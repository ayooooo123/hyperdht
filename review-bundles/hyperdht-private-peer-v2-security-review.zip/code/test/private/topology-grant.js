'use strict'

const test = require('brittle')
const b4a = require('b4a')

const { cryptoSuite } = require('../../lib/private/crypto-suite')
const { PrivateRouteError } = require('../../lib/private/errors')
const routes = Object.freeze({ ...require('../..'), PrivateRouteError })
const {
  DOMAIN,
  LINK_OPERATION,
  PROTOCOL_VERSION,
  ROLE,
  TOPOLOGY_ROLE,
  roleForIdentity
} = require('../../lib/private/protocol')
const {
  TEST_ONLY_LINK_DIRECTORY_OBSERVER,
  LinkDirectory,
  decodeTopologyGrant,
  encodeTopologyGrant,
  encodeUnsignedTopologyGrant,
  readLinkHandle,
  readVerifiedTopologyGrant,
  signTopologyGrant,
  verifyTopologyGrant
} = require('../../lib/private/topology-grant')

const seed = (value) => b4a.alloc(32, value)

function expectCode(t, fn, code) {
  let error = null
  try {
    fn()
  } catch (err) {
    error = err
  }
  t.ok(error instanceof PrivateRouteError)
  if (error) t.is(error.code, code)
}

function captureCopies(operation) {
  const original = b4a.from
  const allocations = []
  let result = null
  let error = null
  b4a.from = (...arguments_) => {
    const value = original(...arguments_)
    allocations.push(value)
    return value
  }
  try {
    result = operation()
  } catch (err) {
    error = err
  } finally {
    b4a.from = original
  }
  return { allocations, error, result }
}

function retainedGrantCopies(allocations, encodingSize) {
  let encodingIndex = -1
  for (let index = allocations.length - 1; index >= 0; index--) {
    if (allocations[index].byteLength === encodingSize) {
      encodingIndex = index
      break
    }
  }
  if (encodingIndex < 1) return []
  return [
    allocations[encodingIndex - 1],
    allocations[encodingIndex],
    ...allocations.slice(encodingIndex + 1, encodingIndex + 5)
  ]
}

function allZero(buffers) {
  return buffers.every((buffer) => buffer.every((byte) => byte === 0))
}

function privateRoleIdentity(start = 1) {
  for (let value = start; value < 256; value++) {
    const pair = cryptoSuite.keyPair(seed(value))
    if (roleForIdentity(pair.publicKey) === ROLE.PRIVATE) return pair
  }
  throw new Error('Unable to derive deterministic private-role identity')
}

function safetyRoleIdentity(start = 1) {
  for (let value = start; value < 256; value++) {
    const pair = cryptoSuite.keyPair(seed(value))
    if (roleForIdentity(pair.publicKey) === ROLE.SAFETY) return pair
  }
  throw new Error('Unable to derive deterministic safety-role identity')
}

const KNOWN_UNSIGNED_HEX =
  '0000000000111111111111111111111111111111111111111111111111111111111111111143046bfe4092b3e94994eada15dcc20d8aaa07b658fd3954eb8e0efb8bdca5de00047f000001a029014ed32f63bf35f0eeefcb25f28a2e1fbdc873ae2835671b0c9460f5f12e4556a80104c0000209a02a020102030405060708000000000000100000000000000020002222222222222222222222222222222222222222222222222222222222222222'
const KNOWN_SIGNED_HASH_HEX = '2553e6ea2546ee6a7935fc1f9b212aa5de4c90de4334d0c3bc5466c60a2f7fe8'
const KNOWN_SIGNATURE_HEX =
  '7ec8de683cb14a07ba46946efe31f31932f8c50ba866ba8a01bbf5e164eef310f1fd6ca5c2ab54feb005e29e3e32bbe2522f8acf524bdc8e14db49a7587af50a'
const KNOWN_DIGEST_HEX = '0b8667ec50bf9088b93718bc0a1486e14a9697d78f576eba9f61db061ce68019'
const INVALID_SOURCE_DESTINATION_HEX =
  '0000000000111111111111111111111111111111111111111111111111111111111111111143046bfe4092b3e94994eada15dcc20d8aaa07b658fd3954eb8e0efb8bdca5de00047f000001a029014ed32f63bf35f0eeefcb25f28a2e1fbdc873ae2835671b0c9460f5f12e4556a80604c0000209a02a020102030405060708000000000000100000000000000020002222222222222222222222222222222222222222222222222222222222222222379dfdef88eaa663db808df8e9a8a09ab0d958a297b9d4047e053c5de7ae4aaa2b19081773f3e8e509c3fdc9d1dd2b26e813c263ecd0a05d899d71796fa40e03'
const MAX_TIMER_DELAY = 0x7fff_ffff

function endpoint(identity32, role, host, port, operations) {
  return { identity32, role, host, port, operations }
}

function knownFixture(overrides = {}) {
  const authority = cryptoSuite.keyPair(seed(90))
  const a = cryptoSuite.keyPair(seed(31))
  const b = cryptoSuite.keyPair(seed(32))
  const grant = {
    version: PROTOCOL_VERSION,
    format: 0,
    grantId32: seed(17),
    endpointA: endpoint(
      a.publicKey,
      TOPOLOGY_ROLE.SOURCE,
      '127.0.0.1',
      41001,
      LINK_OPERATION.INITIATE
    ),
    endpointB: endpoint(
      b.publicKey,
      TOPOLOGY_ROLE.SAFETY_GUARD,
      '192.0.2.9',
      41002,
      LINK_OPERATION.ACCEPT
    ),
    epoch: 0x0102_0304_0506_0708n,
    notBefore: 0x1000n,
    expiresAt: 0x2000n,
    runId32: seed(34),
    ...overrides
  }
  return { authority, a, b, grant }
}

function classifiedFixture(overrides = {}) {
  const authority = cryptoSuite.keyPair(seed(91))
  const safety = safetyRoleIdentity(100)
  const privateRelay = privateRoleIdentity(120)
  const grant = {
    version: PROTOCOL_VERSION,
    format: 0,
    grantId32: seed(18),
    endpointA: endpoint(
      safety.publicKey,
      TOPOLOGY_ROLE.SAFETY_FINAL,
      '2001:db8::1',
      42001,
      LINK_OPERATION.KNOWN
    ),
    endpointB: endpoint(
      privateRelay.publicKey,
      TOPOLOGY_ROLE.PRIVATE_ENTRY,
      '2001:db8::2',
      42002,
      LINK_OPERATION.KNOWN
    ),
    epoch: 7n,
    notBefore: 100n,
    expiresAt: 200n,
    runId32: seed(35),
    ...overrides
  }
  return { authority, safety, privateRelay, grant }
}

function signedFixture(fixture = classifiedFixture()) {
  return { ...fixture, signed: signTopologyGrant(fixture.grant, fixture.authority.secretKey) }
}

function twoSignedFixtures() {
  const first = signedFixture()
  const base = classifiedFixture()
  const second = signedFixture(
    classifiedFixture({
      grantId32: seed(19),
      endpointB: {
        ...base.grant.endpointB,
        host: '2001:db8::3',
        port: 42003
      }
    })
  )
  return { first, second }
}

function fakeClock(start = 100n) {
  let now = start
  let nextId = 1
  const timers = new Map()

  function runDue() {
    let progressed = true
    while (progressed) {
      progressed = false
      for (const [id, timer] of timers) {
        if (timer.at > now) continue
        timers.delete(id)
        timer.callback()
        progressed = true
        break
      }
    }
  }

  return Object.freeze({
    now: () => now,
    schedule(callback, delay) {
      const id = nextId++
      timers.set(id, { callback, at: now + BigInt(delay) })
      return id
    },
    cancel(id) {
      timers.delete(id)
    },
    advance(delta) {
      now += BigInt(delta)
      runDue()
    },
    pending: () => timers.size
  })
}

function inertClock(start = 100n) {
  let now = start
  let nextId = 1
  const timers = new Set()
  return Object.freeze({
    now: () => now,
    schedule() {
      const id = nextId++
      timers.add(id)
      return id
    },
    cancel(id) {
      timers.delete(id)
    },
    advance(delta) {
      now += BigInt(delta)
    },
    pending: () => timers.size
  })
}

function directoryOptions(fixture, clock, overrides = {}) {
  return {
    localIdentity32: fixture.safety.publicKey,
    localRole: TOPOLOGY_ROLE.SAFETY_FINAL,
    authorityPublicKey: fixture.authority.publicKey,
    epoch: fixture.grant.epoch,
    runId32: fixture.grant.runId32,
    now: clock.now,
    schedule: clock.schedule,
    cancel: clock.cancel,
    onClose() {},
    onError() {},
    ...overrides
  }
}

function authorization(fixture, digest32, overrides = {}) {
  return {
    digest32,
    operation: LINK_OPERATION.INITIATE,
    localIdentity32: fixture.safety.publicKey,
    localRole: TOPOLOGY_ROLE.SAFETY_FINAL,
    peerIdentity32: fixture.privateRelay.publicKey,
    peerRole: TOPOLOGY_ROLE.PRIVATE_ENTRY,
    epoch: fixture.grant.epoch,
    runId32: fixture.grant.runId32,
    ...overrides
  }
}

test('topology grant constants are frozen, distinct, and topology roles do not overload relay roles', (t) => {
  t.alike(TOPOLOGY_ROLE, {
    SOURCE: 0,
    SAFETY_GUARD: 1,
    SAFETY_FINAL: 2,
    PRIVATE_ENTRY: 3,
    PRIVATE_MIDDLE: 4,
    PRIVATE_FINAL: 5,
    DESTINATION: 6
  })
  t.alike(LINK_OPERATION, { INITIATE: 1, ACCEPT: 2, KNOWN: 3 })
  t.ok(Object.isFrozen(TOPOLOGY_ROLE))
  t.ok(Object.isFrozen(LINK_OPERATION))
  t.is(b4a.toString(DOMAIN.TOPOLOGY_GRANT), 'hyperdht-private-routes/topology-grant/v0')
  t.is('TEST_ONLY_LINK_DIRECTORY_OBSERVER' in routes, false)
  t.is('readLinkHandle' in routes, false)
  t.is('readVerifiedTopologyGrant' in routes, false)
})

test('canonical grant has exact known-answer bytes, domain hash, signature, and digest', (t) => {
  const fixture = knownFixture()
  const unsigned = encodeUnsignedTopologyGrant(fixture.grant)
  const expectedUnsigned = b4a.from(KNOWN_UNSIGNED_HEX, 'hex')

  t.is(unsigned.byteLength, 175)
  t.alike(unsigned, expectedUnsigned)

  const signedHash = cryptoSuite.hash([DOMAIN.TOPOLOGY_GRANT, unsigned])
  t.is(b4a.toString(signedHash, 'hex'), KNOWN_SIGNED_HASH_HEX)

  const signed = signTopologyGrant(fixture.grant, fixture.authority.secretKey)
  t.is(signed.byteLength, 239)
  t.alike(signed.subarray(0, unsigned.byteLength), expectedUnsigned)
  t.is(b4a.toString(signed.subarray(unsigned.byteLength), 'hex'), KNOWN_SIGNATURE_HEX)
  t.ok(
    cryptoSuite.verify(
      signedHash,
      signed.subarray(unsigned.byteLength),
      fixture.authority.publicKey
    )
  )
  t.is(b4a.toString(cryptoSuite.hash(signed), 'hex'), KNOWN_DIGEST_HEX)
  t.alike(encodeTopologyGrant(decodeTopologyGrant(signed)), signed)
})

test('one signed grant is identical at both peers and preserves all bilateral bindings', (t) => {
  const fixture = knownFixture()
  const reversed = {
    ...fixture.grant,
    endpointA: fixture.grant.endpointB,
    endpointB: fixture.grant.endpointA
  }
  const canonical = signTopologyGrant(fixture.grant, fixture.authority.secretKey)
  const canonicalFromReverse = signTopologyGrant(reversed, fixture.authority.secretKey)

  t.alike(canonicalFromReverse, canonical)

  const verifiedA = verifyTopologyGrant(canonical, fixture.authority.publicKey, {
    localIdentity32: fixture.a.publicKey,
    now: 0x1000n
  })
  const verifiedB = verifyTopologyGrant(canonical, fixture.authority.publicKey, {
    localIdentity32: fixture.b.publicKey,
    now: 0x1000n
  })
  t.alike(Object.keys(verifiedA), [])
  t.alike(Object.keys(verifiedB), [])

  const atA = readVerifiedTopologyGrant(verifiedA)
  const atB = readVerifiedTopologyGrant(verifiedB)
  t.alike(atA.digest32, atB.digest32)
  t.alike(atA.encoding, atB.encoding)
  t.alike(atA.local.identity32, fixture.a.publicKey)
  t.alike(atA.peer.identity32, fixture.b.publicKey)
  t.is(atA.local.operations, LINK_OPERATION.INITIATE)
  t.is(atA.peer.operations, LINK_OPERATION.ACCEPT)
  t.alike(atB.local.identity32, fixture.b.publicKey)
  t.alike(atB.peer.identity32, fixture.a.publicKey)
  t.is(atB.local.operations, LINK_OPERATION.ACCEPT)
  t.is(atB.peer.operations, LINK_OPERATION.INITIATE)
  t.alike(atA.peer.address, { family: 4, host: '192.0.2.9', port: 41002 })
  t.alike(atB.peer.address, { family: 4, host: '127.0.0.1', port: 41001 })
  t.is(atA.epoch, 0x0102_0304_0506_0708n)
  t.is(atA.notBefore, 0x1000n)
  t.is(atA.expiresAt, 0x2000n)
  t.alike(atA.runId32, seed(34))

  atA.digest32.fill(0)
  atA.encoding.fill(0)
  atA.local.identity32.fill(0)
  t.is(b4a.toString(readVerifiedTopologyGrant(verifiedA).digest32, 'hex'), KNOWN_DIGEST_HEX)
  t.alike(readVerifiedTopologyGrant(verifiedA).local.identity32, fixture.a.publicKey)
})

test('numeric IPv4 and canonical IPv6 round trip while aliases and names fail closed', (t) => {
  const fixture = classifiedFixture()
  const signed = signTopologyGrant(fixture.grant, fixture.authority.secretKey)
  const decoded = decodeTopologyGrant(signed)

  const hosts = [decoded.endpointA.host, decoded.endpointB.host].sort()
  t.alike(hosts, ['2001:db8::1', '2001:db8::2'])

  for (const host of [
    'localhost',
    '127.000.0.1',
    '127.0.0.1.',
    '2001:0db8::1',
    '2001:DB8::1',
    '2001:db8:0:0:0:0:0:1',
    '2001:db8::1%lo0',
    '::ffff:192.0.2.1'
  ]) {
    expectCode(
      t,
      () =>
        signTopologyGrant(
          {
            ...fixture.grant,
            endpointA: { ...fixture.grant.endpointA, host }
          },
          fixture.authority.secretKey
        ),
      'INVALID_ROUTE'
    )
  }
})

test('topology participant roles bind safety/private relay classification without classifying endpoints', (t) => {
  const fixture = classifiedFixture()
  t.ok(signTopologyGrant(fixture.grant, fixture.authority.secretKey))

  for (const role of [TOPOLOGY_ROLE.SAFETY_GUARD, TOPOLOGY_ROLE.SAFETY_FINAL]) {
    expectCode(
      t,
      () =>
        signTopologyGrant(
          {
            ...fixture.grant,
            endpointA: {
              ...fixture.grant.endpointA,
              identity32: fixture.privateRelay.publicKey,
              role
            }
          },
          fixture.authority.secretKey
        ),
      'UNAUTHORIZED'
    )
  }

  for (const role of [
    TOPOLOGY_ROLE.PRIVATE_ENTRY,
    TOPOLOGY_ROLE.PRIVATE_MIDDLE,
    TOPOLOGY_ROLE.PRIVATE_FINAL
  ]) {
    expectCode(
      t,
      () =>
        signTopologyGrant(
          {
            ...fixture.grant,
            endpointB: {
              ...fixture.grant.endpointB,
              identity32: fixture.safety.publicKey,
              role
            }
          },
          fixture.authority.secretKey
        ),
      'UNAUTHORIZED'
    )
  }

  const endpoints = knownFixture()
  t.ok(signTopologyGrant(endpoints.grant, endpoints.authority.secretKey))
})

test('topology grants accept only the six undirected adjacent role pairs', (t) => {
  const authority = cryptoSuite.keyPair(seed(90))
  const identities = [
    cryptoSuite.keyPair(seed(201)),
    cryptoSuite.keyPair(seed(31)),
    cryptoSuite.keyPair(seed(32)),
    cryptoSuite.keyPair(seed(34)),
    cryptoSuite.keyPair(seed(37)),
    cryptoSuite.keyPair(seed(41)),
    cryptoSuite.keyPair(seed(202))
  ]
  const alternates = [
    cryptoSuite.keyPair(seed(203)),
    cryptoSuite.keyPair(seed(35)),
    cryptoSuite.keyPair(seed(36)),
    cryptoSuite.keyPair(seed(42)),
    cryptoSuite.keyPair(seed(43)),
    cryptoSuite.keyPair(seed(34)),
    cryptoSuite.keyPair(seed(204))
  ]
  const allowed = new Set(['0:1', '1:2', '2:3', '3:4', '4:5', '5:6'])

  for (let left = TOPOLOGY_ROLE.SOURCE; left <= TOPOLOGY_ROLE.DESTINATION; left++) {
    for (let right = left; right <= TOPOLOGY_ROLE.DESTINATION; right++) {
      const grant = {
        version: PROTOCOL_VERSION,
        format: 0,
        grantId32: b4a.alloc(32, left * 8 + right),
        endpointA: endpoint(
          identities[left].publicKey,
          left,
          '127.0.0.1',
          43000 + left,
          LINK_OPERATION.KNOWN
        ),
        endpointB: endpoint(
          left === right ? alternates[right].publicKey : identities[right].publicKey,
          right,
          '127.0.0.2',
          43100 + right,
          LINK_OPERATION.KNOWN
        ),
        epoch: 9n,
        notBefore: 10n,
        expiresAt: 20n,
        runId32: seed(45)
      }
      const pair = `${left}:${right}`
      if (allowed.has(pair)) t.ok(signTopologyGrant(grant, authority.secretKey), pair)
      else expectCode(t, () => signTopologyGrant(grant, authority.secretKey), 'UNAUTHORIZED')
    }
  }

  const self = knownFixture()
  expectCode(
    t,
    () =>
      signTopologyGrant(
        {
          ...self.grant,
          endpointB: { ...self.grant.endpointB, identity32: self.grant.endpointA.identity32 }
        },
        self.authority.secretKey
      ),
    'INVALID_ROUTE'
  )
})

test('a correctly authority-signed nonadjacent grant is rejected during decode and verification', (t) => {
  const fixture = knownFixture()
  const encoding = b4a.from(INVALID_SOURCE_DESTINATION_HEX, 'hex')
  const unsigned = encoding.subarray(0, encoding.byteLength - 64)
  const signature = encoding.subarray(encoding.byteLength - 64)

  t.ok(
    cryptoSuite.verify(
      cryptoSuite.hash([DOMAIN.TOPOLOGY_GRANT, unsigned]),
      signature,
      fixture.authority.publicKey
    )
  )
  expectCode(t, () => decodeTopologyGrant(encoding), 'UNAUTHORIZED')
  expectCode(
    t,
    () =>
      verifyTopologyGrant(encoding, fixture.authority.publicKey, {
        localIdentity32: fixture.a.publicKey,
        now: 0x1000n
      }),
    'UNAUTHORIZED'
  )
})

test('every one-byte mutation of a signed topology grant is rejected', (t) => {
  const fixture = knownFixture()
  const signed = signTopologyGrant(fixture.grant, fixture.authority.secretKey)

  for (let offset = 0; offset < signed.byteLength; offset++) {
    const mutated = b4a.from(signed)
    mutated[offset] ^= 1
    let error = null
    try {
      verifyTopologyGrant(mutated, fixture.authority.publicKey, {
        localIdentity32: fixture.a.publicKey,
        now: 0x1000n
      })
    } catch (err) {
      error = err
    }
    t.ok(error, `mutation at byte ${offset}`)
  }

  expectCode(
    t,
    () =>
      verifyTopologyGrant(signed.subarray(0, signed.byteLength - 1), fixture.authority.publicKey, {
        localIdentity32: fixture.a.publicKey,
        now: 0x1000n
      }),
    'INVALID_ROUTE'
  )
  expectCode(
    t,
    () =>
      verifyTopologyGrant(b4a.concat([signed, b4a.from([0])]), fixture.authority.publicKey, {
        localIdentity32: fixture.a.publicKey,
        now: 0x1000n
      }),
    'INVALID_ROUTE'
  )
})

test('grant verification requires authority, local membership, and active validity window', (t) => {
  const fixture = knownFixture()
  const signed = signTopologyGrant(fixture.grant, fixture.authority.secretKey)
  const stranger = cryptoSuite.keyPair(seed(99))

  expectCode(
    t,
    () =>
      verifyTopologyGrant(signed, stranger.publicKey, {
        localIdentity32: fixture.a.publicKey,
        now: 0x1000n
      }),
    'UNAUTHORIZED'
  )
  expectCode(
    t,
    () =>
      verifyTopologyGrant(signed, fixture.authority.publicKey, {
        localIdentity32: stranger.publicKey,
        now: 0x1000n
      }),
    'UNAUTHORIZED'
  )
  expectCode(
    t,
    () =>
      verifyTopologyGrant(signed, fixture.authority.publicKey, {
        localIdentity32: fixture.a.publicKey,
        now: 0x0fffn
      }),
    'UNAUTHORIZED'
  )
  expectCode(
    t,
    () =>
      verifyTopologyGrant(signed, fixture.authority.publicKey, {
        localIdentity32: fixture.a.publicKey,
        now: 0x2000n
      }),
    'UNAUTHORIZED'
  )
})

test('LinkDirectory authorizes one opaque adjacent handle with exact route-local bindings', (t) => {
  const fixture = signedFixture()
  const clock = fakeClock()
  const directory = new LinkDirectory(directoryOptions(fixture, clock))
  const digest32 = directory.add(fixture.signed)
  const handle = directory.authorize(authorization(fixture, digest32))
  const again = directory.authorize(authorization(fixture, b4a.from(digest32)))

  t.is(handle, again)
  t.alike(Object.keys(handle), [])
  t.alike(Object.keys(directory), [])
  for (const name of ['entries', 'values', 'addresses', 'lookupAddress', 'dial', 'send']) {
    t.is(name in directory, false)
  }

  const link = readLinkHandle(handle)
  t.alike(link.digest32, digest32)
  t.alike(link.localIdentity32, fixture.safety.publicKey)
  t.is(link.localRole, TOPOLOGY_ROLE.SAFETY_FINAL)
  t.alike(link.peerIdentity32, fixture.privateRelay.publicKey)
  t.is(link.peerRole, TOPOLOGY_ROLE.PRIVATE_ENTRY)
  t.alike(link.peerAddress, { family: 6, host: '2001:db8::2', port: 42002 })
  t.is(link.epoch, 7n)
  t.alike(link.runId32, seed(35))
  t.is(link.operations, LINK_OPERATION.KNOWN)

  link.peerIdentity32.fill(0)
  link.digest32.fill(0)
  t.alike(readLinkHandle(handle).peerIdentity32, fixture.privateRelay.publicKey)
  t.alike(readLinkHandle(handle).digest32, digest32)

  const invalidBindings = [
    { operation: LINK_OPERATION.ACCEPT << 1 },
    { localIdentity32: fixture.privateRelay.publicKey },
    { localRole: TOPOLOGY_ROLE.SAFETY_GUARD },
    { peerIdentity32: fixture.safety.publicKey },
    { peerRole: TOPOLOGY_ROLE.PRIVATE_MIDDLE },
    { epoch: 8n },
    { runId32: seed(36) },
    { digest32: seed(37) }
  ]
  for (const override of invalidBindings) {
    expectCode(
      t,
      () => directory.authorize(authorization(fixture, digest32, override)),
      'UNAUTHORIZED'
    )
  }
})

test('LinkDirectory accepts only local verified grants and copies all retained bytes', (t) => {
  const fixture = signedFixture()
  const clock = fakeClock()
  const directory = new LinkDirectory(directoryOptions(fixture, clock))
  const input = b4a.from(fixture.signed)
  const digest32 = directory.add(input)
  input.fill(0)
  fixture.grant.runId32.fill(0)
  fixture.safety.publicKey.fill(0)

  const handle = directory.authorize({
    ...authorization(classifiedFixture(), digest32),
    localIdentity32: readVerifiedTopologyGrant(
      verifyTopologyGrant(fixture.signed, fixture.authority.publicKey, {
        localIdentity32: safetyRoleIdentity(100).publicKey,
        now: 100n
      })
    ).local.identity32
  })
  t.ok(handle)

  const stranger = cryptoSuite.keyPair(seed(199))
  const unrelated = knownFixture({
    grantId32: seed(44),
    epoch: 7n,
    notBefore: 100n,
    expiresAt: 200n,
    runId32: seed(35)
  })
  unrelated.grant.endpointA = {
    ...unrelated.grant.endpointA,
    identity32: stranger.publicKey
  }
  const unrelatedSigned = signTopologyGrant(unrelated.grant, unrelated.authority.secretKey)
  const otherDirectory = new LinkDirectory({
    ...directoryOptions(classifiedFixture(), clock),
    authorityPublicKey: unrelated.authority.publicKey
  })
  expectCode(t, () => otherDirectory.add(unrelatedSigned), 'UNAUTHORIZED')
})

test('LinkDirectory expiry closes the active handle, tombstones it, and prevents reopening', (t) => {
  const fixture = signedFixture()
  const clock = fakeClock()
  const closes = []
  const snapshots = []
  const directory = new LinkDirectory(
    directoryOptions(fixture, clock, {
      onClose: (handle, reason) => closes.push({ handle, reason }),
      [TEST_ONLY_LINK_DIRECTORY_OBSERVER]: (snapshot) => snapshots.push(snapshot)
    })
  )
  const digest32 = directory.add(fixture.signed)
  const handle = directory.authorize(authorization(fixture, digest32))

  t.is(clock.pending(), 1)
  clock.advance(99)
  t.is(closes.length, 0)
  clock.advance(1)
  t.alike(closes, [{ handle, reason: 'expired' }])
  t.is(clock.pending(), 0)
  expectCode(t, () => directory.authorize(authorization(fixture, digest32)), 'UNAUTHORIZED')
  expectCode(t, () => directory.add(fixture.signed), 'UNAUTHORIZED')
  t.alike(snapshots.at(-1), {
    grants: 0,
    handles: 0,
    tombstones: 1,
    timers: 0,
    destroyed: false
  })
})

test('handle reads synchronously enforce exact expiry with an inert scheduler', (t) => {
  for (const delta of [100, 101]) {
    const fixture = signedFixture()
    const clock = inertClock()
    const closes = []
    const directory = new LinkDirectory(
      directoryOptions(fixture, clock, {
        onClose: (handle, reason) => closes.push({ handle, reason })
      })
    )
    const digest32 = directory.add(fixture.signed)
    const handle = directory.authorize(authorization(fixture, digest32))
    clock.advance(delta)
    expectCode(t, () => readLinkHandle(handle), 'UNAUTHORIZED')
    t.alike(closes, [{ handle, reason: 'expired' }], `${delta}`)
    t.is(clock.pending(), 0, `${delta}`)
    expectCode(t, () => readLinkHandle(handle), 'UNAUTHORIZED')
    t.is(closes.length, 1, `${delta}`)
  }
})

test('reentrant timer cancellation cannot close or notify the same handle twice', (t) => {
  const fixture = signedFixture()
  let now = 100n
  let directory
  let digest32
  let reentered = false
  const closes = []
  const clock = {
    now: () => now,
    schedule: () => 1,
    cancel() {
      if (reentered) return
      reentered = true
      directory.revoke({ digest32, epoch: 7n, runId32: fixture.grant.runId32 })
    }
  }
  directory = new LinkDirectory(
    directoryOptions(fixture, clock, {
      onClose: (handle, reason) => closes.push({ handle, reason })
    })
  )
  digest32 = directory.add(fixture.signed)
  const handle = directory.authorize(authorization(fixture, digest32))
  now = 200n
  expectCode(t, () => readLinkHandle(handle), 'UNAUTHORIZED')
  t.alike(closes, [{ handle, reason: 'expired' }])
  t.is(reentered, true)
})

test('same-epoch revocation is bound to the configured run and permanently tombstones the grant', (t) => {
  const fixture = signedFixture()
  const clock = fakeClock()
  const closes = []
  const directory = new LinkDirectory(
    directoryOptions(fixture, clock, {
      onClose: (handle, reason) => closes.push({ handle, reason })
    })
  )
  const digest32 = directory.add(fixture.signed)
  const handle = directory.authorize(authorization(fixture, digest32))

  expectCode(
    t,
    () => directory.revoke({ digest32, epoch: 8n, runId32: fixture.grant.runId32 }),
    'UNAUTHORIZED'
  )
  expectCode(t, () => directory.revoke({ digest32, epoch: 7n, runId32: seed(90) }), 'UNAUTHORIZED')
  t.is(directory.authorize(authorization(fixture, digest32)), handle)

  directory.revoke({ digest32, epoch: 7n, runId32: fixture.grant.runId32 })
  t.alike(closes, [{ handle, reason: 'revoked' }])
  expectCode(t, () => directory.authorize(authorization(fixture, digest32)), 'UNAUTHORIZED')
  expectCode(t, () => directory.add(fixture.signed), 'UNAUTHORIZED')
  expectCode(
    t,
    () => directory.revoke({ digest32, epoch: 7n, runId32: fixture.grant.runId32 }),
    'UNAUTHORIZED'
  )
})

test('a closing handle is non-admissible before user onClose runs', (t) => {
  const fixture = signedFixture()
  const clock = fakeClock()
  let callbackCode = null
  const directory = new LinkDirectory(
    directoryOptions(fixture, clock, {
      onClose(handle) {
        try {
          readLinkHandle(handle)
        } catch (err) {
          callbackCode = err && err.code
        }
      }
    })
  )
  const digest32 = directory.add(fixture.signed)
  directory.authorize(authorization(fixture, digest32))
  directory.revoke({ digest32, epoch: 7n, runId32: fixture.grant.runId32 })
  t.is(callbackCode, 'UNAUTHORIZED')
})

test('LinkDirectory bounds grants and handles without exposing partial authority', (t) => {
  const first = signedFixture()
  const second = signedFixture(
    classifiedFixture({
      grantId32: seed(19),
      endpointB: {
        ...classifiedFixture().grant.endpointB,
        host: '2001:db8::3',
        port: 42003
      }
    })
  )
  const clock = fakeClock()
  const grantBound = new LinkDirectory(
    directoryOptions(first, clock, { maxGrants: 1, maxHandles: 1 })
  )
  grantBound.add(first.signed)
  expectCode(t, () => grantBound.add(second.signed), 'CIRCUIT_LIMIT')

  const handleBound = new LinkDirectory(
    directoryOptions(first, clock, { maxGrants: 2, maxHandles: 1 })
  )
  const firstDigest = handleBound.add(first.signed)
  const secondDigest = handleBound.add(second.signed)
  t.ok(handleBound.authorize(authorization(first, firstDigest)))
  expectCode(
    t,
    () =>
      handleBound.authorize(
        authorization(second, secondDigest, {
          peerIdentity32: second.privateRelay.publicKey
        })
      ),
    'CIRCUIT_LIMIT'
  )
})

test('revocation tombstones share the configured grant bound and block distinct churn', (t) => {
  const { first, second } = twoSignedFixtures()
  const clock = fakeClock()
  const snapshots = []
  const directory = new LinkDirectory(
    directoryOptions(first, clock, {
      maxGrants: 1,
      maxHandles: 1,
      [TEST_ONLY_LINK_DIRECTORY_OBSERVER]: (snapshot) => snapshots.push(snapshot)
    })
  )
  const digest32 = directory.add(first.signed)
  directory.revoke({ digest32, epoch: first.grant.epoch, runId32: first.grant.runId32 })

  const tombstoned = snapshots.at(-1)
  t.is(tombstoned.grants + tombstoned.tombstones, 1)
  expectCode(t, () => directory.add(first.signed), 'UNAUTHORIZED')
  expectCode(t, () => directory.add(second.signed), 'CIRCUIT_LIMIT')
  const bounded = snapshots.at(-1)
  t.is(bounded.grants + bounded.tombstones, 1)
  t.alike(bounded, {
    grants: 0,
    handles: 0,
    tombstones: 1,
    timers: 0,
    destroyed: false
  })
})

test('expiry tombstones share the configured grant bound and block distinct churn', (t) => {
  const first = signedFixture()
  const base = classifiedFixture()
  const second = signedFixture(
    classifiedFixture({
      grantId32: seed(20),
      endpointB: { ...base.grant.endpointB, host: '2001:db8::4', port: 42004 },
      expiresAt: 300n
    })
  )
  const clock = fakeClock()
  const snapshots = []
  const directory = new LinkDirectory(
    directoryOptions(first, clock, {
      maxGrants: 1,
      maxHandles: 1,
      [TEST_ONLY_LINK_DIRECTORY_OBSERVER]: (snapshot) => snapshots.push(snapshot)
    })
  )
  directory.add(first.signed)
  clock.advance(100)

  const tombstoned = snapshots.at(-1)
  t.is(tombstoned.grants + tombstoned.tombstones, 1)
  expectCode(t, () => directory.add(first.signed), 'UNAUTHORIZED')
  expectCode(t, () => directory.add(second.signed), 'CIRCUIT_LIMIT')
  const bounded = snapshots.at(-1)
  t.is(bounded.grants + bounded.tombstones, 1)
})

test('a synchronous schedule failure rolls add back and returns a sanitized route error', (t) => {
  const { first, second } = twoSignedFixtures()
  const clock = fakeClock()
  const snapshots = []
  let scheduleCalls = 0
  const directory = new LinkDirectory(
    directoryOptions(first, clock, {
      maxGrants: 1,
      maxHandles: 1,
      schedule(callback, delay) {
        scheduleCalls++
        if (scheduleCalls === 1) throw new Error('sensitive schedule failure')
        return clock.schedule(callback, delay)
      },
      [TEST_ONLY_LINK_DIRECTORY_OBSERVER]: (snapshot) => snapshots.push(snapshot)
    })
  )

  let error = null
  try {
    directory.add(first.signed)
  } catch (err) {
    error = err
  }
  t.ok(error instanceof routes.PrivateRouteError)
  if (error) {
    t.is(error.code, 'ROUTE_UNAVAILABLE')
    t.is(error.message.includes('sensitive'), false)
  }

  t.ok(directory.add(second.signed))
  t.alike(snapshots.at(-1), {
    grants: 1,
    handles: 0,
    tombstones: 0,
    timers: 1,
    destroyed: false
  })
  directory.destroy()
})

test('expiry arming cannot publish after a synchronous callback, revoke, destroy, or throw', (t) => {
  for (const mode of ['callback', 'revoke', 'destroy', 'throw']) {
    const fixture = signedFixture()
    let now = 100n
    let directory = null
    const cancelled = []
    const digest32 = cryptoSuite.hash(fixture.signed)
    const clock = {
      now: () => now,
      schedule(callback) {
        if (mode === 'callback') {
          now = 200n
          callback()
        } else if (mode === 'revoke') {
          directory.revoke({
            digest32,
            epoch: fixture.grant.epoch,
            runId32: fixture.grant.runId32
          })
        } else if (mode === 'destroy') {
          directory.destroy()
        } else {
          throw new Error('sensitive scheduler failure')
        }
        return 41
      },
      cancel(id) {
        cancelled.push(id)
      }
    }
    directory = new LinkDirectory(directoryOptions(fixture, clock))

    const captured = captureCopies(() => directory.add(fixture.signed))
    t.ok(captured.error instanceof routes.PrivateRouteError, mode)
    if (captured.error) {
      t.is(captured.error.code, 'ROUTE_UNAVAILABLE', mode)
      t.is(captured.error.message.includes('sensitive'), false, mode)
    }
    const retained = retainedGrantCopies(captured.allocations, fixture.signed.byteLength)
    t.is(retained.length, 6, `${mode} captures every retained grant buffer`)
    t.ok(allZero(retained), `${mode} clears every retained grant buffer`)
    if (mode !== 'destroy') directory.destroy()
    t.alike(cancelled, mode === 'throw' ? [] : [41], `${mode} disposes its staged timer once`)
  }
})

test('revoke, expiry, and destroy clear every retained grant and link-handle buffer', (t) => {
  for (const mode of ['revoke', 'expiry', 'destroy']) {
    const fixture = signedFixture()
    const clock = fakeClock()
    const directory = new LinkDirectory(directoryOptions(fixture, clock))
    const added = captureCopies(() => directory.add(fixture.signed))
    t.absent(added.error, mode)
    const grantCopies = retainedGrantCopies(added.allocations, fixture.signed.byteLength)
    t.is(grantCopies.length, 6, `${mode} captures every retained grant buffer`)

    const authorized = captureCopies(() =>
      directory.authorize(authorization(fixture, added.result))
    )
    t.absent(authorized.error, mode)
    t.is(authorized.allocations.length, 4, `${mode} captures every retained handle buffer`)

    if (mode === 'revoke') {
      directory.revoke({
        digest32: added.result,
        epoch: fixture.grant.epoch,
        runId32: fixture.grant.runId32
      })
    } else if (mode === 'expiry') {
      clock.advance(100)
    } else {
      directory.destroy()
    }

    t.ok(allZero(grantCopies), `${mode} clears the retained grant`)
    t.ok(allZero(authorized.allocations), `${mode} clears the retained handle`)
    t.not(grantCopies.includes(added.result), `${mode} does not clear the caller digest copy`)
    if (mode !== 'destroy') directory.destroy()
  }
})

test('partial handle construction clears allocations and preserves a retryable grant', (t) => {
  for (const failureAt of [2, 3, 4]) {
    const fixture = signedFixture()
    const clock = fakeClock()
    const directory = new LinkDirectory(directoryOptions(fixture, clock))
    const digest32 = directory.add(fixture.signed)
    const original = b4a.from
    const allocations = []
    let position = 0
    b4a.from = (...arguments_) => {
      if (++position === failureAt) throw new Error('sensitive allocation failure')
      const value = original(...arguments_)
      allocations.push(value)
      return value
    }
    let error = null
    try {
      directory.authorize(authorization(fixture, digest32))
    } catch (err) {
      error = err
    } finally {
      b4a.from = original
    }

    t.ok(error instanceof routes.PrivateRouteError, `${failureAt}`)
    if (error) {
      t.is(error.code, 'ROUTE_UNAVAILABLE', `${failureAt}`)
      t.is(error.message.includes('sensitive'), false, `${failureAt}`)
    }
    t.ok(allocations.length > 0, `${failureAt}`)
    t.ok(allZero(allocations), `${failureAt}`)
    const handle = directory.authorize(authorization(fixture, digest32))
    t.ok(handle, `${failureAt} remains retryable`)
    directory.destroy()
  }
})

test('observer revocation clears and prevents publication of the staged handle', (t) => {
  const fixture = signedFixture()
  const clock = fakeClock()
  let directory = null
  let digest32 = null
  let armed = false
  directory = new LinkDirectory(
    directoryOptions(fixture, clock, {
      [TEST_ONLY_LINK_DIRECTORY_OBSERVER](snapshot) {
        if (!armed || snapshot.handles !== 1) return
        directory.revoke({
          digest32,
          epoch: fixture.grant.epoch,
          runId32: fixture.grant.runId32
        })
      }
    })
  )
  digest32 = directory.add(fixture.signed)
  armed = true

  const captured = captureCopies(() => directory.authorize(authorization(fixture, digest32)))
  t.ok(captured.error instanceof routes.PrivateRouteError)
  if (captured.error) t.is(captured.error.code, 'ROUTE_UNAVAILABLE')
  t.is(captured.allocations.length, 4)
  t.ok(allZero(captured.allocations))
  expectCode(t, () => directory.authorize(authorization(fixture, digest32)), 'UNAUTHORIZED')
  directory.destroy()
})

test('a throwing expiry clock fail-closes the grant and reports only a safe asynchronous error', (t) => {
  const fixture = signedFixture()
  const clock = fakeClock()
  const errors = []
  const snapshots = []
  let nowCalls = 0
  const directory = new LinkDirectory(
    directoryOptions(fixture, clock, {
      now() {
        nowCalls++
        if (nowCalls === 4) throw new Error('sensitive clock failure')
        return clock.now()
      },
      onError: (error) => errors.push(error),
      [TEST_ONLY_LINK_DIRECTORY_OBSERVER]: (snapshot) => snapshots.push(snapshot)
    })
  )
  const digest32 = directory.add(fixture.signed)
  const handle = directory.authorize(authorization(fixture, digest32))

  let escaped = null
  try {
    clock.advance(100)
  } catch (error) {
    escaped = error
  }

  t.absent(escaped)
  t.is(errors.length, 1)
  t.ok(errors[0] instanceof routes.PrivateRouteError)
  if (errors[0]) {
    t.is(errors[0].code, 'ROUTE_UNAVAILABLE')
    t.is(errors[0].message.includes('sensitive'), false)
  }
  expectCode(t, () => readLinkHandle(handle), 'UNAUTHORIZED')
  t.is(clock.pending(), 0)
  t.alike(snapshots.at(-1), {
    grants: 0,
    handles: 0,
    tombstones: 1,
    timers: 0,
    destroyed: false
  })
})

test('a throwing long-horizon reschedule fail-closes instead of leaving an untimed grant', (t) => {
  const fixture = signedFixture(
    classifiedFixture({ expiresAt: 100n + BigInt(MAX_TIMER_DELAY) + 50n })
  )
  const clock = fakeClock()
  const errors = []
  const snapshots = []
  let scheduleCalls = 0
  const directory = new LinkDirectory(
    directoryOptions(fixture, clock, {
      schedule(callback, delay) {
        scheduleCalls++
        if (scheduleCalls === 2) throw new Error('sensitive reschedule failure')
        return clock.schedule(callback, delay)
      },
      onError: (error) => errors.push(error),
      [TEST_ONLY_LINK_DIRECTORY_OBSERVER]: (snapshot) => snapshots.push(snapshot)
    })
  )
  const digest32 = directory.add(fixture.signed)
  const handle = directory.authorize(authorization(fixture, digest32))

  let escaped = null
  try {
    clock.advance(MAX_TIMER_DELAY)
  } catch (error) {
    escaped = error
  }

  t.absent(escaped)
  t.is(scheduleCalls, 2)
  t.is(errors.length, 1)
  t.ok(errors[0] instanceof routes.PrivateRouteError)
  if (errors[0]) t.is(errors[0].code, 'ROUTE_UNAVAILABLE')
  expectCode(t, () => readLinkHandle(handle), 'UNAUTHORIZED')
  t.is(clock.pending(), 0)
  t.alike(snapshots.at(-1), {
    grants: 0,
    handles: 0,
    tombstones: 1,
    timers: 0,
    destroyed: false
  })
})

test('a throwing expiry close callback cannot escape the timer or retain link state', (t) => {
  const fixture = signedFixture()
  const clock = fakeClock()
  const errors = []
  const snapshots = []
  let closes = 0
  const directory = new LinkDirectory(
    directoryOptions(fixture, clock, {
      onClose() {
        closes++
        throw new Error('sensitive expiry close failure')
      },
      onError: (error) => errors.push(error),
      [TEST_ONLY_LINK_DIRECTORY_OBSERVER]: (snapshot) => snapshots.push(snapshot)
    })
  )
  const digest32 = directory.add(fixture.signed)
  const handle = directory.authorize(authorization(fixture, digest32))

  let escaped = null
  try {
    clock.advance(100)
  } catch (error) {
    escaped = error
  }

  t.absent(escaped)
  t.is(closes, 1)
  t.is(errors.length, 1)
  t.ok(errors[0] instanceof routes.PrivateRouteError)
  if (errors[0]) {
    t.is(errors[0].code, 'ROUTE_UNAVAILABLE')
    t.is(errors[0].message.includes('sensitive'), false)
  }
  expectCode(t, () => readLinkHandle(handle), 'UNAUTHORIZED')
  t.is(clock.pending(), 0)
  t.is(snapshots.at(-1).grants + snapshots.at(-1).tombstones, 1)
})

test('the safe asynchronous error observer is sanitized and its own throw is swallowed', (t) => {
  const fixture = signedFixture()
  const clock = fakeClock()
  const received = []
  const directory = new LinkDirectory(
    directoryOptions(fixture, clock, {
      onClose() {
        throw new Error('sensitive source failure')
      },
      onError(error) {
        received.push(error)
        throw new Error('sensitive observer failure')
      }
    })
  )
  const digest32 = directory.add(fixture.signed)
  const handle = directory.authorize(authorization(fixture, digest32))

  let escaped = null
  try {
    clock.advance(100)
  } catch (error) {
    escaped = error
  }

  t.absent(escaped)
  t.is(received.length, 1)
  t.ok(received[0] instanceof routes.PrivateRouteError)
  if (received[0]) {
    t.is(received[0].code, 'ROUTE_UNAVAILABLE')
    t.is(received[0].message.includes('sensitive'), false)
  }
  expectCode(t, () => readLinkHandle(handle), 'UNAUTHORIZED')
  t.is(clock.pending(), 0)
})

test('destroy closes active links, cancels expiry, and leaves zero retained directory state', (t) => {
  const fixture = signedFixture()
  const clock = fakeClock()
  const closes = []
  const snapshots = []
  const directory = new LinkDirectory(
    directoryOptions(fixture, clock, {
      onClose: (handle, reason) => closes.push({ handle, reason }),
      [TEST_ONLY_LINK_DIRECTORY_OBSERVER]: (snapshot) => snapshots.push(snapshot)
    })
  )
  const digest32 = directory.add(fixture.signed)
  const handle = directory.authorize(authorization(fixture, digest32))

  directory.destroy()
  directory.destroy()

  t.alike(closes, [{ handle, reason: 'destroyed' }])
  t.is(clock.pending(), 0)
  t.alike(snapshots.at(-1), {
    grants: 0,
    handles: 0,
    tombstones: 0,
    timers: 0,
    destroyed: true,
    ownedBytes: 0,
    callbacks: 0
  })
  expectCode(t, () => directory.add(fixture.signed), 'CIRCUIT_STATE')
  expectCode(t, () => directory.authorize(authorization(fixture, digest32)), 'CIRCUIT_STATE')
  expectCode(
    t,
    () => directory.revoke({ digest32, epoch: 7n, runId32: fixture.grant.runId32 }),
    'CIRCUIT_STATE'
  )
  expectCode(t, () => readLinkHandle(handle), 'UNAUTHORIZED')
})

test('destroy cleans every handle and callback before mapping the first onClose failure', (t) => {
  const { first, second } = twoSignedFixtures()
  const clock = fakeClock()
  const closes = []
  const snapshots = []
  let firstHandle = null
  const directory = new LinkDirectory(
    directoryOptions(first, clock, {
      maxGrants: 2,
      maxHandles: 2,
      onClose(handle) {
        closes.push(handle)
        if (handle === firstHandle) throw new Error('sensitive onClose failure')
      },
      [TEST_ONLY_LINK_DIRECTORY_OBSERVER]: (snapshot) => snapshots.push(snapshot)
    })
  )
  const firstDigest = directory.add(first.signed)
  const secondDigest = directory.add(second.signed)
  firstHandle = directory.authorize(authorization(first, firstDigest))
  const secondHandle = directory.authorize(authorization(second, secondDigest))

  let error = null
  try {
    directory.destroy()
  } catch (err) {
    error = err
  }

  t.ok(error instanceof routes.PrivateRouteError)
  if (error) {
    t.is(error.code, 'ROUTE_UNAVAILABLE')
    t.is(error.message.includes('sensitive'), false)
  }
  t.alike(closes, [firstHandle, secondHandle])
  expectCode(t, () => readLinkHandle(firstHandle), 'UNAUTHORIZED')
  expectCode(t, () => readLinkHandle(secondHandle), 'UNAUTHORIZED')
  t.is(clock.pending(), 0)
  t.alike(snapshots.at(-1), {
    grants: 0,
    handles: 0,
    tombstones: 0,
    timers: 0,
    destroyed: true,
    ownedBytes: 0,
    callbacks: 0
  })

  directory.destroy()
  t.alike(closes, [firstHandle, secondHandle])
})

test('destroy attempts every timer cancellation and closes every handle after a cancel failure', (t) => {
  const { first, second } = twoSignedFixtures()
  const clock = fakeClock()
  const closes = []
  const snapshots = []
  let cancelCalls = 0
  const directory = new LinkDirectory(
    directoryOptions(first, clock, {
      maxGrants: 2,
      maxHandles: 2,
      cancel(id) {
        clock.cancel(id)
        cancelCalls++
        if (cancelCalls === 1) throw new Error('sensitive cancel failure')
      },
      onClose: (handle) => closes.push(handle),
      [TEST_ONLY_LINK_DIRECTORY_OBSERVER]: (snapshot) => snapshots.push(snapshot)
    })
  )
  const firstDigest = directory.add(first.signed)
  const secondDigest = directory.add(second.signed)
  const firstHandle = directory.authorize(authorization(first, firstDigest))
  const secondHandle = directory.authorize(authorization(second, secondDigest))

  let error = null
  try {
    directory.destroy()
  } catch (err) {
    error = err
  }

  t.ok(error instanceof routes.PrivateRouteError)
  if (error) {
    t.is(error.code, 'ROUTE_UNAVAILABLE')
    t.is(error.message.includes('sensitive'), false)
  }
  t.is(cancelCalls, 2)
  t.alike(closes, [firstHandle, secondHandle])
  expectCode(t, () => readLinkHandle(firstHandle), 'UNAUTHORIZED')
  expectCode(t, () => readLinkHandle(secondHandle), 'UNAUTHORIZED')
  t.is(clock.pending(), 0)
  t.alike(snapshots.at(-1), {
    grants: 0,
    handles: 0,
    tombstones: 0,
    timers: 0,
    destroyed: true,
    ownedBytes: 0,
    callbacks: 0
  })
})
