'use strict'

const test = require('brittle')
const { hrtime } = require('process')
const b4a = require('b4a')
const { digestTestIsolatedAddressTuple } = require('../../lib/private/dht-exit-test-topology-grant')
const { deriveDhtExitPeerId } = require('../../lib/private/dht-exit-destination-table')
const { cryptoSuite } = require('../../lib/private/crypto-suite')
const { deriveBlindedPublicKey, publishPeriods } = require('../../lib/private/blinded-presence')

const { createCoherentTestClock } = require('./coherent-clock')
const { createProcessConfigAuditor } = require('./process/config-auditor')
const { CODEC_VECTOR_DIGEST_HEX } = require('./process/codec-vectors')
const { createProcessControl, spawnRoleProcesses } = require('./process/coordinator')
const { LINK_UNRESPONSIVE_AFTER } = require('../../lib/private/link-control-session')
const {
  PROCESS_PLANS,
  ROLES,
  TEST_ONLY_PROCESS_TOPOLOGY_ISSUER,
  createLiveProcessTopology
} = require('./process/topology-fixture')

const HEALTHY_SILENCE_MS = LINK_UNRESPONSIVE_AFTER + 500
const BLACKHOLE_ROTATION_BOUND_MS = LINK_UNRESPONSIVE_AFTER + 3_500
const READY_IDLE_MS = 2_000

function capabilities(seed) {
  return {
    clocks: TEST_ONLY_PROCESS_TOPOLOGY_ISSUER.clocks(createCoherentTestClock()),
    entropy: TEST_ONLY_PROCESS_TOPOLOGY_ISSUER.entropy(b4a.alloc(32, seed))
  }
}

// Portable loopback has no NAT, so the production endpoint punch there proves only
// the frame path: same-socket reflection off two live DHT roles, the bilateral plan
// exchange over the coordinator, and both punch rounds crossing before the endpoint
// bootstraps. dht-seed and dht-value answer the reflection PING because dht-rpc
// replies to any source with the tuple it observed. identity32 is a label.
function loopbackReflectors() {
  return [9, 11].map((roleIndex) => {
    const host = `127.64.${roleIndex}.1`
    const port = 42_000 + roleIndex
    return { host, port, identity32: cryptoSuite.hash([b4a.from(`${host}:${port}`)]) }
  })
}

function base(projection, type, phaseSequence, generation = projection.generation) {
  return {
    generation,
    phaseSequence,
    role: projection.role,
    roleIndex: projection.roleIndex,
    type
  }
}

function noop() {}

// A role's reachable address: the one peers dial, and the one every isolated-address
// digest is keyed on, because a closer is discovered over the wire and a peer appears
// there at the address it published. topology-fixture.js:1030 mints the learned-grant
// pools from exactly this tuple. A derived plan binds what it publishes, so the two are
// the same address there; a discovered topology carries the published tuples in the
// projection because no role can compute another's.
function reachableTupleFor(projection) {
  if (!projection.meshPeers) return projection.bind
  return projection.meshPeers.tuples[projection.roleIndex - 1]
}

function registerLiveProcessSuite(launch) {
  if (
    !launch ||
    (launch.runtime !== 'node' && launch.runtime !== 'bare') ||
    typeof launch.runtimeVersion !== 'string'
  ) {
    throw new Error('invalid runtime launch record')
  }

  // `launch.placement` lets a caller run the same scenario somewhere other than
  // portable loopback, such as one network namespace per role, and inspect what
  // crossed the wire afterwards. Portable runs pass `null` and are unaffected.
  const plan = launch.plan || PROCESS_PLANS.PORTABLE_LOOPBACK
  const label = launch.label ? ` on ${launch.label}` : ''

  test(`live private route lifecycle in eleven ${launch.runtime} role processes${label}`, async (t) => {
    // `launch.prepare` lets the roles live somewhere this process cannot spawn
    // them. It returns the addresses each role discovered for itself, which the
    // topology is then minted from, and a way to open their control channels. The
    // scenario below is identical either way: same protocol, same auditing.
    const prepared = launch.prepare ? await launch.prepare(t) : null
    const candidateOrder = process.env.PR_CANDIDATE_ORDER || 'normal'
    const localPunch =
      !launch.productionEndpointPunch &&
      process.env.PR_PRODUCTION_ENDPOINT_PUNCH === '1' &&
      plan === PROCESS_PLANS.PORTABLE_LOOPBACK
    const productionEndpointPunch = launch.productionEndpointPunch === true || localPunch
    const natTraversal = localPunch
      ? { reflectors: loopbackReflectors() }
      : (prepared && prepared.natTraversal) || launch.natTraversal || null
    if (productionEndpointPunch && natTraversal === null) {
      throw new Error('production endpoint punch needs reflectors')
    }
    const topology = createLiveProcessTopology({
      candidateOrder,
      plan,
      ...(prepared && prepared.endpoints ? { endpoints: prepared.endpoints } : {}),
      ...(productionEndpointPunch ? { natTraversal } : {}),
      ...capabilities(launch.runtime === 'node' ? 0x31 : 0x32)
    })
    const placement = launch.createPlacement ? launch.createPlacement(topology) : null
    const auditor = createProcessConfigAuditor(topology.oracle)
    auditor.auditAll(topology.projections)
    const children =
      prepared && prepared.openChannels
        ? await prepared.openChannels(topology.projections)
        : spawnRoleProcesses(launch.runtime, topology.projections, {
            enter: placement ? placement.enter : undefined,
            nodePath: launch.nodePath
          })
    const control = createProcessControl({ auditor, children, plan })
    const phases = new Map(ROLES.map((role) => [role, 1n]))
    const generations = new Map(
      topology.projections.map((projection) => [projection.role, projection.generation])
    )
    const projectionFor = (role) => topology.projections[ROLES.indexOf(role)]
    const codecVectorDigest = b4a.from(CODEC_VECTOR_DIGEST_HEX, 'hex')

    function nextPhase(role) {
      const value = phases.get(role) + 1n
      phases.set(role, value)
      return value
    }

    function command(role, type, phaseSequence, fields = {}) {
      const projection = projectionFor(role)
      return {
        ...base(projection, type, phaseSequence, generations.get(role)),
        ...fields
      }
    }

    async function sendAndWait(role, type, eventType, fields = {}, phase = null) {
      const generation = generations.get(role)
      const phaseSequence = phase === null ? nextPhase(role) : phase
      phases.set(role, phaseSequence)
      control.setPhase(role, generation, phaseSequence)
      const waiting = control.expect(role, eventType, generation)
      await control.send(role, command(role, type, phaseSequence, fields))
      return waiting
    }

    const middleRoles = ROLES.filter((role) => role.includes('-middle'))
    const exitRoles = ROLES.filter((role) => role.includes('-exit'))

    async function routingSnapshots() {
      const snapshots = new Map()
      for (const role of [...middleRoles, ...exitRoles]) {
        snapshots.set(role, await sendAndWait(role, 'snapshot', 'snapshot'))
      }
      return snapshots
    }

    function deriveRoutingState(snapshots, previousExitCounts = null) {
      const activePairs = []
      for (const middleRole of middleRoles) {
        const middle = snapshots.get(middleRole)
        if (middle.selectedExitRoleIndex === null) continue
        const exitRole = ROLES[middle.selectedExitRoleIndex - 1]
        const exit = snapshots.get(exitRole)
        t.is(
          exit.selectedMiddleRoleIndex,
          middle.roleIndex,
          `${middleRole} and ${exitRole} report a reciprocal active relationship`
        )
        activePairs.push({ exitRole, middleRole })
      }
      const lookupPair = activePairs.find(({ exitRole }) => {
        const count = snapshots.get(exitRole).ordinaryRequestCount
        return previousExitCounts === null ? count > 0 : count > previousExitCounts.get(exitRole)
      })
      if (lookupPair === undefined) throw new Error('active lookup pair unavailable')
      const announcePair = activePairs.find((pair) => pair !== lookupPair)
      if (announcePair === undefined) throw new Error('active announce pair unavailable')
      return {
        activePairs,
        announcePair,
        lookupPair,
        standbyExits: exitRoles.filter(
          (role) => !activePairs.some((pair) => pair.exitRole === role)
        ),
        standbyMiddles: middleRoles.filter(
          (role) => !activePairs.some((pair) => pair.middleRole === role)
        )
      }
    }

    function assertOptionalGrantUsage(snapshot, role, stage) {
      const responder = learnedGrantResponders.find((candidate) => candidate.role === role)
      const observed = responder === undefined ? -1 : responder.observedCount()
      const count = snapshot.isolatedGrantRequestCount
      t.ok(
        Number.isSafeInteger(count) && count === observed && count >= 0 && count <= 30,
        `${role} matches coordinator-observed grant requests during ${stage}`
      )
      t.is(snapshot.pendingGrantRequests, 0, `${role} leaves no grant request pending`)
      t.ok(snapshot.ordinaryRequestCount >= 1, `${role} sends the immutable request`)
    }

    let learnedGrantResponders = []

    try {
      const configured = []
      for (let index = 0; index < topology.projections.length; index++) {
        const projection = topology.projections[index]
        const waiting = control.expect(projection.role, 'configured', projection.generation)
        await control.send(projection.role, {
          ...base(projection, 'configure', 1n),
          codecVectorDigest,
          projection: topology.oracle.projectionBytes[index],
          run: projection.run,
          runtime: launch.runtime,
          runtimeVersion: launch.runtimeVersion
        })
        configured.push(waiting)
      }
      const configuredEvents = await Promise.all(configured)
      t.is(configuredEvents.length, 11, 'all roles attest runtime, UDX and codec vector')

      const prepared = await Promise.all(
        ROLES.map((role) => sendAndWait(role, 'prepare', 'prepared'))
      )
      t.is(prepared.length, 11, 'all roles bind before ordered DHT setup')

      // t.is(ready.state, ...) alone is not a gate: role-runner sets that state
      // unconditionally after dht.ready(), and dht.ready() resolves on a network
      // where nothing was ever answered - a bootstrap query counts a request
      // timeout and continues, and _bootstrapping is additionally caught. So also
      // require a request to have been ANSWERED, for the roles that must have had
      // one. Activation runs value first, then referral, then seed, which is the
      // reverse of the fixture's one-way DHT edges (topology-fixture.js gives seed
      // nodes:[referral], referral nodes:[value], value nodes:[] with bootstrap
      // pointing at value's OWN tuple): each of referral and seed activates after
      // the single peer it dials is up, so each MUST have been answered by it, and
      // measures 0 answered with 1 timeout when that peer is deaf.
      //
      // dht-value is deliberately NOT asserted. It activates first, with nothing
      // else running, and its only bootstrap address is itself - so it answers its
      // own query and reports a non-zero count on a completely dead network.
      // Asserting it would re-add exactly the assertion-that-cannot-fail this
      // replaces.
      const mustBeAnswered = new Set(['dht-referral', 'dht-seed'])
      for (const role of ['dht-value', 'dht-referral', 'dht-seed']) {
        const ready = await sendAndWait(role, 'activate', 'ready')
        t.is(ready.state, 'DHT_SETUP', `${role} binds in ordered DHT setup`)
        if (mustBeAnswered.has(role)) {
          t.ok(
            ready.answeredRequestCount > 0,
            `${role} had a DHT request answered in ordered DHT setup`
          )
        }
      }

      const preStoreSnapshots = []
      for (const role of ['dht-seed', 'dht-referral', 'dht-value']) {
        const snapshot = await sendAndWait(role, 'snapshot', 'snapshot')
        preStoreSnapshots.push(snapshot)
        t.is(snapshot.storedValueCount, 0, `${role} has no value before setup store`)
        t.alike(snapshot.storedValueDigests, [], `${role} holds no immutable record`)
        t.alike(snapshot.mutableRecordTargets, [], `${role} holds no mutable record`)
      }
      t.is(preStoreSnapshots[1].transientValueBytes, 0)

      const referral = projectionFor('dht-referral')
      const referralGeneration = generations.get('dht-referral')
      const setupPhase = nextPhase('dht-referral')
      phases.set('dht-referral', setupPhase)
      control.setPhase('dht-referral', referralGeneration, setupPhase)
      const opens = control.expectMany('dht-referral', 'audit-open', referralGeneration, 3)
      const closes = control.expectMany('dht-referral', 'audit-close', referralGeneration, 3)
      const stored = control.expect('dht-referral', 'stored', referralGeneration)
      await control.send('dht-referral', {
        ...base(referral, 'store-immutable', setupPhase, referralGeneration),
        value: topology.oracle.immutableValue
      })
      const [openEvents, closeEvents, storedEvent] = await Promise.all([opens, closes, stored])
      t.alike(
        openEvents.map((entry) => entry.class),
        [3, 4, 5],
        'setup opens token, put and readback only'
      )
      t.alike(
        closeEvents.map((entry) => entry.class),
        [3, 4, 5],
        'setup closes token, put and readback only'
      )
      t.ok(storedEvent.valueDigest.equals(topology.oracle.targetHash))
      t.alike(
        storedEvent.setupAuditSequences,
        closeEvents.map((entry) => entry.recordSequence)
      )
      t.alike(
        storedEvent.setupAuditDigests,
        closeEvents.map((entry) => entry.recordDigest)
      )

      const afterStore = []
      for (const role of ['dht-seed', 'dht-referral', 'dht-value']) {
        afterStore.push(await sendAndWait(role, 'snapshot', 'snapshot'))
      }
      t.is(afterStore[0].storedValueCount, 0, 'seed stores no value')
      t.is(afterStore[1].storedValueCount, 0, 'referral stores no value')
      t.is(afterStore[1].transientValueBytes, 0, 'referral clears transient value bytes')
      t.is(afterStore[2].storedValueCount, 1, 'value role stores exactly one value')
      t.alike(afterStore[2].storedValueDigests, [topology.oracle.targetHash])

      // An exit MAY ask for a learned-closer grant when discovery returns an isolated
      // candidate. Real DHT ordering can also return the value directly, in which case
      // no request exists. Keep a standing responder for requests that do arrive, but
      // never make an optional discovery event a prerequisite for scenario progress.
      learnedGrantResponders = ['lookup-exit-a', 'lookup-exit-b', 'announce-exit'].map((role) => {
        const exitProjection = projectionFor(role)
        const learnedCandidates = [
          ['dht-referral', exitProjection.learnedReferralGrants],
          ['dht-value', exitProjection.learnedValueGrants],
          ['dht-seed', exitProjection.learnedSeedGrants]
        ].map(([candidateRole, pools]) => {
          const candidateProjection = projectionFor(candidateRole)
          const candidateTuple = reachableTupleFor(candidateProjection)
          const id = deriveDhtExitPeerId(candidateTuple)
          const digestForGen = (gen) =>
            digestTestIsolatedAddressTuple({
              tuple: candidateTuple,
              id,
              exitRole: exitProjection.roleIndex,
              generation: BigInt(gen)
            })
          const candidatesByGen = {}
          for (const [gen, grants] of Object.entries(pools)) {
            candidatesByGen[gen] = { candidateRole, digest: digestForGen(gen), grants, used: 0 }
          }
          id.fill(0)
          // Each grant is one-shot and a rebuilt branch rediscovers the same closer,
          // so every request for this digest spends the next grant in the pool. The
          // exit derives the candidate id from its tuple, so a rediscovered seed has a
          // different digest than the configured `initialSeedGrant` it already holds.
          return candidatesByGen
        })
        const seedDigest = digestTestIsolatedAddressTuple({
          tuple: exitProjection.dhtSeed,
          id: exitProjection.dhtSeedId,
          exitRole: exitProjection.roleIndex,
          generation: exitProjection.generation
        })
        const state = {
          granting: true,
          observedCount: 0,
          stopped: false,
          waiter: null
        }
        const arm = () => {
          if (state.stopped || control.closed) return
          let waiter
          try {
            waiter = control.expectOptional(
              role,
              'isolated-grant-request',
              exitProjection.generation
            )
          } catch {
            return
          }
          state.waiter = waiter
          waiter.promise.then(async (request) => {
            state.waiter = null
            const allCandidates = learnedCandidates.flatMap((pools) => Object.values(pools))
            const learned = allCandidates.find(
              (candidate) =>
                candidate.candidateRole !== 'dht-seed' &&
                request.tupleDigest.equals(candidate.digest)
            )
            const granted = allCandidates.find((candidate) =>
              request.tupleDigest.equals(candidate.digest)
            )
            const expectedSequence = BigInt(state.observedCount + 1)
            const valid =
              request.requestSequence === expectedSequence &&
              granted !== undefined &&
              !request.tupleDigest.equals(seedDigest) &&
              (state.observedCount !== 0 || learned !== undefined)
            if (!valid) {
              arm()
              return
            }
            state.observedCount++
            arm()
            if (!state.granting || granted.used >= granted.grants.length) return
            const grant = granted.grants[granted.used++]
            // `respondIsolatedGrant` throws SYNCHRONOUSLY when the role's expected phase
            // has moved since the request was observed, coordinator.js:516. A `.catch` on
            // its return value never sees that throw, and the throw then escapes this
            // handler - `.then(onFulfilled, noop)` handles the SOURCE promise's rejection,
            // not its own handler's - so it lands as an unhandled rejection and takes the
            // whole run down. `stopGranting()` removes the reachable case; this keeps a
            // future one from being fatal.
            try {
              await control.respondIsolatedGrant(role, request, grant)
            } catch {}
          }, noop)
        }
        arm()
        return {
          role,
          observedCount() {
            return state.observedCount
          },
          // Stops ANSWERING, and deliberately not listening. The standing waiter has to
          // stay armed so a request that still arrives is tolerated rather than becoming
          // PROCESS_UNEXPECTED_EVENT, and `state.stopped` is what disarms re-arming, so
          // it stays with `stop()`.
          stopGranting() {
            state.granting = false
          },
          stop() {
            state.stopped = true
            state.granting = false
            for (const pools of learnedCandidates) {
              for (const candidate of Object.values(pools)) candidate.digest.fill(0)
            }
            seedDigest.fill(0)
          }
        }
      })

      for (const role of ROLES.slice(1, 8).reverse()) {
        const ready = await sendAndWait(role, 'activate', 'ready')
        t.is(ready.state, 'READY', `${role} activates after DHT setup`)
      }

      if (productionEndpointPunch) {
        const punchStarted = hrtime.bigint()
        const guardReflected = await control.natReflect('guard')
        const endpointReflected = await control.natReflect('endpoint')
        const endpointTuple = reachableTupleFor(projectionFor('endpoint'))
        const guardTuple = reachableTupleFor(projectionFor('guard'))
        const endpointMinted = `${endpointTuple.host}:${endpointTuple.port}`
        const guardMinted = `${guardTuple.host}:${guardTuple.port}`
        t.comment(
          `production reflection endpoint observed=${endpointReflected.observed} minted=${endpointMinted}`
        )
        t.comment(
          `production reflection guard observed=${guardReflected.observed} minted=${guardMinted}`
        )
        t.is(endpointReflected.observed, endpointMinted, 'endpoint reflects its minted tuple')
        t.is(guardReflected.observed, guardMinted, 'guard reflects its minted tuple')

        const offered = await control.natOffer('endpoint')
        const countered = await control.natCounter('guard', offered.offer)
        const planned = await control.natPlan('endpoint', countered.counter)
        await control.natArm('guard', planned.plan)
        const guardStarted = await control.natStart('guard')
        const endpointStarted = await control.natStart('endpoint')
        const punchElapsedMs = Number(hrtime.bigint() - punchStarted) / 1e6
        t.comment(`production endpoint punch elapsed ${punchElapsedMs.toFixed(1)}ms`)
        t.is(guardStarted.firstOwnedSend, true, 'guard first owned punch send')
        t.is(endpointStarted.firstOwnedSend, true, 'endpoint first owned punch send')
      }

      {
        const ready = await sendAndWait('endpoint', 'activate', 'ready')
        t.is(ready.state, 'READY', 'endpoint activates after DHT setup')
      }
      // KI-17 regression. A client waits as long as it likes between readiness and
      // its first request; the exit's open authority once inherited the five-second
      // finalization grace as its absolute deadline, so a request budget reaching
      // past that window was refused. Two seconds here is the shortest wait that
      // failed; the gate must not depend on the coordinator being fast.
      await new Promise((resolve) => setTimeout(resolve, READY_IDLE_MS))
      const readyEndpointSnapshot = await sendAndWait('endpoint', 'snapshot', 'snapshot')
      t.is(readyEndpointSnapshot.guardOnly, true, 'endpoint semantic edge is guard-only')
      t.is(
        readyEndpointSnapshot.endpointSockets,
        0,
        'endpoint retains no bootstrap socket after guard pinning transfers it to the route'
      )
      t.ok(readyEndpointSnapshot.lookupGeneration !== null)
      t.ok(readyEndpointSnapshot.announceGeneration !== null)

      const endpointGeneration = generations.get('endpoint')
      const valueWaiting = control.expect('endpoint', 'value', endpointGeneration)
      await control.send(
        'endpoint',
        command('endpoint', 'immutable-get', phases.get('endpoint'), {
          target: topology.oracle.targetHash
        })
      )
      const firstValue = await valueWaiting
      t.ok(firstValue.target.equals(topology.oracle.targetHash))
      t.ok(firstValue.value.equals(topology.oracle.immutableValue), 'first immutable get is exact')
      const firstRoutingSnapshots = await routingSnapshots()
      const initialRouting = deriveRoutingState(firstRoutingSnapshots)
      const initialLookupExit = firstRoutingSnapshots.get(initialRouting.lookupPair.exitRole)
      assertOptionalGrantUsage(
        initialLookupExit,
        initialRouting.lookupPair.exitRole,
        'initial lookup'
      )
      t.comment(
        `candidate-order=${candidateOrder} initial lookup=${initialRouting.lookupPair.middleRole}->${initialRouting.lookupPair.exitRole} ` +
          `announce=${initialRouting.announcePair.middleRole}->${initialRouting.announcePair.exitRole}`
      )
      const firstExitCounts = new Map(
        exitRoles.map((role) => [role, firstRoutingSnapshots.get(role).ordinaryRequestCount])
      )
      t.is(initialRouting.standbyExits.length, 1, 'one exit is inactive standby')
      t.is(initialRouting.standbyMiddles.length, 1, 'one middle is inactive standby')
      const cancelPhase = nextPhase('endpoint')
      phases.set('endpoint', cancelPhase)
      control.setPhase('endpoint', endpointGeneration, cancelPhase)
      await control.send(
        'endpoint',
        command('endpoint', 'immutable-get', cancelPhase, { target: topology.oracle.targetHash })
      )
      const cancelled = control.expect('endpoint', 'cancelled', endpointGeneration)
      await control.send(
        'endpoint',
        command('endpoint', 'cancel', cancelPhase, { operationSequence: 2n })
      )
      t.is((await cancelled).operationSequence, 2n, 'delayed lookup cancels without retry')

      const healthyGeneration = readyEndpointSnapshot.lookupGeneration
      await new Promise((resolve) => setTimeout(resolve, HEALTHY_SILENCE_MS))
      const healthySnapshot = await sendAndWait('endpoint', 'snapshot', 'snapshot')
      t.is(
        healthySnapshot.lookupGeneration,
        healthyGeneration,
        'healthy silent lookup branch survives the native detector window'
      )
      t.is(
        healthySnapshot.announceGeneration,
        readyEndpointSnapshot.announceGeneration,
        'healthy silent announce branch survives the native detector window'
      )

      const rotatePhase = nextPhase('endpoint')
      phases.set('endpoint', rotatePhase)
      generations.set('endpoint', 2n)
      const rotationEvent = control.expectEvent('endpoint', 'rotated', 2n, rotatePhase)
      const blackholeStartedAt = hrtime.bigint()
      const faultAcknowledged = await sendAndWait(
        initialRouting.lookupPair.middleRole,
        'blackhole',
        'ready'
      )
      t.is(
        faultAcknowledged.state,
        'READY',
        `${initialRouting.lookupPair.middleRole} silently drops route cells`
      )
      const rotated = await rotationEvent
      t.is(rotated.previousGeneration, endpointGeneration)
      t.ok(
        hrtime.bigint() - blackholeStartedAt <= BigInt(BLACKHOLE_ROTATION_BOUND_MS) * 1_000_000n,
        'native detector rotates the blackholed branch within the process deadline'
      )
      const secondValueWaiting = control.expect('endpoint', 'value', 2n)
      await control.send(
        'endpoint',
        command('endpoint', 'immutable-get', rotatePhase, { target: topology.oracle.targetHash })
      )
      t.ok((await secondValueWaiting).value.equals(topology.oracle.immutableValue))
      const rotatedRoutingSnapshots = await routingSnapshots()
      const rotatedRouting = deriveRoutingState(rotatedRoutingSnapshots, firstExitCounts)
      t.comment(
        `candidate-order=${candidateOrder} rotated lookup=${rotatedRouting.lookupPair.middleRole}->${rotatedRouting.lookupPair.exitRole} ` +
          `announce=${rotatedRouting.announcePair.middleRole}->${rotatedRouting.announcePair.exitRole}`
      )
      t.not(
        `${rotatedRouting.lookupPair.middleRole}->${rotatedRouting.lookupPair.exitRole}`,
        `${initialRouting.lookupPair.middleRole}->${initialRouting.lookupPair.exitRole}`,
        'rotation changes the active lookup pair'
      )
      assertOptionalGrantUsage(
        rotatedRoutingSnapshots.get(rotatedRouting.lookupPair.exitRole),
        rotatedRouting.lookupPair.exitRole,
        'lookup after rotation'
      )
      for (const role of [initialRouting.lookupPair.exitRole, rotatedRouting.lookupPair.exitRole]) {
        const snapshot = rotatedRoutingSnapshots.get(role)
        t.ok(
          (snapshot.ordinaryRequestCount === 0 &&
            snapshot.tableEntryCount === 0 &&
            snapshot.referralProbeCount === 0) ||
            (snapshot.ordinaryRequestCount >= 1 && snapshot.tableEntryCount >= 1),
          `${role} is either retired cleanly or retains admitted request state`
        )
      }
      const announceSnapshot = rotatedRoutingSnapshots.get(rotatedRouting.announcePair.exitRole)
      const announceGrantResponder = learnedGrantResponders.find(
        (responder) => responder.role === rotatedRouting.announcePair.exitRole
      )
      t.is(
        announceGrantResponder.observedCount(),
        0,
        'coordinator observes no grant request on the state-derived announce exit'
      )
      t.is(announceSnapshot.isolatedGrantRequestCount, 0, 'announce reports no grant request')
      t.is(announceSnapshot.ordinaryRequestCount, 0, 'announce transports no application request')
      t.is(announceSnapshot.referralProbeCount, 0, 'announce probes no application referral')
      t.is(rotatedRouting.standbyExits.length, 1, 'rotation leaves one inactive exit standby')
      t.is(rotatedRouting.standbyMiddles.length, 1, 'rotation leaves one inactive middle standby')
      const rotatedEndpointSnapshot = await sendAndWait('endpoint', 'snapshot', 'snapshot')
      t.is(rotatedEndpointSnapshot.guardOnly, true)
      t.ok(
        rotatedEndpointSnapshot.lookupGeneration > readyEndpointSnapshot.lookupGeneration,
        `physical ${initialRouting.lookupPair.middleRole} fault publishes a fresh lookup generation`
      )
      t.is(
        rotatedEndpointSnapshot.announceGeneration,
        healthySnapshot.announceGeneration,
        'blackholed lookup replacement preserves the healthy announce generation'
      )

      const suspended = await sendAndWait('endpoint', 'suspend', 'suspended')
      t.is(suspended.type, 'suspended')
      const suspendedSnapshot = await sendAndWait('endpoint', 'snapshot', 'snapshot')
      t.is(suspendedSnapshot.activeOperations, 0)
      t.is(suspendedSnapshot.queuedBytes, 0)
      t.is(suspendedSnapshot.endpointSockets, 0, 'suspend closes endpoint socket ownership')
      t.is(suspendedSnapshot.guardOnly, false, 'suspend has no send-capable guard edge')
      const resumed = await sendAndWait('endpoint', 'resume', 'resumed')
      t.is(resumed.type, 'resumed')

      const resumedSnapshot = await sendAndWait('endpoint', 'snapshot', 'snapshot')
      t.is(resumedSnapshot.guardOnly, true, 'resume restores only the pinned guard edge')
      t.is(
        resumedSnapshot.endpointSockets,
        0,
        'resume transfers the reconnected bootstrap socket to the route'
      )
      t.ok(
        resumedSnapshot.lookupGeneration > rotatedEndpointSnapshot.lookupGeneration,
        'resume installs a fresh lookup generation'
      )
      t.ok(
        resumedSnapshot.announceGeneration > rotatedEndpointSnapshot.announceGeneration,
        'resume installs a fresh announce generation'
      )
      const resumedValueWaiting = control.expect('endpoint', 'value', 2n)
      await control.send(
        'endpoint',
        command('endpoint', 'immutable-get', phases.get('endpoint'), {
          target: topology.oracle.targetHash
        })
      )
      t.ok((await resumedValueWaiting).value.equals(topology.oracle.immutableValue))

      // Gate C: required SURB reply path over the live eleven-role mesh.
      // Exit emits hop cells only; middle and guard peel with their own secrets;
      // endpoint admits terminals. No correlated reverse frames.
      const surbRoutingBefore = await routingSnapshots()
      const surbExitCounts = new Map()
      for (const role of exitRoles) {
        surbExitCounts.set(role, surbRoutingBefore.get(role).ordinaryRequestCount)
      }
      const correlatedBefore = new Map()
      for (const role of exitRoles) {
        correlatedBefore.set(role, surbRoutingBefore.get(role).correlatedFrameCount || 0)
      }
      const surbValue = await sendAndWait('endpoint', 'surb-get', 'value', {
        target: topology.oracle.targetHash
      })
      t.ok(
        surbValue.value.equals(topology.oracle.immutableValue),
        'surb-get returns the exact oracle value over the SURB path'
      )
      const surbRoutingAfter = await routingSnapshots()
      const surbRouting = deriveRoutingState(surbRoutingAfter, surbExitCounts)
      const surbMiddle = surbRoutingAfter.get(surbRouting.lookupPair.middleRole)
      const surbExit = surbRoutingAfter.get(surbRouting.lookupPair.exitRole)
      // Guard peels on the shared guard role.
      const surbGuard = await sendAndWait('guard', 'snapshot', 'snapshot')
      t.ok(
        surbMiddle.surbHopsPeeled >= 1,
        'lookup middle peeled at least one SURB hop with its own authority'
      )
      t.ok(
        surbGuard.surbHopsPeeled >= 1,
        'guard peeled at least one SURB hop with its own authority'
      )
      t.ok(surbExit.surbHopCellCount >= 1, 'lookup exit emitted at least one SURB hop cell')
      t.is(
        surbExit.correlatedFrameCount,
        correlatedBefore.get(surbRouting.lookupPair.exitRole) || 0,
        'SURB path adds no correlated reverse frames on the lookup exit'
      )

      // Live announce-branch coverage. The in-process harness delivers no announce
      // seed frames, so a routed put is exercised only here: an immutable put and a
      // mutable put travel the announce branch to the exit that answered the
      // announce-context query, land on the DHT roles, and read back exact over the
      // lookup branch. Placed after every routing derivation above, because a put
      // grows the announce exit's ordinary request count and `deriveRoutingState`
      // tells the lookup pair apart by exactly that growth.
      const announceExitRole = surbRouting.announcePair.exitRole
      const announceBaseline = surbRoutingAfter.get(announceExitRole)
      const routedValue = b4a.alloc(1023, 0x5c)
      const routedTarget = cryptoSuite.hash([routedValue])
      const mutableSeed = b4a.alloc(32, 0x5a)
      const mutableKeyPair = cryptoSuite.keyPair(mutableSeed)
      const mutableTarget = cryptoSuite.hash([mutableKeyPair.publicKey])
      // The storage oracle admits exactly these two records on the DHT roles from
      // here on; anything else a DHT role reports holding still fails the audit.
      auditor.expectRoutedRecords({ mutableTargets: [mutableTarget], valueDigests: [routedTarget] })
      const storedRouted = await sendAndWait('endpoint', 'immutable-put', 'stored-routed', {
        value: routedValue,
        replyMode: 'SURB_REQUIRED'
      })
      t.ok(storedRouted.target.equals(routedTarget), 'routed immutable put reports the value hash')
      const immutableExit = await sendAndWait(announceExitRole, 'snapshot', 'snapshot')
      t.ok(
        immutableExit.surbHopCellCount > announceBaseline.surbHopCellCount,
        'the maximum immutable put was answered over the SURB path'
      )
      t.is(
        immutableExit.correlatedFrameCount,
        announceBaseline.correlatedFrameCount,
        'the immutable put adds no correlated reverse frame on the announce exit'
      )
      const routedBack = await sendAndWait('endpoint', 'immutable-get', 'value', {
        target: storedRouted.target
      })
      t.ok(routedBack.value.equals(routedValue), 'announce-branch immutable put reads back exact')
      const mutableValue = b4a.alloc(895, 0x5b)
      const storedMutable = await sendAndWait('endpoint', 'mutable-put', 'stored-routed', {
        seed: mutableSeed,
        seq: 1n,
        value: mutableValue,
        replyMode: 'SURB_REQUIRED'
      })
      t.ok(
        storedMutable.target.equals(mutableTarget),
        'routed mutable put reports the record target'
      )
      const mutableExit = await sendAndWait(announceExitRole, 'snapshot', 'snapshot')
      t.ok(
        mutableExit.surbHopCellCount > immutableExit.surbHopCellCount,
        'the maximum mutable put was answered over the SURB path'
      )
      t.is(
        mutableExit.correlatedFrameCount,
        immutableExit.correlatedFrameCount,
        'the mutable put adds no correlated reverse frame on the announce exit'
      )
      const mutableBack = await sendAndWait('endpoint', 'mutable-get', 'mutable-value', {
        publicKey: mutableKeyPair.publicKey
      })
      t.is(mutableBack.seq, 1n, 'announce-branch mutable put reads back at its sequence')
      t.ok(mutableBack.value.equals(mutableValue), 'announce-branch mutable put reads back exact')
      // Which DHT role holds the records is the DHT's placement, not the harness's;
      // that at least one of them reports each record is what proves the put landed.
      const recordHolders = []
      for (const role of ['dht-seed', 'dht-referral', 'dht-value']) {
        recordHolders.push(await sendAndWait(role, 'snapshot', 'snapshot'))
      }
      t.ok(
        recordHolders.some((snapshot) =>
          snapshot.storedValueDigests.some((d) => d.equals(routedTarget))
        ),
        'a DHT role holds the routed immutable value'
      )
      t.ok(
        recordHolders.some((snapshot) =>
          snapshot.mutableRecordTargets.some((d) => d.equals(mutableTarget))
        ),
        'a DHT role holds the routed mutable record'
      )

      // Gate D presence over the live routed record commands (decisions D10–D12): the
      // endpoint publishes a blinded presence record on the announce branch (one
      // mutable put per publication period) and resolves it back over the lookup
      // branch, both in required SURB reply mode, so neither the put's token query,
      // its commit acknowledgement, nor the read's reply travels the correlated
      // path. The coordinator's wall time is sent with both commands so both ends
      // derive the same periods; the storage oracle admits exactly the blinded
      // targets. The proof is the same on each branch's exit: hop cells grew and
      // correlated frames did not. One round trip per exit is all a baseline needs;
      // a full routing snapshot here is eleven round trips inside the
      // timing-sensitive tail.
      const presenceSeed = b4a.alloc(32, 0x7d)
      const presenceReader = b4a.alloc(32, 0x7e)
      const presenceIdentity = cryptoSuite.keyPair(presenceSeed)
      const presenceDescriptor = b4a.from(`blinded presence (${launch.runtime})`)
      const presenceNow = BigInt(Date.now())
      const presencePeriods = publishPeriods(Number(presenceNow))
      const presenceKeys = presencePeriods.map((period) =>
        deriveBlindedPublicKey(presenceIdentity.publicKey, period)
      )
      auditor.expectRoutedRecords({
        mutableTargets: presenceKeys.map((key) => cryptoSuite.hash([key])),
        valueDigests: []
      })
      const published = await sendAndWait('endpoint', 'presence-publish', 'presence-published', {
        seed: presenceSeed,
        readerSecret: presenceReader,
        revision: 1n,
        descriptor: presenceDescriptor,
        now: presenceNow,
        replyMode: 'SURB_REQUIRED'
      })
      t.is(published.revision, 1n, 'presence published at revision 1')
      t.alike(
        published.publicKeys,
        presenceKeys.slice().sort((left, right) => b4a.compare(left, right)),
        'the endpoint published under exactly the blinded keys of the publication periods'
      )
      const publishExit = await sendAndWait(announceExitRole, 'snapshot', 'snapshot')
      t.ok(
        publishExit.surbHopCellCount > mutableExit.surbHopCellCount,
        'the presence publication was answered over the SURB path'
      )
      t.is(
        publishExit.correlatedFrameCount,
        mutableExit.correlatedFrameCount,
        'the presence publication adds no correlated reverse frame on the announce exit'
      )
      const presenceBaseline = await sendAndWait(
        surbRouting.lookupPair.exitRole,
        'snapshot',
        'snapshot'
      )
      const resolved = await sendAndWait('endpoint', 'presence-resolve', 'presence-state', {
        identityPublicKey: presenceIdentity.publicKey,
        readerSecret: presenceReader,
        now: presenceNow,
        replyMode: 'SURB_REQUIRED'
      })
      t.is(resolved.present, true, 'presence resolves present over the SURB path')
      t.is(resolved.revision, 1n, 'presence resolves at its revision')
      t.ok(resolved.descriptor.equals(presenceDescriptor), 'presence descriptor is exact')
      t.ok(
        presencePeriods.includes(resolved.period),
        'presence resolves from one of the publication periods'
      )
      // No rotation since the surb-get derivation, so the lookup exit is the same role;
      // the put above grew the announce exit's count, which is why no re-derivation.
      const presenceExit = await sendAndWait(
        surbRouting.lookupPair.exitRole,
        'snapshot',
        'snapshot'
      )
      t.ok(
        presenceExit.surbHopCellCount > presenceBaseline.surbHopCellCount,
        'the presence read was answered over the SURB path'
      )
      t.is(
        presenceExit.correlatedFrameCount,
        presenceBaseline.correlatedFrameCount,
        'the presence read adds no correlated reverse frame on the lookup exit'
      )

      // Revocation publishes period tombstones through the same required-mode
      // write path. Prove storage changed, rather than only checking forwarded options.
      await sendAndWait('endpoint', 'presence-revoke', 'presence-published', {
        seed: presenceSeed,
        readerSecret: presenceReader,
        revision: 2n,
        now: presenceNow,
        replyMode: 'SURB_REQUIRED'
      })
      const revokeExit = await sendAndWait(announceExitRole, 'snapshot', 'snapshot')
      t.ok(
        revokeExit.surbHopCellCount > publishExit.surbHopCellCount,
        'presence revocation was answered over the SURB path'
      )
      t.is(
        revokeExit.correlatedFrameCount,
        publishExit.correlatedFrameCount,
        'presence revocation adds no correlated reverse frame on the announce exit'
      )
      const absent = await sendAndWait('endpoint', 'presence-resolve', 'presence-state', {
        identityPublicKey: presenceIdentity.publicKey,
        readerSecret: presenceReader,
        now: presenceNow,
        replyMode: 'SURB_REQUIRED'
      })
      t.is(absent.present, false, 'revoked presence no longer resolves present')
      t.is(absent.revision, 2n, 'the resolver observes the tombstone revision')
      const revokeReadExit = await sendAndWait(
        surbRouting.lookupPair.exitRole,
        'snapshot',
        'snapshot'
      )
      t.ok(
        revokeReadExit.surbHopCellCount > presenceExit.surbHopCellCount,
        'the tombstone read was answered over the SURB path'
      )
      t.is(
        revokeReadExit.correlatedFrameCount,
        presenceExit.correlatedFrameCount,
        'the tombstone read adds no correlated reverse frame on the lookup exit'
      )

      if (productionEndpointPunch) {
        // The first-send replies were taken before the peer's packets could have
        // crossed a real NAT, and the rounds ran on for three seconds. Asked only
        // here: an idle of two seconds before the first routed get fails the
        // unmodified scenario (KI-17), and a pause after it moves the blackhole
        // rotation past its process deadline, so nothing above may wait on this.
        const guardStats = await control.natStats('guard')
        const endpointStats = await control.natStats('endpoint')
        t.comment(
          `production punch guard sent=${guardStats.sent} received=${guardStats.received} ` +
            `stray=${guardStats.strayReceived}; endpoint sent=${endpointStats.sent} ` +
            `received=${endpointStats.received} stray=${endpointStats.strayReceived}`
        )
        t.ok(
          guardStats.received > 0 || endpointStats.received > 0,
          'at least one punch direction crossed'
        )
      }

      const unavailable = await sendAndWait('endpoint', 'network-change', 'unavailable')
      t.is(unavailable.reason, 'NETWORK_CHANGE')
      const networkChangedSnapshot = await sendAndWait('endpoint', 'snapshot', 'snapshot')
      t.is(networkChangedSnapshot.endpointSockets, 0, 'network change leaves no endpoint socket')
      t.is(networkChangedSnapshot.guardOnly, false, 'network change installs no fallback edge')
      // We cannot test guard-loss after network-change because network-change is terminal.
      // KI-11. Advancing a role's expected phase while one of that role's own events is
      // still unread makes the event stale: `baseMessage` compares the two phases for
      // exact equality, control-channel.js:964, and `dispatch` reports any validation
      // failure as PROCESS_PHASE_MISMATCH, coordinator.js:343-348. The exits are the only
      // roles that still speak unprompted by the time we get here - every other event in
      // the scenario answers a command, and the endpoint's autonomous `rotated` and
      // `unavailable` both need state READY, which the terminal network-change above left
      // as UNAVAILABLE - so the window is an `isolated-grant-request` overtaking the loop
      // below. Provoked deliberately, and shown closed, by
      // test/private/process/teardown-phase-window-probe.js.
      //
      // Stop ANSWERING first. This is hygiene, not the fix: the request is emitted by the
      // exit on its own schedule, so nothing done on this side can unsend a frame already
      // in the pipe. It earns its place for a different reason - a grant answered after
      // the advance throws synchronously out of `respondIsolatedGrant`, see the responder
      // above - and because an exit handed a grant mid-teardown restarts the very
      // discovery that emits the next request. Nothing below needs a grant responder:
      // the role snapshots above prove no request is pending, and the six grants per
      // pool cover any optional discovery during the completed lifecycle.
      // An unanswered request is expected on the role side too, `stopOwners` rejects a
      // pending one with PROCESS_CANCELLED before destroying the exit service,
      // role-runner.js:816-821, so it cannot wedge the stop below.
      for (const responder of learnedGrantResponders) responder.stopGranting()
      const exits = []
      const snapshots = []
      const closed = []
      for (const role of ROLES) {
        // The fix: a round trip at the phase already in force, which the runner accepts
        // because it adopts whatever phase a command carries, role-runner.js:968 - the
        // same reuse the two `immutable-get`s above rely on. A role's events reach us as
        // one FIFO stream decoded in order, so once this snapshot has been dispatched
        // every frame that role emitted earlier has been dispatched too, under the phase
        // it was emitted with. Only then is the phase advanced. What remains is one round
        // trip wide instead of the whole loop wide, and with granting stopped an exit that
        // does emit inside it cannot be given a grant and so cannot emit a second.
        await sendAndWait(role, 'snapshot', 'snapshot', {}, phases.get(role))
        const generation = generations.get(role)
        const stopPhase = nextPhase(role)
        control.setPhase(role, generation, stopPhase)
        snapshots.push(control.expect(role, 'snapshot', generation))
        closed.push(control.expect(role, 'closed', generation))
        exits.push(control.expectExit(role))
        await control.send(role, command(role, 'stop', stopPhase))
      }
      const finalSnapshots = await Promise.all(snapshots)
      await Promise.all(closed)
      const exitResults = await Promise.all(exits)
      for (const snapshot of finalSnapshots) {
        t.is(snapshot.state, 'CLOSED')
        t.is(snapshot.activeOperations, 0)
        t.is(snapshot.openResources, 0)
        t.is(snapshot.queuedBytes, 0)
      }
      for (const result of exitResults) t.is(result.code, 0)
      await control.close()
      // Every role has exited, so the capture is complete and the wire record
      // covers the whole lifecycle including the failure paths.
      if (placement) await placement.audit(t)
    } catch (err) {
      t.fail(err && err.message ? err.message : String(err))
    } finally {
      for (const responder of learnedGrantResponders) responder.stop()
      if (!control.closed) await control.cancel('TEARDOWN').catch(() => {})
      if (placement) placement.teardown()
      topology.stop()
    }
  })
}

module.exports = registerLiveProcessSuite
