# Private Routing Implementation and Migration Record

## Status and scope

This record covers the experimental Gate 3A substrate, the owner-approved Gate
3B1 live routing implementation through Task 17, subsequent routed-DHT, SURB,
and blinded-presence work, and the later alpha peer-stream cutover. It is not a
production anonymity claim. The reviewed native route stack remains
package-private; the peer alpha is a separate HyperDHT-native fixed-cell circuit
runtime described below and in the README.

Direct behavior remains the default. Supplying the exact acknowledged
`privateRouting` option adds a separate `dht.privateRouting` context while
ordinary `dht.connect()`, `dht.createServer()`, DHT records, queries, and
routing-table behavior remain direct. Relay participation is an explicit,
mutually exclusive role. The peer alpha `standard` profile uses a four-relay
compiled path, period-blinded destination-signed descriptors, quorum storage
and readback, authenticated 1200-byte hop transformation, entry multiplexing,
bounded per-link accounting, and end-to-end Noise. It does not instantiate or
claim completion of the full reviewed peer-tail/UDX adjacency, shared global
quota, ARQ, or legacy-egress design.

The historical canonical design is [Private Routing Protocol v1](private-routing-v1.md).
The current peer API contract is the README's
[ALPHA private peer routing](../README.md#alpha-private-peer-routing) section.
The eleven-role Node/Bare and privileged Linux evidence below applies to the
package-private routed-DHT stack at the cited revisions, not automatically to
the later peer alpha. A global passive observer and timing correlation by
colluding guards and exits remain outside the guarantees; no cover traffic
exists. Accepted limitations are tracked under [Known issues](#known-issues).

### Current implementation

The current alpha peer implementation on `implement-private-peer-v2`
supersedes the published
[`0b2df5a`](https://github.com/ayooooo123/hyperdht/commit/0b2df5a)
checkpoint. The earlier checkpoint made destination admission ephemeral until
resolver exclusion and destination-role reservation completed. The current v3
wire and `standard` profile additionally:

- keep ordinary HyperDHT peer APIs direct; private peer behavior remains an
  explicit selection through the frozen `dht.privateRouting` facade;
- require the exact `profile: 'standard'` option and compile two
  source-selected safety relays plus a destination-selected entry and guard,
  with all four advertised relay identities distinct;
- sign each descriptor with the period-blinded destination key and omit the
  stable destination application key from descriptor bytes;
- require at least three successful descriptor replicas and an exact
  two-reply signed readback quorum before publication commits;
- stage guard-authenticated entry registration and install it only after the
  descriptor publication quorum succeeds and the guard sends `ENTRY_COMMIT`;
- retain ephemeral destination admission, resolver-before-key disclosure, and
  mutual reservation between resolver, destination-guard, and entry roles;
- recover signed previous-generation state through the admitted destination
  guard, so initial publication, restart, and refresh send descriptor GET and
  PUT traffic only from that guard;
- authenticate, open, account, and reseal every fixed STREAM cell at every
  relay hop, using fresh adjacent route contexts rather than transparent stream
  joins;
- bound pending cell sends, receive buffering, asynchronous transform backlog,
  lifetime stream IDs, per-stream frames, and per-stream bytes, with separate
  send and receive peer-ledger charges on every link;
- multiplex independent end-to-end Noise/SecretStream sessions over one
  destination circuit; and
- keep logical FIN/RESET retirement idempotent and stream-scoped, retaining
  retired IDs until circuit teardown so late DATA in either direction cannot
  destroy sibling sessions.

Current local verification on 2026-09-13:

- focused peer protocol behavior passes Node and Bare with 5/5 tests and 78/78
  assertions per runtime;
- the complete private aggregate passes Node 1,299/1,299 with 23,190/23,190
  assertions and Bare 1,254/1,254 with 23,055/23,055 assertions;
- changed-file Prettier and `git diff --check` pass;
- the portable eleven-process routed-DHT scenario does not start: both attempts
  fail at `lookup-exit-b/CONTROL` with `PROCESS_BIND_UNAVAILABLE`. No stale
  `runtime-node.js` process or owner of `127.64.5.1:42005` was present after the
  failure. This is not recorded as peer-v3 behavior evidence and does not
  replace Linux packet capture.

The earlier routed-DHT implementation checkpoint is
[`cae9721`](https://github.com/ayooooo123/hyperdht/commit/cae9721f946b4d3b2b8adcb61b3230332371e830),
published to `private-routing-v1` on 2026-09-09, followed on the same branch by
the KI-4 offer-admission repair described below:

- **Routed DHT and Gate C:** immutable/mutable get and put support explicit
  `replyMode: 'SURB_REQUIRED'` behind `experimentalSurbReplies: true`.
  Defaults remain correlated; mutable-get refresh cannot use required replies.
  Required-mode holds cover query construction, retries, and commit, and are
  released on every attempt's cleanup. SURB replies use relay-local peeling
  through the route's own reverse relays, not an independent or mixed path.
- **Gate D and D12:** the blinded-presence client publishes, resolves, and
  revokes over mutable records using its configured reply mode. The live
  scenario proves required-mode maximum-size puts, exact readback, publication,
  and resolution to authenticated absence after a period-scoped tombstone at a
  higher revision, without additional correlated reply frames on the relevant exit.
- **Protocol scope:** Gate D supersedes the stable-key, plaintext-topic
  private-storage overlay for presence. Its old object/command and storage-session
  IDs stay reserved and rejected. Routed public `lookup`, `findPeer`,
  `announce`, `unannounce`, and raw `query` are not v1 commands; adding them is
  not unfinished implementation of an already approved wire.
- **Verification:** all ten local gates passed on that source/test tree,
  followed by native-Linux private-routing CI and the Linux/macOS/Windows build
  matrix. See the [measurements](#gate-3b1-task-17-live-eleven-process-scenario-status)
  and [publication evidence](#continuation-checkpoint--2026-09-09-required-mode-puts-and-v2-allocation).

**Open gates:** the alpha peer runtime still needs Linux packet-capture
acceptance and external human cryptographic review before any production
anonymity claim. The full reviewed peer-tail/UDX adjacency runtime, shared
global quota ledger, ARQ/retransmission, legacy egress, Hyperswarm, mobile, and
PearTube integration remain unimplemented. KI-4's routed-DHT responder-side
offer admission is repaired under the reviewed cross-host time contract, but
four later real-link dispatches stopped before LINK_OFFER; none confirms that
repair on real links. Further useful evidence needs a reachable multi-host
placement, not a relaxed protocol check. KI-1 timing/volume correlation and
KI-5 operator diversity remain explicit limits; mixing/cover traffic is
deferred and anonymous-admission Gate A is dropped.

**External review acceptance:** an internal model report is not the required
external human cryptographic review. The review must identify its author,
the exact source and native dependency revisions, the reviewed Gate C and Gate D
transcripts, findings and their disposition, and a signed-off re-review of
repairs. Include the single-use SURB replay/key ownership, deadline domains,
reply-mode binding, blinded-key derivation, record signatures, rollback,
tombstones, and the stated linkability limits. Any added peer-stream wire and
key schedule must be included in that review before public exposure. Current
source, regression cases, Linux capture evidence, and earlier internal findings
are review inputs, not substitutes for that report. No external reviewer or
completed engagement is identified in the project record.

**Remaining-work verification — 2026-09-09 (`06dc259` source):**

- Native CI previously omitted the Node and Bare production endpoint-punch
  scenarios present in `scripts/linux-gates.sh all`. Both steps are now added
  to `test-private-routing.yml`, with the same normal candidate order and
  `PR_PRODUCTION_ENDPOINT_PUNCH=1`. Both commands passed in the Linux gate
  runner, 180 assertions each. At `9857887`, native push run
  [34413408100](https://github.com/ayooooo123/hyperdht/actions/runs/34413408100)
  passed. PR run
  [34413413038](https://github.com/ayooooo123/hyperdht/actions/runs/34413413038)
  passed the punch steps but failed namespace capture at 184/185:
  `ERR_TEARDOWN_ICMP: raw DROP=1, classified=0`. This failed evidence remains
  open as KI-19; it is not a production-punch failure or an approved exception.
  Both Private Routing runs at correction commit `819cc62`
  ([push](https://github.com/ayooooo123/hyperdht/actions/runs/34413788764),
  [PR](https://github.com/ayooooo123/hyperdht/actions/runs/34413792450))
  passed; [Build Status](https://github.com/ayooooo123/hyperdht/actions/runs/34413792433)
  also passed. These subsequent passes do not explain or erase KI-19.
- Mixed-host run [34410082928](https://github.com/ayooooo123/hyperdht/actions/runs/34410082928)
  used `up -p -l 2` without overrides. Punch matrix 0/117; role 4
  (`lookup-exit-a`) never attached, `HOLEPUNCH_ABORTED`; driver exit 1.
- The launcher's all-runner fallback,
  [34411036338](https://github.com/ayooooo123/hyperdht/actions/runs/34411036338),
  used `up -p` without overrides at `06dc259`. Role 5 could not be reached
  for punching; the nine reporting roles returned 6/105 directed pairs,
  99 silent. Endpoint role 1 never attached; driver exit 1. The denominator
  excludes the absent role report, so this is not a 6/117 complete matrix.
- Both remote allocations were cancelled after the drivers failed. No private
  link setup or lifecycle result was reached. These are reachability failures;
  the precise underlying NAT or network cause is not established. Operator
  addresses remain outside the repository and vault.
- Final local verification ran once, uninterrupted, with
  `bash scripts/linux-gates.sh all`. The Docker context is not established
  by the retained invocation evidence; do not attribute this run to the
  separately clock-probed VM.
  All ten gates passed: Node private aggregate 1,099 tests / 19,762 assertions;
  Bare private aggregate 1,054 / 19,627; four normal/reverse process legs
  175 assertions each; two production-punch legs 180 each; namespace projection
  27; namespace live capture 185 with raw DROP zero.
- A disposable VM was separately created without activating its Docker context.
  External NTP was paused there only. Its 45-second wall/monotonic probe
  measured −0.419793 to +0.001376 ms drift. This probe does not establish
  the clock behavior of the unlocated full-gate run. A later context-specific
  container check is not evidence of that run's placement. The disposable VM
  was deleted; shared services were not restarted. This corrects the unsupported
  VM attribution published in `9857887`.
  This correction concerns this continuation's `hyperdht-gates-finish` profile,
  not the distinct `hyperdht-gates-ki4` run reported in the earlier `74875ec`
  checkpoint; that prior session's placement was not re-audited here.
- Repository-wide Prettier passed separately. Runtime-exported bounds were
  checked directly: advertisement 260–388 bytes, presence descriptor 814,
  inner route payload 1,073, outer cell 1,200. No peer-stream implementation
  or new wire was included in these results.

## Implementation history

The checkpoints below preserve the state, measurements, failures, and decisions
at their recorded dates and commits. Their old “remaining work” lists and
uncommitted-state descriptions are historical, not instructions for the current
tree. Use [Current implementation](#current-implementation) for current scope
and open gates. Historical and rejected experiments are not accepted runtime.

### Continuation checkpoint — 2026-09-05

Reviewed the accepted branch through `6468028`, the current live owners, gate
scripts, and prior review records. The next completed work is verification
hardening, not a new public routing feature:

- The local `all` runner now includes normal and reversed candidate order under
  both Node and Bare role runtimes, like CI.
  Each process gate explicitly sets its order. Running all four process gates
  with the caller exporting either `normal` or `reverse` produced
  `normal, normal, reverse, reverse`; all eight runs passed 136 assertions each.
- The blackhole scenario uses monotonic elapsed time and checks both healthy
  idle generations plus preservation of the announce generation during lookup
  replacement.
- An isolated mutation that suppresses `runLiveness` timeout closure, while
  leaving PING scheduling intact, fails the native scenario with
  `PROCESS_COMMAND_DEADLINE` after the blackhole is armed. The unmodified
  scenario passes. Lease-only recovery cannot substitute for the native detector.
- KI-10 and the historical branch-liveness proposal now name the existing
  detector. KI-14's headline now reflects preferred-tier selection on all three
  construction paths, without implying hard exclusion in small pools.
- Fork CI exposed a guard authentication failure at resume. Preserved source
  stacks and deterministic signed-message regressions identified a clock-skew
  rejection in both handshake completion paths. KI-4 below records the fix:
  order peer timestamps against signed bounds, not another host's wall clock.

KI-10 refused-loss redelivery is now implemented: loss stays on its published
branch, physical and live-IO reports carry that generation, and a refused
controller wakeup is restored for delivery after the active rotation completes.
The focused regression proves both refusal paths without advancing the lease
clock, plus rejection of retired registrations and retiring-branch safety.

The active, experimental SURB reference now has wire-compatible key cleanup,
payload bounds, canonical X25519 public-key validation, and aggregate test
registration. A direct probe reproduced high-bit encoding malleability before
the fix and rejects it afterward. A four-hop fault probe also checks key
erasure across 115 injected native-hash failures. The deterministic fixture
still passes. This hardening does not activate Gate C: one-use ownership,
authenticated epoch and reply-mode binding, and production DATAGRAM integration
remain separate design/review work. See the
[reference hardening record](superpowers/specs/2026-08-10-private-routing-surb-construction-design.md#reference-hardening--2026-09-05).

After the advisory fixes and approved teardown classification, all eight local
Linux gates pass. Node passes **975 tests / 19,051 assertions**; Bare passes
**932 / 18,923**. All four normal/reverse process legs pass 136 assertions;
namespace projection passes 27; live namespace capture passes 146 with raw
DROP zero and classified ICMP zero. A delayed-close probe passes with three
raw drops and three classified replies. An injected ICMP echo fails as required.
See [KI-16](#ki-16-ordered-udp-shutdown-can-produce-kernel-icmp-drops).
These local container results do not replace fork-native CI or real NAT-host
evidence.

Remaining work, in dependency order:

1. **KI-13 production NAT traversal:** design and review the production owner
   path for same-socket reflection, signed plan creation/distribution, topology
   and run binding, replay limits, and mapping lifetime. Then prove authenticated
   route startup across real NAT'd hosts without harness pre-punching. The
   isolated NAT branch's positive worker report is not acceptance evidence.
2. **Gate C and private-presence/Gate D:** meet their protocol and cryptographic
   review gates, then integrate the actual reply and record paths. The reverted
   and rejected branches are not completed implementations. Gate D still needs
   a vetted native scalar multiplication path for full blinded-key signing.
3. **Complete Gate 3B:** remaining DHT commands, private presence, and peer
   streams need reviewed end-to-end implementations. Public required mode must
   remain disabled until all aggregate criteria below pass together in CI.
4. **Consumer integration:** Hyperswarm, mobile, and PearTube follow the public
   controller gate. Real-device and real-network evidence cannot be replaced by
   the local container gates.

KI-1 timing/volume correlation and KI-5 operator diversity remain explicit
limits. This checkpoint adds no production constructor, protocol, or anonymity
claim. Current local measurements are in the Task 17 table below.

### Continuation checkpoint — 2026-09-06

Two internal architecture reviews (KI-13 production NAT ownership; Gate C SURB
lifecycle) and one dependency build were completed, and the two reviewed
experimental slices were implemented. Neither review is external
cryptographic review, and nothing here enables public required mode.

**KI-13 production NAT ownership.** The review found that active production
code creates no topology grants (`signTopologyGrant` is only called by the
process fixture), that the archived `924fd55` proposal inherits a test trust
root and reflects through a raw socket that is closed and rebound, and that a
general plan signer accepting caller tuples would be a UDP redirection
service. Seat decisions, recorded here for owner review: (D1) a plan is signed
by both adjacent identities over one canonical body, with no central signer;
(D2) plans travel only over an existing authenticated pre-link control path,
otherwise the adjacency fails closed; (D3) IPv4 and IPv6 through the topology
address codec; (D4) a successful punch never authorizes a link or readiness;
(D5) plan validity is bounded by the link deadline and both reflection claims,
at most 15 s; (D6) test topology grants stay test-only. Implemented:
`lib/private/nat-reflect.js` (probe/observation codec and endpoint-bound
reflection claims; two distinct identity-pinned reflectors must agree; never
holds a socket), `lib/private/nat-punch-plan.js` (canonical plan codec,
bilateral sign/verify, fixed punch-profile registry), a shared strict parser
in `dht-exit-wire.js`, and package-private
`createNatTraversalAuthority`/`reflectNatEndpoint`/`armNatPunch` on
`UdxCellEndpoint`. `armNatPunch` compares the plan against the live link
handle (grant digest, epoch, run, identities, roles, both tuples, expiry), the
live reflection claim for this socket generation, and a plan-ID tombstone
before charging or allocating a packet. Punch bytes are demultiplexed before
bootstrap parsing and never reach `BootstrapRequestTable`. Guard pinning and
endpoint close destroy all NAT state. `LinkBootstrapSession` consumes one
opaque attempt, arms its deadline first, starts LINK CREATE after the first
owned send, and cancels the attempt on OPEN, failure, close, and invalidation.
Focused tests: `nat-reflect` 9/17, `nat-punch-plan` 7/25, `nat-traversal`
6/33; the owned-file suites are unchanged. Review scenarios 19 and 27–29 need
live processes and are not covered locally. Not implemented: the production
plan producer/distributor over a pre-link channel, and the real-NAT run with
the harness punch disabled. KI-13 therefore remains open.

**Gate C SURB amendment.** Implemented in `lib/private/surb.js` as recorded in
the [design spec](superpowers/specs/2026-08-10-private-routing-surb-construction-design.md#ownership-amendment--2026-09-06):
per-hop context-bound key schedule with no context bytes on the wire, owned
one-use authorities, atomic in-hop replay admission, and an authenticated inner
reply envelope. 31 tests / 115 assertions. Reply-mode selection in the routed
request, batch framing, the 492-byte fragment profile, and exit/initiator
integration remain unimplemented and human-gated.

**Gate D dependency.** `crypto_core_ed25519_scalar_mul` was added to a local
checkout of `holepunchto/sodium-native` at `f566427` (npm 5.1.0) as a direct
libsodium binding with the upstream wrapper conventions (local commit
`5c10460`, patch at `/tmp/hyperdht-sodium-scalar-mul.patch`). Built with
`bare-make` for darwin-arm64; the full upstream suite passes under Node
(6,292 assertions) and Bare (6,282), plus independent checks
$(L-1)^2 \equiv 1$ and $(L-1)\cdot 2 \equiv L-2 \pmod L$. Not yet done: a
fork commit or release, prebuilds for the Linux gate image, the
`sodium-universal` override, and the record-transcript approval that the
design handoff below still requires. No JavaScript scalar arithmetic was
introduced.

**Routed immutable-put and mutable get/put (Gate 3B criterion 4, partial).**
An internal review (`glm-5.3`, full text at
`/tmp/hyperdht-routed-dht-commands-review.md`) confirmed that the frozen
`COMMANDS` ranges in `routed-dht.js` fit only fixed-width bodies:
`MUTABLE_GET_V1` is `target[32] || seq u64`; `IMMUTABLE_PUT_V1` is
`token[32] || target[32] || version u8 || len u16 || value[0..1023]`;
`MUTABLE_PUT_V1` adds `publicKey[32] || seq u64` before the value and a
64-byte signature after it, so the required-mode mutable value cap is
**895 bytes** (direct mode allows more; this asymmetry is now the contract).
Seat decisions taken as the review defaults: put replies are bare one-byte
acks with no token or closer nodes (209-byte reply, amplification 0); the exit
maps upstream `SEQ_REUSED`/`SEQ_TOO_LOW` to `ROUTED_ERROR.RECORD_CONFLICT` and
the controller surfaces `ERR_RECORD_CONFLICT`; no exit-side token state or
hash checks (the upstream node verifies signatures and hashes); a
refresh-capable `mutableGet` queries on the announce branch so its commit token
comes from the exit that will send the put; pure reads stay on the lookup
branch. Implemented across `dht-command-policy.js`, `query-context.js`,
`routed-dht.js` (per-command reply profiles and `targetOf`),
`opaque-destination.js` (announce referrals), `routed-dht-io.js`,
`live-route-authority.js`, `dht-exit-wire.js`, `dht-exit-destination-table.js`,
`dht-exit-io.js`, and `PrivateRoutingController.immutablePut/mutableGet/
mutablePut` with generation pinning and one restart on rotation. `findPeer`,
`lookup`, `announce`, `unannounce`, and raw `query` still fail closed. New
suites: `dht-exit-put` 3/24, `dht-exit-mutable-get` 3/18,
`live-mutable-and-put` 3/16. Not covered: a live announce-branch put end to
end (the in-process harness does not deliver announce seed frames), and the
lying-exit limitation stays a documented v1 limit.

After formatting, the eight local Linux gates were run on the combined tree.
Node aggregate passes **1,019 tests / 19,244 assertions**; Bare passes
**976 / 19,116**. Process legs pass 136 assertions each; namespace projection
27; live namespace capture 146 with raw DROP zero. One earlier
`process:bare:reverse` run failed with `ERR_PRIVATE_GUARD_UNAVAILABLE` from
the bootstrap deadline at 6.1 s while the container was also finishing the
aggregate; five immediate reruns of that gate, one of `process:bare`, and the
final full pass all succeeded. The no-punch bootstrap path is unchanged by
this checkpoint, so the failure is recorded as a load-related deadline expiry,
not explained. It should be watched in fork CI.

Remaining work is unchanged in shape: KI-13 plan distribution and real-NAT
proof; Gate C integration and human review; Gate D transcript approval,
dependency pin, and implementation; remaining DHT commands, presence, peer
streams; consumer integration.

### Continuation checkpoint — 2026-09-06, KI-13 plan distribution

The production plan producer and distributor were implemented after mapping the
real link lifecycle rather than the review packet's assumed one. Three facts
decided the shape. Topology grants are minted only by the process fixture and
reach roles over the coordinator control channel; no production owner mints
them yet. The endpoint opens its guard link inside `bootstrap-io.js` only after
a direct CAPS_QUERY / ACTIVE_CHALLENGE exchange with the guard, so any punch
for that edge must precede the FIRST bootstrap contact, not LINK CREATE.
Guard→middle and middle→exit links are dialed cold from
`wire-services.dial()` at route build and at every rotation, and a plan is
valid for at most 15 s, so no pre-negotiated plan can serve them.

Seat decisions, recorded for owner review beside D1–D6:

- **D7.** Endpoint↔guard is the only production-punched edge. Its plan
  travels over the topology owner's channel, the same authenticated channel
  that carries the topology grant; in the harness that is the coordinator,
  which relays opaque bytes and never signs. Relay↔relay cold dials have no
  pre-link channel, so under D2 a NAT'd middle or exit stays unsupported and
  fails closed. The harness keeps its own pre-punch for relay pairs and labels
  it test topology plumbing.
- **D8.** The endpoint's punch precedes its first bootstrap contact. The
  attempt is armed against a link handle the role authorizes from the same
  grant in its own `LinkDirectory`, runs standalone, and the controller starts
  only after the first owned punch send. OPEN transfers nothing from the punch.
- **D9.** Four-step bilateral exchange: `offerNatPunch` (initiator: header,
  its side, responder claim digest and nonce zero) → `counterNatPunch`
  (responder fills its claim digest and nonce, may only LOWER `expiresAt`,
  signs) → `completeNatPunch` (initiator checks the counter differs from its
  offer in exactly those fields, verifies the responder signature, signs, arms
  through `armNatPunch`) → `acceptNatPunch` (responder checks the plan's
  unsigned bytes and its own signature byte-for-byte, arms through
  `armNatPunch`, which verifies the initiator signature and every binding).

Implemented in `lib/private`: strict offer/counter codecs and the
allowed-difference comparator in `nat-punch-plan.js`; the four functions above
plus single-use pending tokens (bounded by `DEFAULT_MAX_NAT_PLANS`, expiring at
the offer window, revoked on guard pin, endpoint close, authority destroy and
link-handle close) in `udx-cell-endpoint.js`; the NAT authority now retains an
owned copy of the identity secret key and clears it on every revocation path;
`bindReflectedEndpointClaim` requires explicit reflectors (the hard-coded
`203.0.113.x` defaults were a production bypass and are gone); and
`prepareEndpointNatTraversal` in `endpoint-bootstrap-authority.js`, which binds
the endpoint's own socket before the controller starts, creates the NAT
authority on it from a second identity secret capability, and reflects.

Harness: optional `natTraversal.reflectors` projection field, guard
`endpointGrant`, control-channel commands `nat-reflect|offer|counter|plan|arm|start`
and events `nat-reflected|offer|counter|plan|armed|started`, coordinator
helpers, role-runner handlers, and the suite sequence guard reflect → endpoint
reflect → offer → counter → plan → arm → guard start → endpoint start →
endpoint activate. `nat-reflected` carries one `observed` string because the
leak oracle refuses any event field named `host` or `port`. `scripts/live-route.sh -p`
(`REMOTE_PEER_PRODUCTION_ENDPOINT_PUNCH=1`) removes the endpoint from the
harness punch cross-product and passes the two public bootstrap reflectors,
labelled by `hash(host:port)`. New local gates `process:node:punch` and
`process:bare:punch` run the portable loopback scenario with dht-seed and
dht-value as reflectors. Default runs send no NAT command and mint no NAT
projection field.

Evidence: `nat-negotiation` 11/19, `nat-traversal` 6/33, `process-codec`
21/416, `nat-control-messages` 2/49. `process:node:punch` passes 141/141: both
production reflections equal the minted tuples, the whole exchange took 33.7 ms
on loopback, both sides report a first owned punch send, at least one direction
crossed, and the endpoint then bootstrapped and completed the full lifecycle.
Loopback proves the frame path only.

First real-NAT dispatch, run
[34059354417](https://github.com/ayooooo123/hyperdht/actions/runs/34059354417),
all eleven roles on runners, `-p`: the harness punch matrix arrived on 96 of
117 directed pairs and every one of the 21 silent pairs involved
lookup-middle-b, which heard nothing from any role. Production reflection on
the final socket equalled the minted tuple on both NAT'd hosts (endpoint
`74.235.70.229:23569`, guard `135.119.236.51:32793`), so the close-and-rebind
hop preserved both mappings on those runners. The four-step exchange took
799.6 ms over the DHT control streams; both sides reported a first owned punch
send; the endpoint then bootstrapped to the guard, pinned it, and the first
routed immutable get was exact — with no harness punch on the endpoint's edge.
Two assertions failed. The crossing check read the counters immediately after
the first send, before the peer's packets could have crossed a real NAT; it now
reads them at the scenario tail. The blackhole rotation then missed the process
deadline; the only replacement middle was the role whose NAT admitted nobody,
which is consistent with the punch matrix but was not proven to be the cause.
The first `-p` drive also exposed a `live-route.sh` bug: an expanded word is
never an assignment prefix, so the flag is now exported.

Second dispatch, run
[34059905384](https://github.com/ayooooo123/hyperdht/actions/runs/34059905384),
on the corrected tree: this time the guard's runner and lookup-middle-b's
runner admitted nobody (punch matrix 77/117, every silent pair involving role 2
or role 5). The endpoint's production reflection again equalled its minted
tuple (`52.161.51.65:20489`), but the guard's did not: the probe socket had
been reflected at `48.217.251.100:10265` and the final socket, bound to the
same local port, was reflected at `:10267`. That is the close-and-rebind hop
the harness could never measure, measured: on that runner's NAT the mapping
did not survive the rebind, or the NAT allocates per socket. Production
behaved as designed — the guard's claim did not match its grant tuple, no plan
was offered, no punch byte was sent, and the run stopped at the reflection
assertion. Third dispatch, run
[34060254019](https://github.com/ayooooo123/hyperdht/actions/runs/34060254019):
the harness punch matrix arrived on 8 of 117 pairs and the run died in DHT
setup, before any production step. Three runs, three different outcomes from
runner placement alone; which runner draws a NAT that admits unsolicited peers
is not under the harness's control. The owner approved placing the guard on
the operator's machine (`-l 2`) on condition that its address never enters
this repository; the records below therefore name that host only as "the
operator host".

Fourth dispatch, run
[34061028552](https://github.com/ayooooo123/hyperdht/actions/runs/34061028552),
ten roles on runners and the guard on the operator host: harness punch matrix
117/117; production reflection equalled the minted tuple on the endpoint's
runner and on the operator host; the four-step exchange took 738.1 ms; both
sides made a first owned punch send; the endpoint bootstrapped through the
production-punched pair, pinned the guard, and the first routed immutable get
was exact; the initial routes, cancel, and healthy-silence checks all passed.
**That is the KI-13 real-NAT proof for the endpoint↔guard edge: bind once,
reflect the same socket, bilateral plan, punch from that socket, authenticated
link, no harness punch on that edge and no close-and-rebind after reflection.**
The run then failed at the blackhole rotation with `PROCESS_COMMAND_DEADLINE`,
as the first dispatch had. That was first read as loopback-tuned deadlines; the
later KI-17 diagnosis gives the likelier cause: the harness link service killed
every pre-armed standby accept five seconds after activation, and on runners
the punch exchange and real latency pushed the rotation past that. Fixed under
KI-17; not yet re-run remotely. A fifth
run with the coordinator's documented diagnostic overrides
(`PR_COMMAND_TIMEOUT_MS=20000`, `PR_SCENARIO_TIMEOUT_MS=120000`), run
[34061182110](https://github.com/ayooooo123/hyperdht/actions/runs/34061182110),
never reached the production steps: the runners' harness punch matrix arrived
on 10 of 117 pairs, as in the third run, and DHT setup failed. The remote
lifecycle after readiness — rotation under a blackhole across runners — is
therefore still unmeasured with the punched edge; it is a harness-deadline
question, not a NAT one.

After the KI-17 fixes (`7017cda`), two more guard-on-operator-host runs. Run
[34062727729](https://github.com/ayooooo123/hyperdht/actions/runs/34062727729):
matrix 117/117, reflection equal on both sides, exchange 648.9 ms, both first
sends, then the endpoint's `activate` missed the coordinator's 5 s command
deadline. Run
[34062848870](https://github.com/ayooooo123/hyperdht/actions/runs/34062848870),
identical except for the coordinator's documented diagnostic overrides
(`PR_COMMAND_TIMEOUT_MS=20000`, `PR_SCENARIO_TIMEOUT_MS=120000`): **141/141.**
Matrix 117/117; reflection equal on both sides; exchange 672.7 ms; punch
counters guard sent 6 / received 2, endpoint sent 2 / received 1, so both
directions crossed; the endpoint bootstrapped through the punched pair; exact
routed gets before and after rotation; the native detector rotated the
blackholed branch inside its own 5 s bound (assertion 53); suspend, resume,
network change and teardown all passed. That is the full eleven-role lifecycle
on real NAT with the production-punched endpoint↔guard edge, and the first
remote run to finish since the blackhole scenario was added. What the raised
override changed is only the coordinator's per-command wait: the protocol
bounds inside the run (bootstrap budget, rotation bound) were met unchanged.
The 5 s `COMMAND_TIMEOUT_MS` is therefore a loopback constant for remote runs
of the `activate` step; whether to give the remote driver its own value is a
harness decision, not a protocol one. Dispatching stopped after this run.

Two contract notes. The reflectors observe the endpoint's socket before guard
pinning; that is within the pre-guard exposure the security contract allows
for configured bootstrap contacts, but those sends bypass the bootstrap
exposure accounting, so the readiness report does not yet list them. The
reflector `identity32` is a label bound into the claim, not an authenticated
identity: dht-rpc pings are unauthenticated, and the claim's authority comes
from the socket owner observing agreement between two reflectors.

### Continuation checkpoint — 2026-09-06, Gate D records, exposure accounting, live put coverage

**Gate D dependency pinned.** The CI prebuilds of the sodium-native fork at
`5c10460` (run 34056613931, all fourteen targets) are committed on
`ayooooo123/sodium-native` branch `private-routing/scalar-mul-prebuilds` at
`562d642`, and `package.json` now carries an npm `overrides` entry pinning
`sodium-native` to that commit, so `sodium-universal` resolves the fork under
Node and Bare without a toolchain. The Linux gate image is keyed on
`package.json`, so it rebuilt; `crypto_core_ed25519_scalar_mul` is a function
inside it under both runtimes. No JavaScript scalar arithmetic exists in the
tree.

**Gate D records implemented on the approved transcript.**
`lib/private/blinded-presence.js` derives, natively only, the blinding scalar
$h = \text{reduce}(\text{SHA-512}(\text{domain} \| A \| \text{period} \| \text{length}))$,
the blinded key $A' = h\cdot A$ (`crypto_scalarmult_ed25519_noclamp`, point
validity checked) and, for the owner, $a' = h \cdot a \bmod L$
(`crypto_core_ed25519_scalar_mul` over the clamped expanded seed), with the
owner-side check $a' \cdot B = A'$. Signing under $a'$ is standard Ed25519
assembled from `scalar_reduce`, `scalarmult_ed25519_base_noclamp`,
`scalar_mul` and `scalar_add`, so any storage node verifies it with plain
`crypto_sign_verify_detached` under $A'$. Seat decisions recorded in the
module: the storage key is the DHT's own `generichash(A')` (the mutable
contract enforces `target = hash(publicKey)`, so a separate `k_e` domain is
not available); the owner signature over the complete record is the DHT
mutable signature itself (`mutableSignable{seq, value}` signed with the
blinded signer through `mutablePut`'s `signMutable` option); periods are one
day with a one-hour overlap (`publishPeriods` adds the next period inside the
last hour, `lookupPeriods` keeps the previous one for the first hour, exact
boundary milliseconds tested). The record is exactly 895 bytes (the mutable
cap): clear `version u8 || revision u32 || noncePrefix[16]`, then an
XChaCha20-Poly1305 body under a per-record reader key
$H(\text{domain} \| \text{readerSecret} \| A' \| \text{period})$ with associated
data $\text{domain} \| A' \| \text{version} \| \text{period} \| \text{revision}$,
carrying `type u8 || period u64 || tombstoneScope u8 || tombstoneTarget[32] ||
descriptorLength u16 || descriptor[814]` zero-padded and checked for zero
padding on open. Type, period, scope, target and length are therefore under
both the AEAD and the owner signature, which closes the rejected branch's three
faults: a reader-credential holder cannot flip descriptor↔tombstone without
$a'$, trailing zero bytes survive because the length is explicit, and the
overlap is executable. Verification derives $A'$ from the caller's identity and
period, never from the record; the header revision must equal the DHT `seq`;
rollback is `resolvePresenceState`: within the same period, a lower revision
or an equal revision with a different record digest is `REPLAY`. Identical
records can be polled again. Every returned state retains the period, revision,
and its own record digest, including tombstones. A `PERIOD` tombstone clears
presence; a `RECORD` tombstone clears it only when its target matches the
retained digest in the same period, or when polling that already accepted
tombstone. A mismatched target stays ignored. A higher revision in that period
can re-enable presence after a tombstone. Revisions from different periods
are not compared, but a record below the retained period is always `REPLAY`.
`lib/private/presence-client.js` is the production caller over
`controller.mutablePut` / `mutableGet` (publish, revoke, resolve across the
period lists; the reader credential is the client's configured secret and the
per-record key is derived and erased inside the codec). Fixed vectors: identity
seed `0x11`×32 gives $A'$ `fda0443b…3cb94d64` for period 0 and
`00584423…b57bf49d` for period 1. Suites: `blinded-presence` 9/58,
`presence-client` 6/25, `live-presence` 6/43 (a real signed record fetched
over the lookup branch and opened; the announce-branch put through a READY
controller is not exercised in-process, see the process gate below for the
controller's `mutablePut` with a caller `seq`). Not done: the required-mode
`lookup`/`announce` mapping onto these records (Gate 3B remainder), any
external cryptographic review, and the presence client on the eleven-role gate.

**Reflector sends now in the exposure report.** `BootstrapIO` mints its
redaction key at construction instead of at `start()`, and
`recordPreGuardContact({ host, port, outcome })` records a `reflect` /
`reflector` entry through the same `expose` path. The reflected claim now
retains which reflectors answered (`readReflectedEndpointClaimReflectors`),
so `prepareEndpointNatTraversal` records one entry per configured reflector:
`observed` when its reply reached the socket, `silent` otherwise, `rejected`
for all when reflection threw (the original error is rethrown unchanged). The
worker's first version matched a field the opaque claim does not expose and
would have recorded every reflector as silent; caught on diff review and
replaced. `endpoint-bootstrap-authority` 7/46, `bootstrap-io` 33/347.

**Remote driver command wait.** The coordinator now takes the topology plan and
ships `REMOTE_ACTIVATE_TIMEOUT_MS = 20_000` for the `ready` reply on the
`dht-mesh` plan only (`PLAN_EVENT_TIMEOUTS`); every other event and every
loopback plan keeps the 5 s `COMMAND_TIMEOUT_MS`, callers still cannot pass
deadlines, and the loud environment override can only lengthen a step. This is
the harness decision the previous checkpoint left open; run 34062727729 failed
at exactly that step and run 34062848870 passed with the override. A `-l 2 -p`
dispatch without overrides is the check, after this tree is pushed (the runner
roles execute the default branch and the role runner changed below).

**Live announce-branch put coverage.** The eleven-role scenario now, after the
resumed get, issues a routed `immutable-put`, reads the value back exact over
the lookup branch, then a routed `mutable-put` (`seq` 1) and a `mutable-get`
that returns it at sequence 1 — all through `PrivateRoutingController`'s
production announce-branch path, which the in-process harness cannot deliver.
That required the DHT-tier storage oracle to become exact instead of
"dht-value holds one value": every DHT role now reports
`storedValueCount`, `storedValueDigests` (sorted, unique) and
`mutableRecordTargets` (sorted, unique; the persistent mutable cache is keyed
by the record target), the control channel validates the lists, and the
config auditor admits only the setup value on dht-value plus records the
scenario announced beforehand through `auditor.expectRoutedRecords`; the setup
value may never appear on seed or referral and may not vanish from dht-value
before close. The steps sit after every routing derivation because a put grows
the announce exit's ordinary request count, which is how the lookup pair is
told apart. Process gates now pass **148 assertions** each (was 136), Node and
Bare, with a DHT role reporting each routed record.

**Gate C integration, experimental and off by default.** The owner-approved
wire is implemented; the approval is owner approval, external cryptographic
review is still open, and no anonymity claim follows from any of this.
`ROUTED_REQUEST_V2` (`0x0103`, `REPLY_MODE` `1 = CORRELATED`,
`2 = SURB_REQUIRED`) wraps a complete V1 request:
`replyMode u8 || batchId[16] || surbCount u8 || reserved u16 = 0 ||
requestBytes u16 || surbBytes u16 || request || descriptors[surbCount × 436]`;
V1 is untouched and its fixtures are pinned. `fragments.js` gained
`createFragmentProfile` and the 492-byte / eight-fragment
`SURB_REPLY_FRAGMENT_PROFILE`, so a required reply is at most **3,936**
application bytes (`RESPONSE_TOO_LARGE` above that, no correlated send). The
initiator (`RoutedDHTIO` → `LiveRouteAuthority.request`) builds eight
independent SURBs against the route's own relays in reverse order, one open
authority and one terminal handle each, bound by the operation deadline and
revoked on cancellation and teardown, and sends the V2 request as one logical
forward message; the exit (`dht-exit-io.js`) validates the complete batch
before any DHT request, and its only SURB output is the sealed first-hop cell
onto its reverse link (`routeSurbHop`); `SURB_REQUIRED` never reaches the
correlated authority or `onRoutedReply`, and a middle given a hop cell with a
flipped MAC drops it without forwarding. Relay peeling is
`processRelaySurbHop` (`relay-service.js`), reachable from the M3 forwarding
facade through an opt-in `surbHopPeel` capability whose absence leaves every
reverse cell byte-identical (`m3-adjacency-runtime` 48/48 unchanged). The
endpoint admits terminal cells by handle, opens with the one-use authority,
reassembles under the 492 profile and resolves the same promise the
correlated path would. The controller exposes `immutableGet(target,
{ replyMode })` / `mutableGet(publicKey, { replyMode })`; `SURB_REQUIRED`
throws `ERR_PRIVACY_UNAVAILABLE` unless the controller was created with
`experimentalSurbReplies: true`. Suites: `surb-integration` 19/65 (the
review's scenarios 1–20 mapped to named tests), `live-surb-required` 7/43
(exact value back with zero correlated frames and exit hop cells counted;
flipped-MAC drop; 4,000-byte refusal with no hop cell; option gate), plus the
touched suites unchanged in count. A first LEAD version had the exit peel
every layer itself with the relays' authorities ("local peel"); that was
rejected on diff review as the shim the packet forbids and deleted, and the
exit no longer accepts relay authorities at all.

The historical item (3) below is corrected by the later link-sealing checkpoint.

What is still not proven, stated plainly, as of commit `4993aae`: (1) the
in-process live topology forwards reverse cells through opaque forwarders, not
the M3 facade, so `live-surb-required` feeds each exit hop cell through
`processRelaySurbHop` with that relay's own authorities from the test (the
relay code path is real, the link between relays is simulated), and terminal
delivery to the endpoint uses the test issuer's `deliverSurbTerminal`; (2) no
fixture or production owner passes `surbHopPeel` to a facade yet, and the
return-path relay capabilities are bound by the test issuer
(`bindSurbReturnPath`), not by the route builder; (3) packed SURB frames on
the reverse link carry a fixed magic and are not sealed by the per-link route
codec, which classifies them to a link observer as SURB traffic (not a
cross-link tag, but a visible kind); (4) the eleven-role gate does not
exercise required mode.

**Required mode on real links (same day, later).** Items (1), (2) and (4)
closed. The controller now binds the return path itself on every READY
install (`bindProductionSurbReturnPaths` from `route-manager.readBranchPath`
and `guard-lease.readGuardSurbHop`, initial pair and every rotation; the old
authority dies with its generation). The eleven-role harness passes
`surbHopPeel` to each relay's M3 forwarding facade in `wire-services.js`,
built from that role's own route secret and a per-role replay authority, so a
hop cell is peeled at the middle and again at the guard on the real links,
the guard emitting the terminal cell to the endpoint over the guard link. The
endpoint role creates its controller with `experimentalSurbReplies: true` and
the scenario, after the announce-branch puts, issues `surb-get` and requires
the exact value, `surbHopsPeeled ≥ 1` on the lookup middle and on the guard,
`surbHopCellCount ≥ 1` on the lookup exit and an unchanged
`correlatedFrameCount` on it. Process legs now pass **155** assertions, the
punch legs 160, live namespace capture 165. Three defects surfaced on the way,
all fixed with a regression: the controller's reply mode was a sticky switch
on the IO (every later get would have stayed on the SURB path, and a
correlated caller's request would have become required) — it is now a
counted per-query hold covering the query's retry; after a required reply the
exit's route service still considered the operation active and admitted no
further request (the SURB path never settled it) — `onSurbReplySettled` now
does; and the endpoint's receive race left the losing transport reservation
armed after an injected terminal, so it swallowed the next correlated reply
on the route. `live-surb-required` proves a plain get after a required one is
correlated again (7/46). Item (3)'s wire-layer distinction is corrected in
the later link-sealing checkpoint below; external cryptographic review remains open.

**Namespace gate and grants.** The routed put/get and required-SURB steps
each rediscover the learned closers, which on the namespace plan are isolated
candidates admitted only through one-shot coordinator grants; the six-grant
pools were exhausted at the `surb-get`, and an exit whose optional grant is
never answered waits for the probe rather than finishing — a harness
property, recorded here, not a protocol one. `LEARNED_GRANT_USES` is now ten
(observed bound 30). The namespace roles now also receive
`PR_ROLE_FATAL_LOG` through the `env` wrapper inside the namespace, which is
how this was diagnosed.

**Remote check of the plan-scoped bound.** Run
[34068302573](https://github.com/ayooooo123/hyperdht/actions/runs/34068302573)
(`-l 2 -p`, no overrides, tip `237921b`): matrix 117/117, reflection equal on
both sides, exchange 840.9 ms, and the endpoint's `activate` passed inside
the shipped 20 s dht-mesh bound with no diagnostic override — the bound does
what run 34062848870 needed. The run then failed at `suspend` (assertion 77)
with `ERR_PRIVACY_UNAVAILABLE` from `PrivateRoutingController.suspend`: the
controller was still `ROTATING` when the coordinator's next command arrived,
which real-link timing can produce after the blackhole rotation and loopback
never does. The endpoint role now waits out an in-flight rotation (bounded at
4 s, inside the command wait) before suspending; that is the client contract
("suspend a READY controller"), not a hidden retry. Two dispatches on the
pushed tree (`b9686c1`) followed, both lost to runner NAT placement before
any production step, as runs 3 and 5 were:
[34070792738](https://github.com/ayooooo123/hyperdht/actions/runs/34070792738)
had a punch matrix of 18/117 and died in DHT setup (dht-referral and dht-seed
answered by nobody); in
[34071306816](https://github.com/ayooooo123/hyperdht/actions/runs/34071306816)
(matrix 63/117) the endpoint's runner did not preserve its mapping across the
close-and-rebind hop (observed `:15426`, minted `:15425`; the guard on the
operator host reflected equal) and production failed closed before any punch
byte, the same measurement as run 2. Dispatching stopped at the two-run
limit; the suspend-after-rotation wait is therefore verified only on the
Linux gates, and the next `-l 2 -p` run that reaches the lifecycle is its
remote check.

**Measurements.** All ten local Linux gates pass on the final tree. Node
aggregate **1,075 tests / 19,607 assertions**; Bare **1,031 / 19,474**; the
four normal/reverse process legs 155 each; both production-punch legs 160;
namespace projection 27; live namespace capture 165 with raw DROP zero.
Whole-repository Prettier passes. The protocol registry test pins the exact
sorted message-ID set and learned `ROUTED_REQUEST_V2` (63 IDs). Presence
message IDs `0x0280–0x02a3` remain reserved and unused: Gate D records ride
the mutable-record commands by seat decision; the routed presence commands
belong to the Gate 3B remainder.

Remaining work, in dependency order: (1) external cryptographic review of
Gate C and Gate D, including the existing link-sealed SURB framing and any
separately approved wire change; (2) the
next `-l 2 -p` dispatch as the check on the suspend-after-rotation wait;
(3) Gate 3B remainder — routed `findPeer`, `lookup`, `announce`,
`unannounce`, raw `query`, the required-mode `lookup`/`announce` mapping onto
presence records, peer streams, the public required-mode gate; (4) consumer
integration, which also brings the production topology owner that D7 waits
on.

### Continuation checkpoint — 2026-09-06, Gate D rollback repair

The session-3 handoff reports independent Fable-5-1 and glm-5.3 findings.
Both archived reproductions were run against the unchanged implementation:
the returned PERIOD tombstone state allowed a stale descriptor to restore
presence; unchanged reads and midnight overlap reads threw `REPLAY`;
a single RECORD target did not revoke the other period's descriptor.

The state resolver now retains `{ period, revision, recordDigest }` for
descriptors and tombstones. The digest is a copy of the hash of that record,
not the tombstone's target. The client computes it for both record types.
Within a period, lower revisions and equal revisions with different digests
are rejected; an identical record is idempotent. An accepted RECORD tombstone
stays absent when polled again, before its target is compared with the previous
state's now-tombstone digest. Ignored tombstones keep `present: null` and
`ignoredTombstone: true`, with the same revision metadata.

RECORD revocation now requires `targets: Map<bigint, Buffer>` instead of
`target`. Build it from the publication results:

```js
const targets = new Map(published.map(({ period, recordDigest }) => [period, recordDigest]))
await client.revokePresence({ revision, scope: TOMBSTONE_SCOPE.RECORD, targets })
```

Every publication period must have a 32-byte target. Targets are checked and
copied before the first write, so a missing overlap target cannot cause a
partial revoke and caller mutation during an awaited write cannot change a
later target. PERIOD revocation needs no target map. Retain each returned
state unchanged as `previous`, including ignored tombstones. Keep that state
when a lookup returns `null` or throws. Direct helper callers must supply the
opened record's period and digest. In-tree live callers use this contract.

Scope limits: this is a retained-state rollback check, not proof of freshness
for a reader with no history. The retained period is a lower bound: once a
newer signed period is observed, an older period cannot restore presence,
even if the newer record is later missing from storage. Within the retained
period, the revision and digest checks still apply. This single-state rule
does not require callers to select state for an internal fallback period.
An unmatched RECORD tombstone does not prove absence, but it still advances
the period/revision floor. No Gate C wire change, remote dispatch, or Gate 3B
command mapping is part of this repair.

Verification before the full Linux run: the new Node regressions failed on
the old implementation. Focused Node and Bare suites pass: blinded presence
10 tests / 70 assertions, presence client 10 / 52, live presence 6 / 43.
A separate smoke scenario passes on both runtimes: both tombstone scopes,
both overlap periods, midnight rollover, repeated reads, and stale storage
rejection using the actual returned tombstone state. The read-only review
archives remain outside Git and unchanged.

Verification of the first repair (`c0db444`): `bash scripts/linux-gates.sh all` passes all ten gates
with exit code 0. Node aggregate: 1,080 tests / 19,646 assertions. Bare
aggregate: 1,036 / 19,513. All four normal/reverse process legs: 155
assertions each; both production-punch legs: 160 each; namespace projection:
27; live namespace: 165, raw DROP 0. Complete local evidence:
`/tmp/hyperdht-gate-d-linux-gates.log`. The first run's tool artifact omitted
part of the output; the recorded counts are from a complete captured rerun.
The temporary smoke script was removed; the regression tests remain.

The later combined-boundary check found a further defect in `c0db444`: after
reading a new-period tombstone with only an old-period descriptor retained,
a missing new-period record let lookup fall back to the stale old descriptor.
This affected PERIOD tombstones as well as ignored RECORD tombstones. New
regressions failed on that commit for both scopes.

The resolver now rejects `opened.period < previous.period` with `REPLAY`.
This is a period floor, not a comparison of revisions across periods or an
assumed relation between target digests. The combined test publishes and
revokes in overlap, retains only the old descriptor, reads the new tombstone
after midnight, then hides the new record and serves the stale old one.
Both scopes now reject that fallback. A separate helper check also rejects
an older period carrying a higher revision. Focused Node and Bare suites
pass: blinded presence 10 / 71 and presence client 12 / 62. A standalone
Node smoke confirms the ignored RECORD tombstone followed by stale fallback
throws `REPLAY`.

Final period-floor verification: all ten Linux gates pass, exit code 0.
Node aggregate: 1,082 tests / 19,657 assertions; Bare: 1,038 / 19,524.
Four normal/reverse process legs: 155 each; two production-punch legs:
160 each; namespace: 27; live namespace: 165, raw DROP 0. Complete log:
`/tmp/hyperdht-gate-d-period-floor-linux-gates.log`. The changed files pass
Prettier. This run includes the older-period fallback regressions.

### Continuation checkpoint — 2026-09-07, Gate C link sealing and target preflight

The assigned `scary-elephant` worktree starts at `b4bad01`; a fetch found no
newer commit on `origin/private-routing-v1`. No old worktree or uncommitted
handoff was used. JD approved verifying the existing link-sealing boundary
without changing the SURB wire contract.

**Gate C exposure correction.** `routeSurbHop` packs a 1,100-byte frame and
calls `sendM3RouteFrame`. That function calls `sendM3RuntimePayload`, then
`sealTail`, which seals a 1,200-byte adjacency `CellCodec` packet. The M3
relay opens the incoming link cell before `surbHopPeel`, then seals the
result under the outgoing link context. The fixed `SURB-HOP-V1` and
`SURB-TERM-V1` tags are visible to authenticated relays after decryption,
not plaintext to a passive physical-link observer.

`RoutePayloadCodec` is the separate endpoint–exit layer. Applying it to
these reverse frames would prevent relay-local processing by the middle
and guard unless distinct hop-owned contexts were designed. No extra
envelope, exit-side local peel, or correlated fallback was added. Timing,
volume, visible outer cell metadata, and operator-diversity limits remain.

The namespace capture oracle now searches for both SURB tags using its
existing leak-marker checks. A live eleven-role namespace run passed with
the exact required reply, middle and guard peel evidence, no additional
correlated reply frames, no plaintext SURB tag, fixed 1,200-byte cells,
and raw DROP zero. A synthetic-capture positive control detects either
injected tag. A direct `CellCodec` smoke recovers authentic packed frames
and rejects tampering, wrong keys, wrong epochs, and replay for both tags.
These checks are not external cryptographic approval or an anonymity claim.

**Gate D review finding and approved repair.** A valid old-period target
followed by an all-zero new-period target passed the client's length-only
preflight. The first tombstone was written before the encoder rejected the
second target. The new two-period regression failed with one write and the
first stored revision changed from 1 to 2.

`isRecordTombstoneTarget` now owns the 32-byte, nonzero rule in the record
codec and client preflight. Every required target is checked and copied
before the first write. The same smoke now returns `INVALID_DESCRIPTOR`
with zero writes. Node and Bare focused suites pass: blinded presence
10 tests / 71 assertions, presence client 13 / 66, live presence 6 / 43.
The record wire, native dependency pin, signature transcript, period floor,
equal-revision conflict checks, and ignored-tombstone handling are unchanged.

The focused source review covered the SURB context-bound key schedule,
reply binding, one-use admission, and relay-local processing; Gate D
blinded signing, mutable signature verification before decryption, AEAD
period/revision binding, RECORD targets, equal-revision conflicts, overlap,
and older-period fallback. Existing regressions for both tombstone scopes
pass. External cryptographic review and approval remain open; neither this
review nor the previous model reports closes that gate.

**One approved remote run, no overrides.** Ran exactly
`scripts/live-route.sh up -p -l 2` using the normal runtime credentials.
Run [34080635056](https://github.com/ayooooo123/hyperdht/actions/runs/34080635056)
executed `b4bad01aeaa12973b6f657ecc89c07b8dd2c8485`.
The coordinator exited 1: 38/39 assertions passed, with
`PROCESS_FAILURE (endpoint/CONTROL): ERR_PRIVACY_UNAVAILABLE` at endpoint
`activate`. Harness punch matrix was 117/117; both production reflections
matched the minted tuples; punch exchange took 794.7 ms.
The endpoint stack identifies the `exchangeSharedGuardBranch` response
deadline in `lib/private/udx-cell-endpoint.js:4122`, not the later suspend
path. The missing response's cause is not established. Rotation, suspend,
resume, and network change were not reached, so the required remote
lifecycle result remains unproven. No retry was dispatched.

The Actions bridge-host workflow concluded `success`; that is not the
coordinator scenario result. The bridges ended on their bounded lifetime.
No operator address or secret is recorded here. No commit, push, public
required-mode enablement, command-path expansion, or consumer integration
is part of this checkpoint.

**Final local verification after the preflight repair.**
`bash scripts/linux-gates.sh all` exited 0, all ten gates passed:
Node aggregate 1,083 tests / 19,661 assertions; Bare 1,039 / 19,528;
four normal/reverse process legs 155 each; two production-punch legs 160
each; namespace projection 27; live namespace 165, raw DROP zero.
The new SURB marker checks are part of that capture gate. The first
pre-repair run's tool artifact omitted its middle, so a complete captured
rerun established the earlier baseline; these final counts are from a
separate complete captured post-repair run. Synthetic tag-injection and
direct-codec probes were one-off checks, not permanent test additions.

### Continuation checkpoint — 2026-09-07, exact signing and SURB ownership

JD separately approved two further review repairs, without another remote
run, commit, push, or wire change.

**Exact-value signing.** A controller could substitute one byte of an
895-byte presence value and obtain a valid blinded mutable signature for
those altered bytes. The reader then rejected AEAD authentication. The
`signMutable` closure now keeps an owned copy of the exact encoded value,
rejects any unequal candidate with `UNAUTHORIZED`, and hashes the bound
copy when signing. The hostile-controller regression fails before the
repair and passes afterward for both a copied substitution and in-place
mutation of the supplied buffer. A smoke confirms that the unchanged
record still receives a valid signature. Signed transcript bytes do not change.

**SURB batch ownership.** Injecting failure in the second SURB left the
first open authority active and its reply secret uncleared. Construction
now owns each slot as soon as it is allocated and revokes the partial
batch on failure. The regression injects both an entropy failure and a
native keypair failure and requires earlier reply secrets and owned
terminal handles to be erased.

`RoutedDHTIO.request` owns a complete batch until authority admission
returns a valid operation. Before that handoff, failure revokes the batch
and clears V1/V2 request and entropy buffers. A rejected-admission
regression failed with eight live authorities before the repair and now
finds all eight already revoked. After transfer, the production operation
revokes the batch on cancellation or settlement. Partial terminal
registration and reassembler setup are also cleaned if admission throws.
Successful required replies still pass through relay-local middle and
guard authorities; no exit-side peel or correlated fallback was added.

The SURB physical-tag positive controls are now permanent tests in
`test/private/route-oracles.js`, not only one-off probes. Each inserts a
tag in a 1,200-byte route-edge packet and requires the leak oracle to reject it.

Focused Node and Bare verification passes: blinded presence 10/71,
presence client 14/70, live presence 6/43, SURB 31/115, SURB integration
20/71, routed DHT IO 40/274, and live required SURB 7/46.
External cryptographic review remains open. These are ownership and
callback-scope repairs, not a replacement for that approval.

Final combined verification after all three review repairs:
`bash scripts/linux-gates.sh all` exited 0, all ten gates passed.
Node aggregate 1,087 tests / 19,678 assertions; Bare 1,042 / 19,543;
four normal/reverse process legs 155 each; two production-punch legs
160 each; namespace projection 27; live namespace 165, raw DROP zero.
Changed-file formatting passes. These local results supersede the
preflight-only counts above; they do not change the failed remote result.

### Continuation checkpoint — activation diagnostics

JD approved bounded harness diagnostics and exactly one further remote
lifecycle attempt, with the normal deadlines and no further retries.

The retained evidence from run `34080635056` contains only the endpoint
shared-guard response timeout; the workflow has no retained artifacts.
A one-off native-UDP experiment opens a branch with the valid responder.
Both a missing responder and an injected responder authentication failure
produce the same endpoint `ERR_PRIVACY_UNAVAILABLE`. The latter error is
discarded by the shared-guard dispatcher's existing rejection handler.
These results show why the old timeout does not establish packet loss,
responder absence, or authentication failure as its cause.

The guard process harness now reports responder registration, offer
receipt, offer authentication, adjacency adoption, and response creation
through the existing opt-in `PR_ROLE_FATAL_LOG` sink. The diagnostic path
is limited to 32 lines per process and does not emit payloads, keys,
addresses, error messages, or stacks. Diagnostic sink failure does not
change the exchange. There is no production-library or wire change.
`response-created` records the returned accept message, not successful
physical transmission or endpoint receipt.

Native smoke checks distinguish successful response creation from an
authentication rejection during responder construction; both still behave
as before if the diagnostic callback itself throws. A separate sink smoke
verifies default-off behavior, the 32-line bound, and exclusion of error
messages and stacks. These are one-off diagnostic checks, not permanent
test additions. The approved run must explicitly set the local guard's
log path; `live-route.sh` does not set it for the operator host.

Local verification for this diagnostic change is not a clean combined
ten-gate pass. Nine gates passed: Node 1,087/19,678, Bare 1,042/19,543,
four process legs 155 each, two punch legs 160 each, and namespace
projection 27. The live namespace run passed through network change,
then failed during teardown with `PROCESS_COMMAND_DEADLINE` at 100/101.

A separate comparison used temporary read-only overlays, not repository
edits, and added failure-only command identification. The committed
`0c543a4` baseline reached the final audit, then failed the existing
realtime-clock integrity check at 155/156. The current diagnostic build
passed that same targeted lifecycle, 165 assertions and raw DROP zero.
The earlier teardown deadline was not reproduced and its cause remains
unknown. No deadline or clock-audit threshold was changed. The temporary
comparison overlays were removed.

Approved diagnostic run
[34139920391](https://github.com/ayooooo123/hyperdht/actions/runs/34139920391)
was dispatched with `scripts/live-route.sh up -p -l 2`, no deadline
overrides, and an explicit mode-0600 diagnostic log for the guard on the
operator host. The workflow's remote roles use `private-routing-v1` at
`b4bad01aeaa12973b6f657ecc89c07b8dd2c8485`; the guard and coordinator use
the local `0c543a4` tree with the harness-only diagnostic additions.
This is an activation diagnostic, not an all-roles validation of the
published repair branch.

**Remote outcome: failed before branch activation.** Coordinator exit 1,
36/37 assertions. The harness punch matrix was 117/117 and both
production reflections matched. The guard then failed `nat-arm`, before
either production first-send assertion, with
`PROCESS_ROLE_FAILURE (guard/CONTROL)`.

The explicitly enabled local fatal log contains `PrivateRouteError:
Operation is unauthorized`, with the stack through `acceptNatPunch`,
`armNatPunch`, and `verifyNatPunchPlan` at `nat-punch-plan.js:535`.
That line rejects `now < notBefore || now >= expiresAt`. Thus the signed
plan failed its validity-window check; the log does not contain the three
time values needed to distinguish a future plan from an expired one.
The strict validity check was not changed.

The bounded guard diagnostic log contains zero branch-stage records.
No responder was registered and no branch offer was observed by this
diagnostic path. The approved attempt was consumed before reaching the
old shared-guard failure and supplies no evidence for its cause.
Rotation, suspend/resume, and network change remain untested remotely.
No retry was dispatched. Cancellation was requested for the remaining
bridge workflow after the coordinator exited.

Next evidence needed is the plan's age and clock offset at guard
admission, not a longer deadline or relaxed validity window. The original
shared-guard timeout and local teardown/clock-audit failures remain open.
The diagnostic additions and this checkpoint are not committed or pushed.
The bridge workflow subsequently completed with conclusion `cancelled`.

### Continuation checkpoint — NAT admission timing diagnostics

After JD continued the investigation, the guard harness was extended to
observe the existing NAT authority clock reads during synchronous
`acceptNatPunch`. It returns the same coherent clock values to production
code. On failure only, it records the first/last offsets from the parsed
plan's `notBefore`, time remaining to `expiresAt`, sample count, sample
span, and the last sample minus a later `Date.now()` observation.
The system-clock comparison includes time spent inside admission and is
not a direct measurement of remote clock skew.

These records share the existing 32-line guard diagnostic bound and are
off unless `PR_ROLE_FATAL_LOG` is set. The timing-only reader loads the
two U64 fields at offsets 109 and 117. It does not decode or copy the
plan's identities, digests, or punch nonces, and does not verify signatures.
A `rejected-window` record is not proof that the plan authenticated or
that timing caused the rejection. It emits no absolute
timestamps, plan bytes, identities, addresses, keys, or free-form errors.
Truncated headers and failed log writes do not replace the original
admission error. Capture state is cleared on both success and failure.
No deadline, validity rule, wire field, or production library was changed.

A one-off smoke used the real signed offer/counter/complete/accept path
with controlled clocks and the existing test socket adapter. A guard 100 ms
behind the plan start failed at `verifyNatPunchPlan`, with two samples,
offset -100 ms, 5,000 ms remaining, and zero sample span. Expiration failed
earlier at `takePendingNatToken`, with one sample and zero remaining time.
A changed responder signature failed while its timing values remained in
range. A valid plan armed successfully and produced no failure diagnostic.
Default-off behavior, shared 32-line bound, numeric-only output,
unchanged plan bytes, original error identity, and sink-failure isolation
were also verified.

[INFERENCE] The remote stack from `34139920391` points to `now < notBefore`,
not expiration: the counter token stores the same expiry as the signed
plan and is checked before `verifyNatPunchPlan`; the shipped coherent
clock returns the same value throughout this synchronous operation.
The local future-plan smoke reproduces that exact rejection site. The
remote offset magnitude remains unmeasured, so this is not a remote
timestamp observation and is not grounds to weaken the validity check.

Node and Bare production-punch process gates pass, 160 assertions each.
This focused verification does not erase the earlier namespace teardown
and clock-audit failures. At the end of that local-only check, no remote
dispatch, commit, or push had been performed.

Before dispatch, the full-plan diagnostic decoder was replaced by the
timing-only reads above to avoid copying non-time plan material. The
signed-negotiation smoke still passes. A disposable Node/Bare smoke also
verifies the actual reader on a header-only buffer, without any endpoint
or nonce section, and checks truncated input, unchanged bytes, default-off
behavior, and the shared bound. The disposable script was removed.
JD approved exactly one remote `up -p -l 2` timing attempt with normal
deadlines and an explicit private guard log. No retry, commit, push,
wire change, or validity relaxation is authorized by that approval.

The final timing-only reporter passes both production-punch process
gates again, 160 assertions each. Approved run
[34144722025](https://github.com/ayooooo123/hyperdht/actions/runs/34144722025)
was dispatched with normal credentials and deadlines, and an explicit
mode-0600 guard log. Remote roles use `private-routing-v1` at `b4bad01`;
the operator-host guard and coordinator use local `0c543a4` plus the
harness diagnostics. No claim is made that this tests the repair branch
on all roles.

**Timing run outcome: 76/77 assertions, coordinator exit 1.** The punch
matrix was 117/117, both reflections matched, both production first-send
checks passed, and the endpoint activated. The first immutable get,
cancellation, healthy-branch checks, blackhole rotation, and routed
readback through the replacement pair passed.

The scenario then failed the `suspend` command after rotation, before
the `suspended` event. The endpoint stack identifies
`PrivateRoutingController.suspend` at `private-routing-controller.js:1605`,
whose precondition requires READY state and a route manager. It did not
enter the suspend body. No remote suspend/resume, later writes, required
SURB reply, or network-change result is claimed for this attempt.

The guard log records one responder registration, three authenticated
offers with adjacency adoption and response construction, then a fourth
offer rejected with `ERR_AUTHENTICATION` before the authenticated-offer
stage. Response construction alone is not proof of transmission. There
are zero NAT-window rejection records: NAT admission passed, so this run
provides no timing values for the prior NAT failure.

A further one-off native-UDP probe keeps the guard at 1,000 ms and moves
the endpoint from 1,000 to 1,100 ms. Equal clocks open the branch; the
100 ms guard lag produces `ERR_AUTHENTICATION` at `validOffer` and the
same endpoint timeout. The capability remains valid at both clocks.
Source inspection shows the offer is minted up to
`endpointNow + MAX_ADJACENT_LINK_MS`, while `validOffer` refuses a
deadline beyond `guardNow + MAX_ADJACENT_LINK_MS`.
[INFERENCE] Clock disagreement is therefore a candidate for the observed
guard rejection, but the remote log does not identify which authentication
predicate failed. The original activation timeout is not closed by this
later rejection.

No production rule was changed. The approved attempt is consumed; no
retry was made. The remaining bridge workflow was cancelled and completed
with conclusion `cancelled`. The next evidence needed is the rejected
guard-offer predicate and its deadline position, not a relaxed bound.

### Continuation checkpoint — guard offer deadline diagnostics

The optional process-harness observer now separates responder construction
from offer validation. On rejection, it reports a fixed failure-site tag
(`valid-offer`, `offer-decode`, or `other`) and, when available, the offer
deadline relative to the exact sampled guard clock plus the requested-limit
expiry relative to that deadline. These tags identify a stage, not every
predicate in a compound validation check.

Only two U64 values are read from the received offer, at encoded offsets
294 and 302. No offer copy or full decode is made for reporting. No absolute
time, identity, endpoint, key, nonce, signature, or free-form stack is logged.
The values describe an untrusted received window, not an authentication
claim or a measured remote clock offset. The existing opt-in sink and shared
32-record limit remain. With logging off, the original clock function is
passed directly; with logging on, its returned value is unchanged.

A disposable signed native-UDP smoke passed in Node and Bare:

- Equal clocks open the branch.
- A guard 100 ms behind rejects at `offer-validate` / `valid-offer`, with
  `offer_remaining_ms=15100`.
- A deadline equal to the guard clock rejects at the same stage/site, with
  `offer_remaining_ms=0`.
- A mismatched responder key rejects at `responder-create` / `other`, with
  `offer_remaining_ms=15000`.
- Logging off, a failed sink, and a throwing observer preserve the tested
  acceptance and rejection outcomes. Output stops at 32 records.

Verification is not all green. Direct host process runs stopped at socket
binding; their role addresses require the documented Linux runner. On that
runner, Bare passed 155/155. Node failed 34/35 during activation:
`announce-middle` reported `ERR_AUTHENTICATION` at
`validExtensionOffer`, `guard-link.js:769`, after two successful guard
response constructions. That compound check includes signature, role,
identity, deadline, and nonzero-field checks; the failed predicate is not
known. No passing Node process result is claimed for this checkpoint, and
no retry was used to replace that result.

Source formatting passed. The disposable probe is removed after use.
No production library, wire format, or validity bound changed. No new
remote attempt, commit, or push was made. Further remote dispatch still
requires explicit approval; the earlier remote fault and this local
extension rejection remain open.

JD approved exactly one further normal-deadline guard diagnostic attempt,
with no retries. Run
[`34147485033`](https://github.com/ayooooo123/hyperdht/actions/runs/34147485033)
was dispatched with `-p -l 2`: the guard and coordinator use the operator
host's uncommitted diagnostics; remote roles use `private-routing-v1` at
`b4bad01aeaa12973b6f657ecc89c07b8dd2c8485`. This is a diagnosis of the
mixed-revision scenario, not all-role validation of published `0c543a4`.

**Guard diagnostic run outcome: 38/39 assertions, coordinator exit 1.**
The punch matrix passed 117/117, reflection checks passed, and both
production first-send checks passed. Initial endpoint activation failed;
no application lifecycle result is claimed for this attempt.

The private guard log contains exactly three branch records:

```text
guard branch responder-registered OK
guard branch offer-received OK
guard branch offer-validate ERR_AUTHENTICATION site=valid-offer offer_remaining_ms=15027 limit_gap_ms=0
```

Thus the first offer reached role 2 during initial activation and failed
inside `validOffer`, before adjacency adoption or response construction.
The measured deadline exceeds the validator's 15,000 ms maximum by 27 ms.
This proves that the upper-bound condition at `guard-link.js:729` is
violated in this attempt; it does not prove every other condition passed.
The observer samples the same `current = now()` value passed to
`validOffer`, with no second clock read for reporting.

The remote endpoint stack points to the shared-guard timeout at
`udx-cell-endpoint.js:4122`. Retrieved workflow logs contain no named
`LINK_OFFER_V1` / `LINK_ACCEPT_V1` frame timeline, so packet-capture proof
is not claimed. Guard-side evidence directly proves receipt and rejection,
not packet loss on the incoming offer. It explains this attempt's timeout,
but does not establish the cause of the original run or the later fourth
offer from the previous attempt.

There are zero NAT-window rejection records. NAT admission passed; no
failing NAT time offset was measured. The 27 ms excess is a deadline
position at guard validation, not a measured endpoint/guard clock offset.

The approved attempt is consumed. No retry was dispatched. Workflow
cancellation completed with conclusion `cancelled`. Production validity
rules remain unchanged. Diagnostics and documentation remain uncommitted;
the published branch remains `0c543a4`. A repair requires a reviewed
cross-host time contract, not an unexplained increase in the allowed bound.

### Continuation checkpoint — 2026-09-09, adjudication of the 2026-09-07 model review of Gates C and D, remote run 34072979459

This continuation (adjudication, fixes, gates and commit on 2026-09-09; the
reviewer runs and the remote run below happened on 2026-09-07 UTC) started
from the session-3 handoff at `cb72ff8` and rebased onto `origin/continue-hyperdht-private-routing` at `8c404f5`
once the fetch showed the later Gate D rollback repair (`c0db444`,
`b4bad01`), the link-sealing and preflight checkpoint (`0c543a4`) and the
timing diagnostics (`8c404f5`). The coordinator diagnostic below was carried
across as a patch; nothing else from the older tree was reapplied.

**Internal model review — reviewers ran 2026-09-07, adjudicated 2026-09-09.** The packet
(`/tmp/hyperdht-crypto-review-packet.md`, fourteen questions over Gate C
required SURB replies and Gate D blinded presence records; output = ranked
findings with file:line and a run `/tmp` script) went to three read-only
reviewers on `cb72ff8`: `anthropic/claude-fable-5-1` (completed),
`orcarouter/z-ai/glm-5.3` at max thinking (completed) and
`anthropic/claude-opus-5` (stopped by a provider rate limit with an
111-minute retry window before its report; its partial notes matched the
other two on the blinding math). Venice `kimi-k3` and `gpt-5.6-sol` were dry
at dispatch. Reviewers ran in write-approval mode; `/tmp` script runs were
approved, every repository write refused, and the tree was clean when they
finished. Each Critical/High/Medium was reproduced by the seat before it
counted; this is an internal review and does not close the external
cryptographic-review gate.

Gate D findings and status:

- D-1 (both reviewers, High): tombstone states returned without a revision
  let a stale-serving node resurrect presence. D-2 (Medium): the same
  revision published to both overlap periods threw `REPLAY` at the day
  boundary. D-3 (Medium): an unchanged re-read was `REPLAY`. D-4 (Medium):
  one `RECORD` target could not cover both overlap periods. D-7 (Low):
  first-non-null period order let a withholding node downgrade to the
  previous period. All five were closed by the rollback repair
  (`c0db444`, `b4bad01`, "Gate D rollback repair" above) before this
  adjudication; the reviewers' reproductions were run against `cb72ff8`
  and the repaired tree rejects each case.
- D-5 (Fable, Medium): the announce exit sees two `mutablePutRequest`s to
  `A'_p` and `A'_{p+1}` with equal `seq` milliseconds apart during the
  overlap hour and links the periods; two storage nodes can compare `seq`
  continuity. Accepted and recorded as a contract note: the periods are
  unlinkable to storage nodes that do not see both puts, not to the exit
  that carries them. A per-period revision counter would remove the `seq`
  correlation but not the timing one, so no change is made without a
  design decision.
- D-6 (both, Low): unlinkability holds only against parties that do not
  know the stable key `A`; anyone holding `A` confirms `A' = h·A` for every
  period at one scalar multiplication, as in Tor v3. Now stated in the
  module header of `lib/private/blinded-presence.js`.
- glm D2 (Medium): the module comment and the earlier record claimed the
  AEAD stops a reader-credential holder from re-sealing; it does not (the
  reader key derives from the credential, `A'` and the period, all in the
  reader's hands). The signature, checked before the body is opened, is the
  only barrier. Comment corrected; regression added: a genuine tombstone
  body carrying the descriptor's signature, and the converse, are both
  `ERR_AUTHENTICATION` (`blinded-presence` 11 tests / 74 assertions).
- Confirmed sound by both, with scripts: blinding derivation reproduces the
  pinned vectors, `a'·B = A'`, stock `crypto_sign_verify_detached` verifies,
  low-order and identity inputs fail closed, `h ≠ 0` is checked; the nonce
  `r` is domain-separated RFC 8032 style and cannot collide across periods,
  readers or records; AD and signature cover every field; the AEAD nonce
  prefix is random per record under a per-`(reader, A', period)` key; a
  storage node learns `A'`, `seq`, a constant 895 bytes and timing.

Gate C findings and status:

- C-1 (Fable, Medium, reproduced): the nullifier store was a separate
  object per facade install (`wire-services.js` created one per
  `install()`), so a hop header captured on one circuit was admitted again
  on a second circuit of the same relay; both wraps used the same key and
  nonce and produced identical ciphertext (`/tmp/gate-c-c1-c2-repro.js`:
  `replay, second store for the same relay key: ADMITTED`, `identical wrap
output: true`). Fixed: the store now belongs to the capability authority
  (`createSurbCapabilityAuthority({ …, wallNow, maxReplayEntries })`,
  `processSurbHop({ message, capabilityAuthority })`); the separate replay
  authority API is gone (`createSurbReplayAuthority`,
  `destroySurbReplayAuthority` removed, `destroySurbCapabilityAuthority`
  added), `processRelaySurbHop` takes the one authority, and the eleven-role
  harness creates exactly one per relay process
  (`createRelaySurbPeelAuthority`: middles at configure, the guard service
  for its lifetime) and hands it to every facade. Regression: a header
  processed twice through one relay is `ERR_REPLAY` regardless of circuit.
- C-2 (Fable, Medium, reproduced): `now` was a value frozen at authority
  creation, so an expired capability kept peeling (`process after
capability expiry (frozen now): ADMITTED`); on the endpoint the SURB
  descriptors were built and opened against the monotonic clock while hop
  times are wall-clock advertisement fields, so hop expiry never rejected
  there either (only the operation deadline did). Fixed: the authority reads
  `wallNow()` at every use; `RoutedDHTIO` takes `wallNow` (the controller
  passes its wall clock) for `buildSurbBatch`; `createSurbTerminalAdmission`
  takes `now` (monotonic, for the operation deadline) and `wallNow` (for
  `openSurbReply`). Regression: a capability admits, the clock moves past
  its expiry, a fresh header is `INVALID_ROUTE`.
- C-3 (both, Medium): the store never evicts and refuses everything at
  capacity. With the store owned by the capability it now rotates with the
  advertised key; the harness keeps the primitive's 65,536-entry bound
  (eight per required reply). Recorded as the accepted DoS bound: a
  downstream neighbour can fill a relay's store with valid one-hop headers
  at one X25519 each until the key rotates.
- C-4 (Fable, Low): the terminal relay recovers the hop count from the
  deterministic pad. Production paths are always two hops
  (`bindProductionSurbReturnPaths`), so today it confirms a constant.
  Recorded; not changed.
- C-5 (Fable, Low, reproduced on the facade): a hop cell the relay could
  not peel was forwarded raw; the next hop could not open it either and the
  endpoint handed it to the route codec, which rejected it and ended the
  operation. Fixed: the facade drops a SURB hop frame whose peel returned
  null (`surbHopCellsDropped` in diagnostics; regression in
  `m3-adjacency-runtime`: the unpeelable cell is not forwarded, a plain
  reverse payload still is, the circuit is not failed), and the endpoint
  in required mode drops a packed hop frame instead of feeding it to the
  codec. A relay could already end the operation by dropping or by sending
  any invalid frame, so this closes no attacker capability; it removes the
  honest failure mode.
- Follow-ups on the same boundary, same day: the terminal admission now
  samples the wall clock after the handle lookup and before the entry is
  spent, and treats a throwing or non-time callback as `INVALID_ROUTE`
  after revoking the table, so the entry's one-use open authority is
  revoked with it; an unknown handle still returns `null` with no clock
  read and no table change (regression covers both; each ordering it
  replaces failed it). The harness peel-authority factory passes the
  original secret and key (the authority copies them) and clears every
  buffer of the decoded advertisement.
- C-6 (Fable, Low): "length in the clear on unsealed links" was written
  against the session-3 record; the link-sealing checkpoint above already
  corrected that every reverse frame is sealed by the adjacency
  `CellCodec` and a physical observer sees fixed 1,200-byte cells. What
  remains is the forward signature: a required request is 3,781 bytes over
  four DATAGRAM cells against one cell for the same correlated get, and the
  reverse carries one hop cell per fragment. Recorded under KI-1.
- C-7 / glm C1 (Note): the required-mode hold upgrades a concurrent caller's
  request on the same controller to required (never downgrades; the return
  path is always bound at READY in production). Recorded; scoping the hold
  to the query object is deferred.
- C-8 / glm C2 (Note): the guard can burn a terminal handle with a forged
  cell (one fragment lost, no forgery, no retransmit); it can already drop
  the cell. Recorded.
- glm's open question, route-key reuse across relay restarts, is the design
  note's own stated condition (a signed key-generation id); with the store
  on the capability authority a restart with the same key and window would
  reset the store, so that condition stands as written.
- Confirmed sound by both: the keyed BLAKE2b key schedule and its domain
  strings, per-hop independent ephemerals and the filler algebra, MAC over
  `E_i || beta_i`, synchronous nullifier admission, the reply AD from owned
  state on both ends, the zero-pad strip, and every path from
  `SURB_REQUIRED` to `onRoutedReply` closed at `dht-exit-io.js`.

**Remote check, run
[34072979459](https://github.com/ayooooo123/hyperdht/actions/runs/34072979459)**
(`-l 2 -p`, no overrides, remote roles on `private-routing-v1` at
`cb72ff8`): punch matrix 117/117, production reflection equal to the minted
tuple on both sides, exchange 788.6 ms, both first owned sends, `activate`
inside the shipped bound, the first routed get exact, cancellation, and both
healthy-silence checks passed (56/57). The blackhole rotation then failed as
`PROCESS_PHASE_MISMATCH (endpoint/CONTROL)`: the endpoint emitted
`unavailable` where the coordinator expected `rotated`. Cause, reproduced at
the directory level (`/tmp/ki18-repro.js`, three placements): the
coordinator had logged at setup that `lookup-exit-b` and `announce-exit`
shared one `/24` on the runners; the initial lookup pair was
`announce-middle → lookup-exit-b`; `reserveReplacement` excludes the live
opposite pair and the pair being replaced and applies the KI-5 subnet rule
against both, so the only spare exit (`announce-exit`) conflicted with the
departing `lookup-exit-b` and `chooseReplacementPair` returned
`ERR_INCOMPATIBLE_RELAY`; the controller entered `UNAVAILABLE`. That is the
fail-closed placement outcome the KI-5 rule specifies, not a selector
fault, and the selector is unchanged: a three-plus-three pool whose exits
share a `/24` cannot survive a fault. The run therefore says nothing about
the suspend-after-rotation wait, which run 34144722025 (timing
diagnostics, above) later reached. The coordinator now names the event that
missed in a `PROCESS_PHASE_MISMATCH` or `PROCESS_UNEXPECTED_EVENT` failure
(`event type=… generation=… phaseSequence=…; held …`, bounded and typed;
configuration-audit failures stay sanitized), which is how the next such run
reads without the role's stream. One of the two approved `-l 2` runs for this
question was used; the log `/tmp/hyperdht-live-route-p11.log` holds the
operator host's address and may be deleted by JD.

**Gate 3B remainder: the bytes exist, and a decision was taken.** The
message IDs `0x0280–0x02a3` (and the storage carrier `0x0050–0x0054`) are
fully specified in the owner-approved M3 wire registry of the reviewed
prototype (`ayooooo123/peartube` at `0305df915b6a…`, approved 2026-07-15).
That file was referenced by the Gate 3B1 design at
`docs/superpowers/specs/2026-07-14-native-dht-private-routing-m3-wire-registry.md`
but was never ported; it is now in the tree verbatim (SHA-256 prefix
`d9117d1438308446`). Its private-storage overlay (§11) signs
`PRIVATE_PRESENCE_RECORD_V1` under the endpoint's stable Ed25519 key with
the plaintext `topic` on the wire, stored at `hash(topic)` on
`PRIVATE_RECORDS_V1` storage nodes reached through a signed exit storage
session, with a five-identity quorum. Gate D (owner-approved 2026-09-06)
replaced exactly that exposure: records are addressed by a per-period
blinded key, the body is opaque to storage, and no stable identity or
topic is on the wire. JD asked for the decision to be made for the goal of
the strongest achievable anonymity; the seat decides, recorded for JD to
overrule:

- **D10.** Gate D blinded records over the DHT mutable-record commands are
  the presence wire. The registry's `0x0280–0x02a3` objects and commands
  and the `0x0050–0x0054` storage session are superseded for presence and
  stay reserved and rejected (the nine-command exit-origin policy digest is
  unchanged); `PRIVATE_RECORDS_V1` stays unused. Reason: the overlay
  exposes the stable identity and the topic to every storage node and the
  exit; Gate D exposes neither.
- **D11.** No routed public `announce` / `unannounce`: they publish a
  signed, linkable public key through the exit, which is the opposite of
  the goal. No routed public `lookup` / `findPeer` / raw `query` in
  protocol v1 either: they are outside the registry's nine-command
  inventory ("commands outside the nine-entry inventory fail closed"), so
  adding them is a protocol-version change, and the exit would learn the
  topic. Consumers discover each other through Gate D presence resolved
  over the route; a later public-DHT read command needs a versioned wire
  decision from JD.
- **D12.** Presence reads run in required SURB reply mode
  (`createPresenceClient({ …, replyMode: 'SURB_REQUIRED' })`, threaded to
  `controller.mutableGet`), so the resolver's reply never travels the
  correlated path. Publication and revocation are puts whose replies are
  correlated acknowledgements; making puts required is the next slice and
  needs the exit's put path proven under SURB on the live gate.

> **Superseded implementation status:** the
> [2026-09-09 final checkpoint](#continuation-checkpoint--2026-09-09-required-mode-puts-and-v2-allocation)
> completes required-mode publication and revocation. The account below records
> the earlier read-only proof.

Landed with the decision: the eleven-role scenario now publishes a blinded
presence record from the endpoint (one mutable put per publication period,
the coordinator's wall time carried in the command so both ends derive the
same periods; the DHT storage oracle admits exactly the blinded targets) and
resolves it back in `SURB_REQUIRED` mode with the exact descriptor at
revision 1 and a grown hop-cell count on the lookup exit
(`presence-publish` / `presence-resolve` commands, `presence-published` /
`presence-state` events, bounded and validated like the record commands).
Process legs now pass **162** assertions each. Peer streams (Noise streams
through the route) and the public required-mode gate remain design gates:
the first needs its own reviewed design, the second the external
cryptographic review that every checkpoint here names as open.

**Follow-ups on the presence slice (same day, astra-low workers, diffs read
by the seat).** The endpoint role's `presencePublish` / `presenceResolve`
zeroize every owned input (seed copy, derived identity key pair, reader
secret, descriptor, identity) on success, failure, stale-operation return
and cancel-before-timer, through a cleanup callback `startEndpointOperation`
now owns. The scenario baselines the lookup exit after the publish and,
after the required-mode resolve, asserts hop cells grew **and**
`correlatedFrameCount` is unchanged — the D12 proof, measured after the
publish because put acknowledgements are correlated by design. A command
deadline now names its round trip (`PROCESS_COMMAND_DEADLINE (guard/snapshot)`),
and a role reports a command failure that happens after `stop` has begun
instead of swallowing it (`fatal(err, commandFailed)`); faulted link
sessions are joined at link-service destroy.

**KI-18: the namespace capture gate is intermittent on this workstation
(harness self-checks, named now).** Status: open, harness-only, two causes,
both named in the failure since this checkpoint. (1)
`test/private/process/socket-close-observer.js:18` refuses a wall/monotonic
drift above 2 ms over the role's lifetime; inside the Docker VM on this
workstation that drift is exceeded in roughly one run in three, and the
guard and a middle then fail their socket close at `stop` with `socket
close observer realtime clock changed`. Before this checkpoint that error
was swallowed by `fatal()` because `stopped` was already set and surfaced as
the silent `PROCESS_COMMAND_DEADLINE` the 2026-09-07 log records at 100/101.
(2) `ERR_TEARDOWN_ICMP: raw DROP=1, classified=0` (KI-16's classifier) in
about one run in ten. Neither is a protocol property; neither threshold was
widened (the 2 ms bound is what makes the capture timestamps trustworthy and
"never backdate" is deliberate). Options for JD: run the namespace gate on
native Linux, or accept a documented wider drift bound for VM hosts. Runs
on the final tree: worker's five consecutive passes at 173/173, then the
seat's full run failed (1), a rerun passed 173/173 with raw DROP 0, a second
rerun failed (2).

**Environment decision — 2026-09-09:** use the native-Linux CI capture gate
as required release evidence. Keep both 2 ms clock checks and the fail-closed
ICMP classifier unchanged. Local VM capture is supporting evidence only when
the actual run passes those checks. Record every attempt. A clock or ICMP
failure is failed supporting evidence, not a result to omit. Count only a
predeclared uninterrupted run that passes. A disposable coherent-clock VM may
supplement CI without changing the shared workstation VM or its services.
This settles the environment choice, not the cause of every historical unmatched
ICMP packet.

**Fork-native CI and the converged run.** The `Private Routing` workflow ran
on `6014341` on GitHub's native Linux (runs 34377545316 and 34377539226,
both green, including the privileged namespace capture gate with its strict
clock check); at `71498a1` its Bare process leg had missed a command
deadline at assertion 35 (run 34374496372), a runner-load intermittent of
the KI-4 class, not reproduced since. The presence steps then dropped their
two eleven-role routing snapshots for one round trip to the lookup exit each,
and the unproven `closingLinks` join was removed from the link service (the
fault path still awaited the close; only the named `fatal` report was the
fix). On that tree one uninterrupted local run passed all ten gates: Node
1,092 / 19,704; Bare 1,047 / 19,569; process legs 163; punch legs 168;
namespace 27; live namespace 173, raw DROP 0.

**Measurements (`6014341`).** `set -o pipefail; bash scripts/linux-gates.sh all` on the
final tree with no concurrent edits: nine gates pass in one run (Node
aggregate **1,092 tests / 19,704 assertions**; Bare **1,047 / 19,569**; the
four normal/reverse process legs **163** each; both production-punch legs
**168** each; namespace projection 27) and `namespace:live` passed **173 /
173** with kernel raw DROP zero on the same tree in the immediately following
run (`/tmp/hyperdht-nslive-final-1.log`), with the KI-18 intermittents
recorded above. Earlier commits of this checkpoint: `5bcf9ac` 1,091 / 19,687
and 1,046 / 19,552; `b33fbe4` 1,092 / 19,689 and 1,047 / 19,554; `f71e8de`
1,092 / 19,692 and 1,047 / 19,557; `71498a1` 1,092 / 19,704 and 1,047 /
19,569 (process 162, punch 167, live namespace 172). Whole-repository
Prettier passes.

### Continuation checkpoint — 2026-09-09, required-mode puts and V2 allocation

Continued from `0914480`, using the controller/client changes in the
`astra/required-mode-puts` WIP (`1daff08`). Its in-process put test was not
retained: that harness stages no announce seeds. The put proof belongs on
the eleven-role gate.

**D12 remainder.** `immutablePut(value, { replyMode })` and
`mutablePut(keyPair, value, { seq, signMutable, replyMode })` support explicit
`SURB_REQUIRED` behind `experimentalSurbReplies: true`. Defaults remain
correlated. The presence client applies its configured mode to publication
and revocation as well as resolution. Mutable-get refresh remains restricted
to correlated mode.

The required-mode hold begins before query construction and covers the
token query, retries, and commit. Each attempt releases it in `finally`,
including when query construction throws. The same construction/cleanup gap
was repaired in the two get methods. A live-harness regression injects a
construction failure, then checks the next ordinary get's actual reply path.
Against `1daff08` it fails eight assertions because required mode remains
held; the repaired controller passes. The regression tests failure cleanup,
not announce-seed support or a successful in-process put.

**V2 allocator defect.** The first required-mode presence publication failed
with `TRANSPORT_UNAVAILABLE`; its preserved cause was `INVALID_ROUTE` at
`encodeRoutedRequestV2` → `allocate`. The opt-in, off-wire fatal log now
includes a bounded cause chain so that wrapper no longer hides the failure.
The allocator still used the 4,706-byte reply ceiling. The existing generic
V2 envelope ceiling is 4,910 bytes; a maximum legal immutable-put body of
1,090 bytes plus eight descriptors produces a measured **4,839-byte**
encoded request. These are different bounds. Allocation now covers both
message ceilings; per-message encoding/decoding limits and the wire are
unchanged. The size regression carries that largest put body through
fragmentation, reassembly, and decoding. It fails with `INVALID_ROUTE`
before the repair and passes afterward.

**Live behavior proof.** The process control commands `immutable-put`,
`mutable-put`, `presence-publish`, and `presence-revoke` carry a validated
`replyMode`. The ordinary put steps now exercise the maximum legal values
(895 mutable bytes and 1,023 immutable bytes) in required mode, rather than
duplicating those writes later in the lifecycle. Both read back exactly
and appear in the independent DHT storage snapshots. Publication and
period-tombstone revocation also run in required mode. Resolution must first
return the descriptor, then report absence at the tombstone's newer revision.
Every write is measured on the announce exit, every presence read on the
lookup exit: SURB emission increases without additional correlated frames.
Baselines are reused only when that branch has carried no intervening
application traffic. Learned-grant pools and protocol deadlines are unchanged.

An intermediate scenario that appended extra maximum-size puts passed the
Node process smoke (174/174) but later hit `ERR_PRIVATE_BRANCH_ROTATING` at
113 in namespace capture, before the additional immutable put began. The
final scenario replaces duplicate operations with the same maximum-size
coverage and moves branch derivation before writes. No production rotation
or admission rule was changed to accommodate the scenario.

**KI-18 environment evidence.** An earlier intermediate tree passed nine
gates together (Node 1,094/19,709; Bare 1,049/19,574; four process legs 168
each; punch legs 173 each; namespace projection 27). Five namespace-live
attempts failed during teardown after network change. The last three
recorded wall/monotonic drift of −142 to −166 ms over 7.3–8.2 s, with the
new put assertions passing before teardown. The clock diagnostics now
include measured drift and elapsed time; neither 2 ms check was widened.
A separate probe inside the default Colima VM observed a −171 ms change.
Its time-sync status reported a +232 ms offset; that observation alone does
not prove which service caused the change. Logs:
`/tmp/hyperdht-nslive-mayfly-{1,2,3}.log`.

The default VM also hosts unrelated database/proxy containers and was not
restarted. A disposable `hyperdht-gates-mayfly` profile was created without
changing the active Docker context or shared SSH configuration. Its first
45-second clock probe also failed (minimum cumulative drift −1,090 ms).
External NTP synchronization was paused only in this disposable VM. Its
next 45-second probe passed: drift ranged from −0.628 to +0.274 ms.
Real clocks and the 2 ms capture checks remain unchanged. The final
ten-gate result is recorded below; intermediate passes do not count as
final-tree convergence evidence.

**Final verification.** One uninterrupted run of
`DOCKER_CONTEXT=colima-hyperdht-gates-mayfly bash scripts/linux-gates.sh all`
passed all ten gates on the final source/test tree, exit 0:

| Gate                                                    | Result                                      |
| ------------------------------------------------------- | ------------------------------------------- |
| Aggregate, Node                                         | 1,094/1,094 tests; 19,730/19,730 assertions |
| Aggregate, Bare                                         | 1,049/1,049 tests; 19,595/19,595 assertions |
| Normal/reverse process legs, Node and Bare (four gates) | 175/175 each                                |
| Production-punch legs, Node and Bare (two gates)        | 180/180 each                                |
| Namespace projection                                    | 27/27                                       |
| Namespace live capture                                  | 185/185; kernel raw DROP 0                  |

The capture includes maximum-size puts, blinded presence publication,
resolution, revocation and tombstone resolution, plus the existing complete
lifecycle and leak oracles. Repository-wide Prettier passes. This is local
Linux-container evidence, not a substitute for fork-native CI or external
cryptographic review.

**Publication and independent CI.** The verified implementation was committed as
`cae9721` and pushed to `private-routing-v1`. Native-Linux Private Routing
[push run 34390828052](https://github.com/ayooooo123/hyperdht/actions/runs/34390828052)
and [PR run 34390832966](https://github.com/ayooooo123/hyperdht/actions/runs/34390832966)
passed, including privileged namespace capture with the unchanged clock check.
[Build Status 34390832973](https://github.com/ayooooo123/hyperdht/actions/runs/34390832973)
passed on Linux, macOS, and Windows. These are distinct from the local-container
results above and do not constitute external cryptographic review. The
disposable VM and its runtime data were deleted after verification; the shared
database/proxy VM and active Docker context were left unchanged.

This remains package-private and experimental. The owner-approved Gate C
wire is not external cryptographic approval. Public required mode, peer
streams, and the KI-4 cross-host guard-offer time contract remain open;
this slice changes none of those boundaries.

### Continuation checkpoint — 2026-09-09, KI-4 cross-host time contract for offer admission

Continued from `cae9721` in a fresh worktree. The open KI-4 item was the
guard-offer admission failure of run 34147485033: the guard rejected the
endpoint's first LINK_OFFER at `validOffer` because the offered deadline lay
27 ms beyond `guardNow + MAX_ADJACENT_LINK_MS`. The endpoint mints that
deadline as `endpointNow + MAX_ADJACENT_LINK_MS`, so any endpoint clock ahead
of the guard's by more than the one-way transit time was refused. The same
predicate sat in `validExtensionOffer`; the local Linux run recorded in the
guard-offer diagnostics checkpoint (`announce-middle` ERR_AUTHENTICATION at
`guard-link.js:769`) is that line.

**The contract.** A responder checks peer-minted wall timestamps for
authenticated ordering only: an offer whose deadline has already passed on
the responder's clock is expired, and the requested expiry must not precede
the signed deadline. No comparison measures how far ahead the peer's clock
runs. The bound on how far a deadline may lie in the responder's future is
the bound the responder already enforced locally on the requested limits:
`limitsWithinAdvertisement` caps `expiresAtMs` at 300 s from the responder's
own clock and at its advertisement expiry, and the validators require
`requestedLimits.expiresAtMs >= offerDeadlineMs`. Every lifetime a responder
schedules from a peer timestamp is clamped in its own domain: the extension
responder now signs `min(requestedExpiry, offerDeadline, responderNow +
MAX_ADJACENT_LINK_MS)` as the admitted expiry, so a slower exit shortens the
link instead of refusing it. Index-zero admitted limits were never bounded by
the offer deadline (they are the requested limits) and are unchanged. Replay
reservations still live until the peer deadline as read on the responder's
clock: cell IDs derive from the offer digest, so the reservation must cover
the whole window in which the responder would still accept the offer. The
previous KI-4 slice removed the initiator's peer-clock-versus-local-current
comparisons on the same principle; this slice completes the responder side.
No skew-allowance constant, wire byte, or endpoint-side check changed.

Resulting tolerance, without a constant: a responder admits an initiator
whose clock runs ahead by up to the 300 s limits cap less the offered window,
and behind by up to the offered window less the handshake time (expiry).
Initiator-side completion, unchanged, accepts a responder ahead by up to the
offered window less the handshake time (`acceptedAtMs <= offerDeadlineMs`)
and, with the clamp, behind by the same amount (`admittedLimits.expiresAtMs`
must still be in the initiator's future). For the observed 27 ms the admitted
expiry is `initiatorDeadline - 27 ms + transit`; completion would need a
return path of almost fifteen seconds to see it expired.

**Deliberate bound change.** An adversarial initiator can now hold an
index-zero or extension replay reservation for up to 300 s instead of 15 s;
each costs one valid signature from any identity, and the caches already
return ERR_BUSY at `MAX_RESPONDER_REPLAYS = 4096`. The sustained fill rate
needed to keep a cache full drops from about 273 to about 14 offers per
second; storage and admission stay capped. Honest reservations do not change,
because honest deadlines are at most 15 s from the initiator's clock. The
alternatives were rejected on record: an explicit skew allowance reusing the
advertisement's 30 s `MAX_FUTURE_SKEW` contradicts the earlier KI-4 policy and
turns the responder bound into 45 s; a relative budget on the wire (KI-15
style) is a signed-body semantic change and would need the replay cache to
live for the advertisement lifetime; clamping the reservation to 15 s locally
breaks exact replay coverage.

**Review lane.** The packet (fault, deadline data flow, candidate contract,
the three alternatives, four questions) went to `omp/openai-codex/gpt-5.6-sol`
read-only after `orcarouter/kimi/kimi-k3` was credit-gated. Verdicts: the
contract is sound and names every remaining cross-clock check as an
"expired here?" or signed-ordering check; the 300 s reservation exposure with
the 4096 cap is accepted over an unstated skew assumption; the extension
clamp cannot shorten any offer the old validator admitted (for those,
`deadline <= validationNow + 15 s <= sampleNow + 15 s`) and only bounds newly
admitted skewed offers; the test set was expanded by a five-second skew and a
replay-after-15-s case. The verdict is the seat's.

**Regressions (fail before, pass after).** In `test/private/guard-link.js`:
the index-zero responder admits an initiator 27 ms and 5 s ahead and the
initiator completes with the requested lifetime intact; the extension
responder admits both skews and signs an admitted expiry exactly
`MAX_ADJACENT_LINK_MS` from its own clock; the native UDX completion scenario
gains 27 ms and 5 s responder-behind cases over a full offered window. Before
the fix each of these throws ERR_AUTHENTICATION at `validOffer` or
`validExtensionOffer`, the run-34147485033 site. Retained bounds are pinned:
a deadline at or before the responder clock is expired whatever the initiator
clock; a deadline exactly at the responder-local 300 s cap is admitted and one
millisecond past it is refused; a second copy of the same signed offer is
ERR_REPLAY sixteen responder seconds later while the peer deadline still
stands, and expired once that deadline passes. The boundary the contract
introduces is pinned fail-closed: with the responder 5 s behind and the
initiator's clock moved past the clamped admitted expiry before completion,
`completeExtensionLink` refuses with ERR_AUTHENTICATION. The existing
`deadline over five seconds` mutation (0xff deadline) is still refused, now
by the requested-limits ordering rather than the removed comparison. Focused
suite: 56 tests, 1,091 assertions.

NAT punch plan `notBefore` is the same class of comparison (the plan start is
the initiator's clock) and is untouched: NAT admission passed on every remote
run, no NAT-window rejection was ever recorded, and the recorded evidence
threshold for changing it has not been met.

**Verification.** The final source/test tree first ran `linux-gates.sh all` in
the default Colima VM: nine gates passed and the namespace live capture failed
at the network-change teardown with the KI-18 signature (`socket close
observer realtime clock changed`, 18.7 ms and 19.0 ms drift over 7.3 s on the
guard and a lookup middle), after every KI-4 activation, presence and put
assertion had passed (120 of 121 before the role failure). A disposable
`hyperdht-gates-ki4` profile was then created with `--activate=false`, its
`systemd-timesyncd` stopped, and a 45-second sub-millisecond probe showed
zero wall/monotonic drift. One uninterrupted
`DOCKER_CONTEXT=colima-hyperdht-gates-ki4 bash scripts/linux-gates.sh all`
on the same tree with the documentation cleanup already layered in passed
all ten gates. Repository-wide Prettier was checked separately, not by the
private aggregate. The gate runner returned
exit 0:

| Gate                                                    | Result                                      |
| ------------------------------------------------------- | ------------------------------------------- |
| Aggregate, Node                                         | 1,099/1,099 tests; 19,762/19,762 assertions |
| Aggregate, Bare                                         | 1,054/1,054 tests; 19,627/19,627 assertions |
| Normal/reverse process legs, Node and Bare (four gates) | 175/175 each                                |
| Production-punch legs, Node and Bare (two gates)        | 180/180 each                                |
| Namespace projection                                    | 27/27                                       |
| Namespace live capture                                  | 185/185; kernel raw DROP 0                  |

The 2 ms clock bounds are unchanged. The disposable profile was deleted after
publication; the default VM and its unrelated containers were not touched.

**Publication and CI.** The pending fifteen-file documentation cleanup was
landed first as `f20c32c` (three-way merge of this record, no conflicts), then
this slice as
[`74875ec`](https://github.com/ayooooo123/hyperdht/commit/74875ec6c16984287f24e522aed93b2bfe86fd24),
pushed fast-forward `cae9721..74875ec` to `private-routing-v1`. Fork-native CI
on that commit passed: Private Routing
[34406142729](https://github.com/ayooooo123/hyperdht/actions/runs/34406142729)
and
[34406147524](https://github.com/ayooooo123/hyperdht/actions/runs/34406147524),
each with the native-Linux `live-linux` job, and Build Status
[34406147525](https://github.com/ayooooo123/hyperdht/actions/runs/34406147525)
on Linux, macOS and Windows.

**Remote dispatches (standing approval, two per question, both consumed).**
Both used `env -u PR_COMMAND_TIMEOUT_MS -u PR_SCENARIO_TIMEOUT_MS bash
scripts/live-route.sh up -p -l 2` with remote roles at `74875ec`. Run
[34406688476](https://github.com/ayooooo123/hyperdht/actions/runs/34406688476):
punch matrix 0/117, every directed pair silent including runner-to-runner
pairs, role 4 never attached (`HOLEPUNCH_ABORTED`). Run
[34407746216](https://github.com/ayooooo123/hyperdht/actions/runs/34407746216):
punch matrix 8/117, 109 silent, role 1 never attached. No LINK_OFFER was
exchanged in either run, so neither is evidence for or against this slice;
both are runner NAT placement outcomes of the kind `cb72ff8` already recorded
for two post-push `-l 2 -p` dispatches. Both bridge workflows were cancelled.
KI-4's confirmation on real links therefore still waits for a dispatch whose
punch round reaches the matrix; the local ten-gate evidence and the native-Linux
CI above are what this slice stands on.

This remains package-private and experimental. Public required mode and peer
streams stay open; this slice changes neither boundary and adds no wire byte.
The peer-stream design packet with its review-lane verdict is
[`2026-09-09-private-routing-peer-stream-design-packet.md`](superpowers/specs/2026-09-09-private-routing-peer-stream-design-packet.md);
it is a packet for JD to ratify, not an approved design.

### Subagent design handoff — 2026-09-05

> **Historical handoff:** completed implementation work is recorded in the
> [2026-09-09 final checkpoint](#continuation-checkpoint--2026-09-09-required-mode-puts-and-v2-allocation).
> External cryptographic review remains open.

These are review requirements, not accepted replacement protocols:

- **Gate C:** make initiator ownership one-use and expiry-bound. Relay replay
  admission must be atomic, after header authentication and before wrapping.
  Remove manual replay-cache reset from the production contract. A local
  `{run, epoch}` label alone is not cryptographic binding: an old header must
  also fail under a new run or epoch. Bind that context through the accepted
  key/header contract; do not call a cache-only change sufficient.
- Authenticate the reply mode inside the inner request AEAD. A required SURB
  reply must never fall back to the correlated path. Each reply fragment needs
  an independent SURB; counter-based reuse is not the single-use construction.
  At the current 512-byte reference cap, a 20-byte fragment header leaves
  492 data bytes. The existing fragment encoder uses 1,053 data bytes, so it
  cannot be reused unchanged. A three-SURB request also needs a reviewed batch
  format and multi-cell carriage. Full-header reply overhead is 468 bytes;
  the 1,073-byte route payload leaves 605 bytes before any new envelope fields.
  This arithmetic does not approve a production cap.
- **Gate D:** the current native dependency lacks
  `crypto_core_ed25519_scalar_mul`. The
  [current npm release](https://registry.npmjs.org/sodium-native/latest) is
  `sodium-native@5.1.0`, which supports Node and Bare. The proposed dependency
  path is an upstream native binding to libsodium's scalar multiply, followed
  by a released version or approved commit and an explicit dependency pin.
  No JavaScript scalar arithmetic, substitute signer, codec shell, or
  permanently disabled implementation is an accepted substitute.
- Before Gate D implementation, approve the complete signed record transcript:
  version, type, epoch, revision, descriptor length, and tombstone scope/target.
  Verification must use the caller-derived expected blinded key, epoch, and
  storage key, not authority taken from the record itself. Overlap and rollback
  rules must be executable. The advisor's proposed schema and hash choices are
  not ratified, and external cryptographic review remains a human gate.

### Single-branch work collection — 2026-09-05

All related work is centralized on `private-routing-v1` in
`ayooooo123/hyperdht`. The accepted runtime remains active. Rejected and
unaccepted implementations are preserved under `research/private-routing/`,
not merged into `lib/private`. Preservation does not close their review gates.
The complete inventory covers all 33 local branch refs found at collection
time, both detached experiments, external handoff/workflow notes, and the
legacy Tor-transport history from the separate `source-hyperdht` checkout.
Original worktree commits are also retained as parents of an explicitly
archive-only merge. That merge keeps the accepted tree unchanged: it preserves
Git history without installing rejected implementations. Thus the one pushed
branch contains both the original commits and the reconstructable research
copies; separate remote feature branches are not required.

| Archive directory        | Preserved work                                              | Acceptance status                                                                                        |
| ------------------------ | ----------------------------------------------------------- | -------------------------------------------------------------------------------------------------------- |
| `ki10-blackhole-history` | Original `5a53851` / `7aeee57` history                      | Tip tree equals accepted `6468028`; no second runtime merge is needed                                    |
| `pr50-history`           | Original six-commit PR #50 history through `ba1f87e`        | Tip tree equals accepted `c035cf8`; no second runtime merge is needed                                    |
| `production-nat`         | `924fd55` NAT work and preservation status                  | Unaccepted; production ownership and real NAT evidence remain required                                   |
| `presence-gate-d`        | `5c77a50` / `2ac6b64` presence work and rejection status    | Rejected: record-type authentication, trailing-zero handling, overlap, and integration remain unresolved |
| `gate-c-surb`            | SURB rewrite and `check_vectors.js`                         | Incomplete; checker needs absent `/tmp/surb_vectors.txt` and undefined relay `sec` fields                |
| `blackhole-isolation`    | Detached `ab818f9` blackhole/demotion source and tests      | Historical research only; generated `choose.log` and `hook.log` are excluded                             |
| `baseline`               | Detached `ab818f9` baseline demotion and diagnostic changes | Historical comparison only; not a merge candidate                                                        |
| `handoff`                | External handoff and two Task 6 workflow briefs             | Historical instructions, not current authority                                                           |

Each archive has a `manifest.json` with its exact base/head, status, changed
paths, and SHA-256 file hashes. `history.patch`, when present, preserves the
original commits in `git am` format. `working.patch`, when present, preserves
the pending tracked and approved untracked files. Neither patch changes the
active runtime merely by being stored here.

To continue an experiment, create a separate worktree at its manifest's
`base_commit`, apply `history.patch` with `git am`, then apply `working.patch`
with `git apply --index`. Skip whichever patch the manifest marks `null`.
For example, from the canonical checkout:

```sh
ARCHIVE="$PWD/research/private-routing/production-nat"
git worktree add --detach ../hyperdht-nat-study 6c307fa8edbd380be4ff9a6a1bce0c1fd926e903
git -C ../hyperdht-nat-study am "$ARCHIVE/history.patch"
git -C ../hyperdht-nat-study apply --index "$ARCHIVE/working.patch"
```

Verification reconstructed all eight archives in temporary worktrees. Every
original committed tree matched exactly, and all 55 final changed files
matched their SHA-256 records; live source files were also compared directly.
This proves preservation, not correctness of the rejected implementations.
The temporary verification worktrees were removed.

`research/private-routing/inventory.json` records every original local ref and
its location on the fork or in these archives. Other local routing branches
already match their fork refs. The second `projects/Hyperdht-private-routing`
checkout has no unique edits or commits. The clean `source-hyperdht` reference
tip `b329b8b` was already on the fork, but its four Tor-transport commits were
not reachable from the collected branch. A further archive-only merge retains
that tip without installing its files. The source checkout's disabled push
configuration is unchanged. This history is listed in `external_histories` in
the inventory and can be inspected directly with `git worktree add --detach`
at `b329b8b`; no duplicate patch archive is needed. The clean DHT-RPC dependency
tip `fe04496` is already on its own `ayooooo123/dht-rpc` fork and is not copied here.
The stale `/private/tmp` baseline worktree entry points to a missing directory;
the live detached experiments are preserved without pruning that entry.

## Known issues

### KI-19: one native CI capture could not reconcile a kernel drop

**Status: OPEN. Cause unresolved; the strict gate correctly failed closed.**

PR run `34413413038` at `9857887` reached all lifecycle and route-capture
assertions, then failed the last assertion with raw DROP 1 and classified
teardown ICMP 0. The drop counter was already 1 before capture shutdown.
No undecodable frame was reported. The simultaneous push run passed.

Zero classified ICMP does not mean the dropped packet was absent from the
captures. The route oracle validates allowed host pairs, not every firewall
port/direction tuple. An off-port UDP packet on an allowed host pair could
pass those route assertions and still be correctly dropped. Missing captured
ICMP or another dropped IP packet also remains possible. The log cannot
distinguish these cases; the old workflow retained no pcaps.

CI retains the synthetic namespace pcaps, socket-close windows, numbered full
per-rule firewall listings, tcpdump stderr (including packet-loss statistics),
the waiter's actual tcpdump exit status, and forced-kill indicators for seven
days, including failed runs. Firewall samples cover the audit before and after
capture stop, plus teardown before the chain is removed, even if the scenario
failed before reaching its audit. Capture waiters preserve the real tcpdump PID
for SIGINT and record status only after that process exits.

No classifier, clock tolerance, firewall rule, assertion, or retry policy
changed. A recurrence must be diagnosed from this bundle; the summed counter
alone cannot distinguish the two final DROP rules. Missing status or a forced
kill is incomplete shutdown evidence, not a clean capture.

Diagnostic follow-up local evidence (2026-09-09): the explicitly selected
`colima` context passed namespace projection, 27/27. Its live scenario failed
before the capture audit at 111/112, during presence revocation:
`TRANSPORT_UNAVAILABLE` → `ROUTE_UNAVAILABLE` → `ERR_REPLAY` at
`readLiveRoutePair` (`route-manager.js:1139`, already-spent lease). Native
process runs [34415658161](https://github.com/ayooooo123/hyperdht/actions/runs/34415658161)
and [34415661996](https://github.com/ayooooo123/hyperdht/actions/runs/34415661996)
failed at the same operation before namespace provisioning.

The routing regression is separate from KI-19. The controller starts replacement
construction before draining the old DHT queries, but the live-pair reader spent
the old lease as soon as a sibling rotation draft existed. A deterministic
authenticated-reply regression fails there before the ownership repair. Splitting
strict new-work admission from exact current-or-retired reply ownership passes
the focused manager/authority checks (30 tests / 358 assertions).

That partial repair is not accepted as the completed routing fix: a subsequent
explicit-`colima` Node process run still failed presence revocation at 111/112,
now with `ERR_PRIVATE_BRANCH_ROTATING` at transport-request admission. An admitted
DHT query can issue discovery, retries, and a commit PUT after rotation starts.
Those continuations need query-scoped authority, not unconditional admission of
new work on an old generation.

The completed local repair mints opaque, per-attempt continuation capabilities
under strict `READY` admission. Unique transport contexts retain the existing
identity-branded command policies and carry that local capability through
discovery, retries, and commit. Async signing precedes admission. Rotation
constructs its replacement immediately, then waits for the old queries to finish
and release their reply-mode holds and capabilities before transferring ownership.
Expiry, revocation, suspension, destruction, and transfer still fail closed.

The explicit-`colima` eleven-role Node scenario now passes 175/175, including
presence revocation. Focused manager/authority/IO checks pass 75 tests / 664
assertions; controller continuation and installation checks pass 13 / 111.
Removing admission rollback after callback reentry makes the transfer regression
fail with `ERR_PRIVACY_UNAVAILABLE`; restoring it passes. No wire, public API,
retry budget, clock check, or capture classifier changed. Final ten-gate and
native-CI acceptance remain pending.

The cancellation regression found transient candidate publication after controller
destruction during candidate readiness; eventual cleanup prevented the stronger
persistent-leak allegation from reproducing. Exact generation ownership is now
rechecked after query drain and candidate readiness, before publication. Cancelled
installations clean only their candidates, without invalidating a newer or
destroying generation. The publication regression failed before these guards and
passes with them. Removing the drain wait makes the held-commit regression fail
after its explicit event-loop barrier. Neither mutation was left in the source.

The frozen explicit-`colima` full-log run passed nine gates: Node aggregate
1,109 tests / 19,855 assertions, Bare aggregate 1,064 / 19,720, normal and reverse
process legs 175 assertions each, production-punch legs 180 each, and namespace
projection 27. Live namespace passed presence revocation and tombstone checks,
then failed 120/121 during network-change cleanup: the socket-close observer
measured realtime drift of -115.580, -115.576, and -116.407 ms in three roles.
That is a recorded KI-18 clock failure, not an admission failure or capture
classifier waiver. No bound was changed and this run is not ten-gate acceptance.
An earlier asynchronous tool result retained only 50 KB of output, omitting
middle gate totals; its retained namespace 185/185 result is not substituted for
the failed full-log run. Native Linux acceptance remains required.

A separate projection smoke with a host-mounted evidence directory passed
27/27 and retained per-rule counters plus all 13 tcpdump logs/status files.
A throwaway real-process fault smoke killed one owned tcpdump with SIGKILL,
observed retained exit status 137, and verified namespace cleanup. This proves
nonzero capture exits are recorded, not replaced with a successful default.

Review-branch commit `8fc1611` passed all ten native gates in
[run 34421683563](https://github.com/ayooooo123/hyperdht/actions/runs/34421683563)
before publication. Its downloaded bundle parsed 26 pcaps / 2,765 packets,
11 close-window files and four firewall snapshots. All 26 real capture exits
were zero, none required SIGKILL, and the kernel-drop statistics were zero.
However, retained statistics exposed a separate shutdown defect: for example,
the endpoint reported 323 packets captured versus 428 received by its filter.
Zero kernel buffer exhaustion does not prove that tcpdump processed every
received packet; its [counter and buffering semantics](https://www.tcpdump.org/manpages/tcpdump.1.html)
distinguish these observations.

A real delivered-final-packet reproduction retained 0/1 packets on both endpoint
and guard captures, despite both filters receiving the packet and reporting no
kernel drops. The permanent projection regression failed 28/30. Capture startup
now uses `--immediate-mode` as well as `-U`: kernel delivery is immediate and
processed packet output is flushed, rather than leaving final packets buffered
when SIGINT stops capture. The reproduction retains 1/1 on both interfaces and the
projection gate passes 30/30. This fixes the demonstrated capture omission; it
does not establish the cause of the artifact-less historical KI-19 failure.

An injected supersession smoke also found that installation failure cleanup
checked the expected phase and manager but not the previous DHT identity. It
destroyed the superseding owner and its real route manager. Cleanup now mirrors
the exact ownership check; the same smoke passes together with the controller
checks, 14 tests / 117 assertions. The temporary state-access loader was removed
from the working tree; no production test hook or API was added. These two final
corrections require a new native run before publication.

Corrected commit `1ace943c3bc64824671233ad886629e9fdb0d86f` passed all ten
native gates in [run 34423201387](https://github.com/ayooooo123/hyperdht/actions/runs/34423201387):
Node aggregate 1,109 / 19,855, Bare aggregate 1,064 / 19,720, four normal/reverse
process legs 175 each, two production-punch legs 180 each, namespace projection
30, and live capture 185 with raw DROP zero. Linux and macOS formatting and
deterministic jobs passed. Downloaded evidence contains 26 valid pcaps / 2,962
packets, 11 valid close-window files and four complete firewall snapshots.
Every pcap count equals its tcpdump captured count and filter-received count;
all 26 exits are zero, no capture required a forced kill, and kernel capture
drops are zero. Both firewall DROP rules are zero in all four snapshots.
This is the corrected source's native acceptance, not a waiver of the earlier
local clock failure or historical KI-19.

Subsequent advisory review found that the drain wait still snapshotted registered
queries rather than holding the complete admitted attempt. A new internal
attempt registry now spans construction and discovery/commit gaps; active queries
remain the cancellation registry. The exact retired record's `lost` state now
invalidates drain/reply ownership, including loss reported after retirement.
Destroyed or already-lost ownership is rejected before invoking the clock, while
post-clock checks remain necessary for reentrant invalidation.

The shared third safety candidate is now opt-in for rotation fixtures. The broad
lifecycle case covers suspension alone; dedicated regressions cover valid sibling
drain and lost-branch reply rejection. Narrow package-private issuer seams retain
the formerly temporary supersession regression without adding a public API.
Native Linux Node and Bare each pass 55 tests / 540 assertions across the three
affected suites. Four mutations fail the intended regressions: waiting on query
snapshots, removing the DHT-identity cleanup guard, removing pre-clock liveness
checks, and removing lost-branch checks. These advisory repairs require their own
native aggregate/process/capture acceptance before publication; the earlier
`1ace943` acceptance does not cover this later source.

Candidate `b40649e` failed native aggregate acceptance in
[run 34433286596](https://github.com/ayooooo123/hyperdht/actions/runs/34433286596):
`branch loss survives controller refusal` reached a destroyed manager. The newly
strict lost-branch check correctly rejected readiness through a lost sibling, but
generation installation treated that rejection as terminal instead of preserving
recovery ownership. No process or capture acceptance was reached in that run.

The follow-on repair distinguishes failed admission from ownership transfer.
Rotation stages an owner without a DHT or query contexts while replacing a lost
sibling. Exact retired-record loss is now reported after retirement without
invalidating its replacement. Loss both during and after asynchronous readiness
keeps `READY` unobservable through old-transport retirement. A review also found
that unavailable teardown left its old state valid until endpoint closure; state
now invalidates synchronously before that await.

Native Linux Node and Bare each pass 67 tests / 643 assertions across the four
affected suites. Three additional isolated-file mutations fail their retained
regressions: omitting readiness-error recovery, omitting the post-readiness loss
check, and restoring the late unavailable transition. The transferred retired
owner/material are explicitly destroyed by the regression, matching existing
ownership cleanup. The failed candidate run remains evidence; the corrected
source still requires a new native aggregate/process/capture run.

Corrected candidate `5b4a1c0` passed Node aggregate 1,119 / 19,919, Bare aggregate
1,074 / 19,784, and all four normal/reverse process legs (175 assertions each)
in [run 34435307484](https://github.com/ayooooo123/hyperdht/actions/runs/34435307484).
Production-punch Node then failed 38/39 with `ERR_PRIVATE_GUARD_UNAVAILABLE`,
about 17 ms after both first-owned punch sends and exact tuple reflections.
The remaining punch and namespace/capture gates did not run. Prior guard traces
share one append-only log across process legs and cannot establish which inner
bootstrap check rejected this attempt.

One native Node 22 and eight bounded, instrumented Node 24.20.0 production-punch
probes each passed 180 assertions; they do not explain or waive the CI failure.
The bootstrap retry boundary previously discarded its actual rejection. It now
preserves the last rejection using the existing non-enumerable `Error.cause`
convention, while retaining the public `ERR_PRIVATE_GUARD_UNAVAILABLE` code.
The process harness already retains causal stacks. A native, fault-injected
authentication rejection is absent from the old fatal chain and visible after
this repair; that is diagnostic proof, not a reproduction of the unknown CI
cause. Bootstrap Node and Bare contracts pass 33 tests / 347 assertions each.

Later green runs are separate observations, not a fix or waiver for this one.

#### Later accepted runtime candidate

Candidate `f81aff5ea01a7021d4fc9cd7340b32f1890fab07` passed all three jobs in
[native run 34437120378](https://github.com/ayooooo123/hyperdht/actions/runs/34437120378),
including Linux/macOS deterministic checks and all ten live Linux gates.
The tested merge source was `e670c493ccaf2e5c3ea57909590db66ccc2dea7f`.
[PR #54](https://github.com/ayooooo123/hyperdht/pull/54) published these repairs as
merge `02bce1422de05c271260b1f37344d69dbe9afe23`; the canonical checkout was
fast-forwarded to that merge without changing public required-mode gates.

| Gate                                                | Observed acceptance                                    |
| --------------------------------------------------- | ------------------------------------------------------ |
| Node aggregate                                      | 1,119 tests / 19,919 assertions                        |
| Bare aggregate                                      | 1,074 tests / 19,784 assertions                        |
| Node/Bare normal and reverse-candidate process legs | 175 assertions each                                    |
| Node/Bare production-punch legs                     | 180 assertions each                                    |
| Privileged namespace projection                     | 30 assertions                                          |
| Privileged namespace live/capture                   | 185 assertions; raw DROP 0, classified teardown ICMP 0 |

[Capture artifact 10136630727](https://github.com/ayooooo123/hyperdht/actions/runs/34437120378/artifacts/10136630727)
contains 119 files. A separate downloaded-bundle scan verified all 26 PCAPs:
2,942 complete records, captured counts matching tcpdump logs, no truncated
records, all tcpdump exits 0, all shutdown records `forcedKill=false`, and no
kernel capture drops. All four firewall snapshots report raw DROP 0; all eleven
endpoint-close JSON files parse. Uploaded ZIP SHA-256:
`a7f39e5fe2c6ceae6e24e89590f365ddcbc881b09532f0155c1d3db7b02c3ae7`.
The per-file digest manifest and scan results are retained as
`local://native-34437120378-verification.json` in the ownership session.

This is acceptance of the later exact runtime source, not an explanation or
waiver of run `34435307484`. Its discarded inner error remains unavailable;
further causal diagnosis requires a newly captured failure or that missing
original evidence. No v2 peer-stream implementation, external cryptographic
approval, or public-mode approval is implied.

The automatic post-merge workflow also passed:
[run 34439259570](https://github.com/ayooooo123/hyperdht/actions/runs/34439259570).
GitHub's commit objects report the identical tree
`c5aaa6c5b3b5fa1a85ff06d958c0602519787a46` for the accepted candidate, tested
PR merge source, and published merge. This establishes exact source-tree
identity; the detailed downloaded-bundle verification above is specifically
for run `34437120378`, not a second bundle inspection.

### Delayed advisory follow-up — 2026-09-10

Reconciliation against the published head found two remaining runtime gaps:
configured-endpoint exhaustion wrapped the saved guard rejection again inside
the endpoint loop, and overlapping `networkChanged()` calls could finish a
second unavailable teardown while the first endpoint close remained pending.

The bootstrap loop now preserves its saved normalized rejection and wraps only
at final exhaustion. The controller synchronously transitions to UNAVAILABLE
and captures/nulls endpoint ownership, then publishes one retained cleanup
promise before any destructor callback. Concurrent callers, including the
OFF-state network-change path and terminal `destroy()`, await that operation.
UNAVAILABLE is terminal for this controller; the promise is not reset to
permit another cleanup.

Both observable regressions failed before the correction. The ownership,
rotation, authority, and SURB scenarios passed after it. The bootstrap fixture
initially expected a raw injected transport error; the real boundary normalizes
that error to ERR_AUTHENTICATION. Its corrected assertion requires that
normalized error as the immediate cause, rather than another guard wrapper.
The first shared-promise draft failed two stronger checks: immediate endpoint
ownership detachment and terminal destruction waiting for pending endpoint
closure. After correction, native Node verification passed97 tests/972
assertions across bootstrap, route manager, live authority, SURB, and aggregate
branch rotation. A redundant fixture-wiring assertion test was removed.
The retained tests exercise actual controller/bootstrap paths, not source-text
matches. Evidence includes `late-advisory-before.txt`,
`late-ownership-before.txt`, and `late-advisory-final-node.txt`.

The separate peer-stream prerequisite also now states explicitly that OFFER
duplicates and timer retries share the original eight-attempt response budget.
Fresh class-5 AEAD counters do not create fresh send allowance. This remains a
design contract, not an implemented peer-stream privacy claim.

### KI-1: routes are correlatable by timing and volume

**Status: accepted for v1. Not fixed, not scheduled in this gate.**

Every route cell is the same 1,200 bytes on every hop, so cell length is not a
correlator. Nothing else about the traffic shape is concealed: an observer of
two edges sees when each datagram was sent and how many there were, and the
route relays each cell promptly. An adversary who can watch both the
endpoint-to-guard edge and an exit-to-DHT edge can therefore link them by timing
and volume alone, without breaking any cryptography and without any protocol
error.

This is a property of the v1 design, not a defect in its implementation. v1
deliberately excludes
[a global passive observer, timing correlation by colluding guards and exits,
and constant-rate cover traffic](private-routing-v1.md#out-of-scope-for-v1),
because the padding, batching, or cover traffic that would address it costs
bandwidth and battery that v1 is not willing to spend, especially on mobile.

The
[Task 17 wire-level privacy evidence](#gate-3b1-task-17-wire-level-privacy-evidence)
is scoped accordingly: it proves what crossed which edge, never that two edges
cannot be linked. Any future claim of resistance to a two-edge observer requires
a wire-format change and its own sub-gate, and must not be inferred from the
current test results.

### KI-2: the eleven-role live scenarios only run on Linux

macOS and Windows refuse to bind the `127.64.x.1` role tuples without
per-address configuration, so the scenarios stop at the first bind with
`PROCESS_BIND_UNAVAILABLE` there.

They are therefore kept out of `test/private-routing.js`, which `test/all.js`
and `npm test` run on every platform, and are invoked from
`npm run test:private:process:node` and `npm run test:private:process:bare` in
the Linux CI job instead. Anything that binds a role tuple belongs in a
platform-gated script, never in the portable aggregate; putting it there turns
a known platform limit into a red build on macOS and Windows.

### KI-3: the namespace gates need privileged Linux

`npm run test:private:namespace` and `npm run test:private:namespace:live`
create network namespaces, veth pairs and iptables rules, and capture with
`tcpdump`. They require Linux with non-interactive root and skip elsewhere with
a stated reason. They are not part of the portable aggregate suite.

Both limits are limits of the host kernel, not of the gates, so a Linux
container satisfies them. `npm run test:private:linux-gates -- <gate ...>`
builds `docker/linux-gates.Dockerfile` and runs any of `aggregate:node`,
`aggregate:bare`, `process:node`, `process:bare`, `process:node:reverse`,
`process:bare:reverse`, `namespace`, `namespace:live`, or `all` in a privileged
container with the working tree bind-mounted. `all` includes both candidate
orders for both role runtimes, matching the Linux CI matrix. Explicit reverse
gates set their own candidate order even when the caller exports `normal`.
Dependencies live at `/node_modules` inside the image and a tmpfs shadows
`/app/node_modules`, so a host build for another platform is never loaded.
This gives a macOS or Windows workstation the same eight gates as Linux CI.
It does not replace that job: the
container shares the host kernel and its clock, so it is local evidence only,
and KI-4 timing behaviour still has to be judged on the runner.

Observed locally on macOS 25.5.0 arm64 with Docker 29.5.2 over Colima
(`linux/aarch64`), Node v22.23.2 in the image:

- `aggregate:node`: 876/876 tests, 18,106/18,106 assertions.
- `aggregate:bare`: 855/855 tests, 18,047/18,047 assertions.
- `process:node`: 1/1 test, 125/125 assertions.
- `process:bare`: 1/1 test, 125/125 assertions.
- `namespace`: 1/1 test, 27/27 assertions.
- `namespace:live`: 1/1 test, 135/135 assertions, marker datagrams 0,
  undecodable frames 0.

### KI-17: a routed get fails after a short idle following readiness

**Status: FIXED, two causes — one production, one harness. Found on the
unmodified scenario while placing the punch counters; not caused by NAT work.
The eleven-process gates now idle two seconds between readiness and the first
routed get, so the fix is defended by every process leg.**

Symptom. On the portable loopback `process:node` gate, a coordinator wait
between the endpoint's `ready` and the first `immutable-get` changed the
result: 1,000 ms passed; 2,000 ms failed the first get with
`ERR_PRIVACY_UNAVAILABLE`, meaning the routed query returned no value. A
pause of about 2.5 s after that get instead failed the blackhole rotation.

Production cause. `buildDhtExitOpenAuthorityMaterial` in
`final-exit-activation.js` set the DHT-exit open authority's
`absoluteDeadline` to `min(graceDeadline, localDeadline)`. The grace deadline
is OPEN + `FINALIZATION_TIMEOUT_MS` (5 s): it bounds finalization
retransmits, not the open route. That value flowed through
`dht-exit-reservation.js` into the exit's destination table, where every
admitted destination expires at `min(now + 300 s, expiresAt,
absoluteDeadline)` and `verifyDhtExitRoutedDestination` refuses a request
whose deadline exceeds the entry's expiry. A routed get carries a 3 s budget,
so any request issued more than about 2 s after OPEN was refused by the exit
and the endpoint's query drained empty. The same class of fault as the
extension-budget shortening recorded under the KI-4 history: an operation
budget carried as a route lifetime. Fix: the open authority is bounded by the
route's `localDeadline` only. Both the exit-side and endpoint-side authorities
come from the same builder, so both are corrected.

Harness cause. `test/private/process/wire-services.js` gave every
`LinkBootstrapSession` `absoluteDeadline = now + LINK_DEADLINE_MS` (5 s).
That is right for an initiate, which starts now, and wrong for a pre-armed
accept, which waits for a peer that dials whenever the route owner decides.
`receive()` computes `min(start + 5 s, absoluteDeadline, signedExpiry)` when
the first LINK CREATE arrives and fails closed when that is already past, so
every standby middle and exit arm died five seconds after activation. The
scenario's blackhole rotation normally lands at about 3.7 s and passed; two
seconds later it dialed dead arms and the endpoint reported `unavailable`.
Fix: accept-mode sessions are bounded by the grant's remaining lifetime
projected onto the monotonic clock; initiates keep the operation budget.
Production relays do not use this test link service, so this half is
harness-only, but the consumer integration that replaces it must not repeat
it.

Evidence. With the 2 s idle in place: unfixed tree fails assertion 35
(`ERR_PRIVACY_UNAVAILABLE`); production fix alone reaches assertion 48 and
fails the rotation (`unavailable`, generation 1, instead of `rotated`); both
fixes pass 136/136. Debug instrumentation used to identify the rejected event
was removed.

### KI-16: ordered UDP shutdown can produce kernel ICMP drops

**Status: classification approved, implemented, and verified on native Linux.**

The 2026-09-05 advisory verification passed seven Linux gates. The live
namespace gate reported one firewall drop, despite passing every UDP graph,
marker, and payload oracle. The original UDP-only capture could not identify
the dropped packet.

The capture now includes IPv4 traffic, and an audit with drops prints non-UDP
frames as well as the unchanged raw counter. A throwaway 750 ms pause
after the guard's stop command reproduced five dropped ICMP destination/port
unreachable replies. They quoted 1,200-byte route datagrams sent on allowed
adjacencies after the receiving endpoint or guard socket had closed. The
coordinator stops roles in sequence while later roles can still send link
heartbeats. This explains a real failure mechanism; the uncaptured packet in
the first run cannot be identified retroactively.

Six instrumented reruns and one ordinary run passed 146/146 without a drop.
Those passes do not resolve the shutdown race. A separate six-container
concurrency experiment hit command deadlines before its first lifecycle
assertion; it is not evidence about the original dropped packet.

No firewall exception, counter reset, skipped UDP assertion, delayed production
close, or packet-suppressing adapter was added. JD approved a narrow teardown
classification instead of a new acknowledged shutdown protocol.

The two read-only reviews found no existing peer-acknowledged shutdown barrier.
`LinkControlSession.destroy()` waits for local send completion, not peer
receipt; the receiver closes without an acknowledgement. A bounded delay
cannot prove that all peer datagrams have stopped.

Main rejected the first ICMP classification proposal: these kernel replies
contain only a prefix of the original datagram, so a full-cell comparison
cannot succeed. The original one-drop failure remains unattributed.

The replacement audit reads all eleven role captures and both marker captures.
It requires complete, checksummed, unfragmented IPv4; marker non-UDP traffic
never qualifies. Only ICMP type 3/code 3 with zero reserved bytes, a valid
checksum, and an exact quoted-prefix match to earlier allowed UDP traffic on
the same destination root-veth can qualify. The outer addresses must reverse
that exact firewall tuple. Duplicate records, missing provenance, other
protocols, malformed packets, and unmatched counters fail the gate.

Namespace-only instrumentation observes each real native UDP socket's close
call and successful completion without changing its returned promise or
shutdown order. Sidecars identify the exact host and port. Eligibility starts
three milliseconds after the sampled close-call time: one millisecond for
resolution plus two for observed clock uncertainty. This is a close-call
bound, not an exact kernel-unbind timestamp. Packets near that boundary remain
unmatched; uncertainty never backdates eligibility. Completion must precede
the audit, and observed realtime/monotonic drift over two milliseconds fails.
Coordinator receipt of the later `closed` event is not used as a close time.

The raw DROP counter is printed and checked before and after capture stops.
It must exactly equal the independently classified ICMP count in both
directions. No counter is decremented and ICMP remains blocked by the firewall.
Every existing UDP privacy assertion still runs over the full capture.

One follow-up run failed a new file-order assertion with raw DROP zero.
[Libpcap documents that packet queues can produce non-increasing timestamps](https://www.tcpdump.org/manpages/pcap-tstamp.7.html).
The audit no longer assumes global timestamp order. Quote proof still needs
both an earlier file record and an earlier timestamp. A later matching UDP
record cannot supply missing earlier evidence. Duplicate detection covers
records separated by different timestamps.

The native-close observer also had an error path that could throw before
calling native close. It now records the audit error and still closes the
socket. A real-socket regression injects a clock error, rebinds the same port,
and requires the audit to refuse the bad clock. Restoring the throw makes
that regression fail. Restoring the global file-order assertion fails the
valid reordered-traffic case; removing the file-index check fails the later
matching-record refusal case. The final focused checks pass 31 tests and
79 assertions.

The final full Linux matrix passes all eight gates: Node 975 tests / 19,051
assertions; Bare 932 / 18,923; four process legs at 136 assertions each;
namespace projection 27; live namespace 146 with raw DROP zero and classified
ICMP zero. On the same source, a throwaway 750 ms guard-stop pause produces
three raw drops and three classified replies, with all 146 assertions passing.
A separate injected ICMP echo produces one raw drop and fails assertion 146
with `ERR_TEARDOWN_ICMP: unmatched non-UDP packet`, as required. The native
firewall remains strict; the original uncaptured packet remains unattributed.

### Remote peer timing harness

Every gate above runs on one machine, so nothing measures this fork against a
host on another network. `.github/workflows/remote-peer.yml` holds up to five
peers open on runners for a chosen span, and `scripts/remote-peer.sh` times a
workstation against them:

- `scripts/remote-peer.sh secret --push` mints a 32-byte secret, keeps it in
  `$XDG_CONFIG_HOME/hyperdht-remote-peer/secret`, and sets the
  `REMOTE_PEER_SECRET` repository secret. Without `--push` nothing leaves the
  machine.
- `scripts/remote-peer.sh up -p 3 -s 300` dispatches three peers for five
  minutes, then measures all three at once.
- `scripts/remote-peer.sh local -p 3` runs the same harness against a local
  testnet, with no CI and no public network.

Peer and prober keys are derived from that secret plus the run id, so the DHT is
the only rendezvous: no key is a workflow input, none has to be scraped from a
runner log, and none is usable without the secret. Each peer pins its firewall to
the derived prober key. Per peer the probe reports connect time and attempts,
round-trip min/p50/p95 over 64 samples, and 1 MiB echo throughput; peers are
always measured concurrently, which is what exposes shared-socket and holepunch
contention that one peer at a time hides. Every read phase is bounded, so a peer
that accepts and then stalls fails in seconds naming the phase.

Observed against GitHub `ubuntu-latest` runners, run 31909702808, two peers for
300s, prober on a workstation behind a home NAT:

- Peer 1: connect 761ms on the 4th attempt, round trip min 31.7ms p50 36.1ms
  p95 115.7ms, echo 28.0 Mbit/s, remote 52.186.175.102:11265.
- Peer 2: connect 966ms on the 5th attempt, round trip min 31.9ms p50 36.0ms
  p95 111.8ms, echo 25.2 Mbit/s, remote 40.76.238.180:2049.
- Both runners reported `firewalled true`, `accepted 1`, and
  `echoed 1049088` bytes, which is exactly 64 pings of 8 bytes plus 1 MiB.
- Peer 1 also reported `rejected 1`: the stranger-key test was refused by a real
  remote peer, not only locally.
- Neither side counted a relay or a punch (`relaying.attempts 0`, `punches` all
  zero), and the prober's stream reported the runner's public address with a port
  that differs from the runner's local port. Which mechanism carried the
  connection is not established by these counters alone.

A second dispatch, run 31910008193, held five peers for 300s and all five
answered: connect 525..1,695ms, round trip p50 39.5..92.1ms, echo 3.1..21.6
Mbit/s, across five distinct runner addresses, 12/12 assertions. The spread is
the point of measuring peers concurrently: a single peer would have reported one
region's latency as though it were the number.

#### Runner-to-runner links

A single prober only proves workstation-to-peer reachability, which is not what a
private route needs: a guard must reach a middle and a middle an exit.
`.github/workflows/remote-mesh.yml` and `scripts/remote-mesh.sh` hold a mesh of
up to twelve runner members open. Every member derives every other member's key,
dials each higher index once, and answers a report request, so one collector
assembles the whole matrix. Success is a required link ratio plus a minimum
per-member degree, both defaulting to a full mesh, so a mostly-broken mesh cannot
pass.

Run 31910815472, ten `ubuntu-latest` members, 600s, 60s settle: 45/45 pairs
formed, every one on the first attempt, every member holding degree 9, 94/94
assertions. Connect p50 759ms, round trip p50 31.7ms, reconnect p50 276ms with a
worst case of 1,406ms. Reconnect is measured per pair because route rotation
depends on a link returning after a drop.

Cell-socket reachability was measured next, because a DHT link is not what
carries route cells. Each member binds a second UDX socket of the kind
`lib/private/udx-cell-endpoint.js:1401` binds, learns what address the world sees
for that socket, and punches every peer at once from the collector's plan.

Learning that address does not need an external STUN service. Every dht-rpc reply
carries a `to` field with the responder's view of the sender, which is how
dht-rpc fills its own `NatSampler` (`node_modules/dht-rpc/index.js:885`) and how
`dht.host`, `dht.port` and `remoteAddress()` are populated. That covers the socket
the DHT owns, and a NAT mapping belongs to a socket, so the cell socket is
reflected off two DHT bootstrap nodes with a PING built by this repository's own
client codec in `lib/private/dht-exit-wire.js`.

Run 31913403231 and run 31914488659, ten `ubuntu-latest` members each:

- 10/10 members reported the same mapped address from two different bootstrap
  nodes, so the mapping does not depend on the destination and one value per role
  is publishable to every peer.
- Mapped ports differ from local ports on every runner, for example local 40881
  mapped to 20.189.188.0:43970, so a local port would have been the wrong value to
  publish. An earlier attempt that published local ports recorded 0/90 arrivals.
- 90/90 directed cell-socket pairs arrived once the mapped address was used, with
  the source port intact on all 90.
- 10/10 members kept their mapping after closing a socket and binding a new one on
  the same local port, which is the order a distributed run needs: discover the
  endpoint, mint it into the signed capability, then let the endpoint bind.

Note for the private stack itself: `decodeDhtExitReply`
(`lib/private/dht-exit-wire.js:164`) rejects a reply whose `to` differs from the
local tuple, so the audited codec cannot be used unchanged for discovery behind a
NAT.

Two facts follow. Peer-to-peer links between NAT'd runners are reliable enough to
carry a distributed route topology, and a runner mesh can supply the two endpoint
peers plus eight or more route candidates that route choice needs. What it does
not yet do is carry private-route cells: `lib/private/udx-cell-endpoint.js:1398`
binds its own UDX socket with no injection point, and `lib/private/guard-link.js`
dials the endpoint bound into a signed relay capability, checked at line 627. A
distributed route run therefore needs each role's reachable endpoint discovered
first and minted into its capability, which is the next piece of work.

Observed locally, for comparison:

- Three peers on a local testnet: connect 18..19ms, round trip p50 0.4..0.5ms,
  echo 78..127 Mbit/s, 8/8 assertions.
- One peer over the public DHT on the same LAN as the prober: connect 1,328ms,
  round trip p50 0.4ms, echo 173 Mbit/s. This measures the LAN shortcut, not a
  cross-network path, so it is not evidence of remote reachability.
- A peer that accepts and never echoes failed in 15s with
  `ping 0 timed out after 15000ms` rather than hanging.

A peer inside the Colima VM is not reachable from the host prober. What the
diagnostics show: every prober attempt fails with `PEER_NOT_FOUND`, the peer
reports `firewalled true` and never accepts, and the only punch either side
counts is one random punch. So the peer is not discoverable through the DHT from
the host, and the cause has not been isolated further than that. Either way, a
remote peer belongs on a runner; the container stays for the kernel-dependent
gates above.

#### A route across separate hosts

`PROCESS_PLANS.DHT_MESH` builds the eleven-role topology from addresses discovered
at runtime instead of deriving `127.64.x.1`. Each role supplies two tuples,
because they are not the same address: a role binds a socket it owns, and
publishes the address peers must dial. Reachable values drive everything published
(advertisements, adjacency contacts, link specs, DHT peer lists, the firewall map,
the leak oracle's endpoint address); the bind tuple is used only where a socket is
bound, including a DHT role's own host and port.

`test/remote-peer/role-bridge.js` hosts one role on another machine. One byte
decides what a coordinator connection is for: ask for the role's addresses, or
attach and become the role's control stream. The role process itself is
`test/private/process/role-runner.js`, unmodified, so a distributed run executes
the same program the local gates do.
`test/remote-peer/role-channels.js` presents those streams to
`test/private/process/coordinator.js` as child processes, and
`test/remote-peer/live-route.js` supplies both halves to the existing scenario
through a `prepare` hook.

`scripts/live-route-rehearsal.sh` runs the whole path on one machine against a
throwaway DHT: eleven bridges answer with their addresses, the topology is minted
from those answers, eleven control channels open, and the scenario runs.

**Status: passing.** The rehearsal completes the whole scenario across eleven
separately hosted roles: 1/1 test, 132/132 assertions. Roles activate, the route
builds, traffic flows, every role stops on command and exits zero. Earlier 125-count
measurements below are retained as historical snapshots of their respective trees.

The last failure was in the transport, not the protocol. `live-process-suite.js:415`
ends the scenario by calling `expectExit` for every role, sending `stop`, and
asserting each exit code is zero, so a role exiting cleanly is the expected outcome.
`RemoteChild` listened only for the stream's `close` event, and a hyperdht stream
that the far side half-closes with `end()` need never reach `close` while this side
stays open, so no exit was ever reported and the coordinator burned its thirty
second scenario deadline. A remote `end` is now the role finishing: it settles an
exit with code zero and ends this side too.

Two further places where a stream-backed role differed from a spawned one were
measured and closed, both of which could have let a green run hide a fault.
`kill()` reported a zero exit, making a role that was cut down indistinguishable
from one that finished; it now reports no code and the signal, as a killed child
does. And the coordinator stops a role by ending its stdin
(`coordinator.js:549`), which a spawned role sees as EOF; the channel now
half-closes the stream and the bridge passes the EOF on, so a role waiting for it
is not left running.

`test/remote-peer/role-channel-lifecycle.js` holds those semantics with eleven
assertions over a real stream and no role process: byte fidelity in both directions
across many packets, a silent stderr, a graceful end producing exactly one exit with
code zero before the stream closes, a destroyed stream producing one failure exit
with and without an error listener, kill closing the stream, and a write after the
far side is gone reporting to its caller. The graceful-end assertion was checked
against the pre-fix channel and fails there, so it guards the bug rather than
describing it.

Setting `PR_BRIDGE_TRACE` to a path makes both halves of the transport write one
JSON object per line for every control frame, stream event and role exit, which is
how the teardown sequence above was read back. It is off unless the variable is
set.

A rehearsal needs one address per role, because the diversity rule rejects a set of
relays sharing a /24 (KI-5). Linux serves every 127/8 address, so the rehearsal runs
in the container from `docker/linux-gates.Dockerfile` with
`REHEARSAL_HOST_PREFIX=127.64`; on macOS the roles share 127.0.0.1 and the run stops
at that rule.

Getting that far drove out three layers that each treated a role's local address
and its published address as one value. They are equal only when nothing translates
in between, which is what a run across hosts breaks:

- `topology-fixture.js` now carries a bind tuple and a reachable tuple per role,
  and an exit also publishes the address of the second socket it binds at
  `role-runner.js:360` for reaching DHT nodes. No role can derive a peer's address
  under this plan, so they travel with the projection as `meshPeers`.
- `audit-event.js:373` built a record's addresses from the plan name. Under the
  discovered plan the two addresses a record binds are stated instead, encoded to
  the same nineteen bytes the derived plans produce.
- `dht-setup-audit-udx.js` compared one address against both the socket's own bind
  and the address a peer reports back. Those are now separate: the bind check uses
  the local address, the reply checks and the record use the observed one.

No transport question remains open, since 90/90 directed cell-socket pairs already
reach each other between runners.

### KI-7: a cell endpoint must be bound to the address it advertises

**Status: fixed. Found by running the topology across hosts, not by review.**

`lib/private/udx-cell-endpoint.js:1561` rejects a link whose handle carries a local
address different from the address the endpoint bound:

```
if (link.localAddress.host !== state.host || link.localAddress.port !== state.port) {
  throw PrivateRouteError.UNAUTHORIZED()
}
```

The check is sound as an ownership test, and it holds trivially in both derived
plans, where a role binds the same `127.64.x.1` or `10.203.x.2` address it
advertises. It cannot hold behind a NAT. A role there binds a private address or
`0.0.0.0` and is reachable at a translated one, so the address in its signed
capability is never the address it bound, and every `openLink` fails
`UNAUTHORIZED`.

This is what stops the distributed rehearsal after the DHT phases: `announce-exit`
rejects its incoming extension with `UNAUTHORIZED` from `openLink`. It is not a
harness problem. Any deployment where a relay or exit sits behind a NAT hits it,
which is most of them.

`UdxCellEndpoint` now takes an optional `advertisedHost` and `advertisedPort`.
Absent, they are the bound address, so every existing caller is unchanged. Stated,
they must be stated as a pair and are validated like any other address, and the
ownership check at `openLink` compares against them. The test is unchanged in
substance: the advertised pair is fixed when the endpoint is constructed and is
never taken from the handle. `endpoint-bootstrap-authority.js` passes the pair
through when given it, so the endpoint role's bootstrap path publishes the same
address as everything else; stating one field without the other is refused there
too. `test/private/udx-cell-endpoint-advertised.js` covers the pair rule, each
rejection, and the behaviour itself: a handle naming the advertised address passes
the ownership check while a handle naming the bound address is refused
`UNAUTHORIZED`. hyperdht keeps the same distinction for its own
socket through dht-rpc's NatSampler.

Three further plan-name whitelists surfaced behind it, each rejecting an unknown
plan: `role-runner.js` derived peer addresses from the plan, `audit-event.js:373`
derived an audit record's addresses, and `control-channel.js:993` accepted only the
two derived plans on the isolated-grant command. All three now handle the discovered
plan.

### KI-8: a branch loss is never delivered when a stale frame is queued unread

**Status: FIXED. The fault was in the routing code, not in the rehearsal. Diagnosis and
evidence are kept below because the mechanism is worth understanding and because three
earlier hypotheses were wrong.**

This entry was originally titled as an addressing fault and it is not one. Nothing in it
confuses a bound address with an advertised one. The rehearsal's divergent mode exposed it
by adding LATENCY, not by diverging addresses: the deciding variable is a 3.4ms window
between a cancel and a reply, which is why the untranslated mode reproduces it with no
translation anywhere and why identical addressing wins the race purely by being
loopback-fast. That matters for what the mode is worth. Its obvious value is catching
bind-versus-advertised confusion, and it caught three such faults; its second and less
obvious value is being the only mode with remotely realistic timing. Every mode here is
sub-millisecond loopback, so a real deployment loses this race MORE often than our worst
mode does.

The fix is recorded under KI-10, whose first half is the same fault: a live route
transport now drains its physical channel for as long as it is live, so an in-band
`BRANCH_DESTROY` is consumed on arrival whether or not the application is reading.

Proof, on a tree carrying the fix, read by rotation trigger rather than by assertion
number because both candidate faults failed the same assertion:

| mode      | runs | after the fix | rotation trigger     |
| --------- | ---- | ------------- | -------------------- |
| unmapped  | 5    | 5 of 5        | loss, +4.4 to +9.5ms |
| divergent | 5    | 5 of 5        | loss, +4.4 to +9.5ms |

The pre-fix counts are deliberately NOT tabulated beside those, because they come from a
different tree and are contaminated in the direction that would flatter the fix. The
pre-fix rates of 0 in 11 unmapped and 0 in 12 divergent were measured with instrumentation
active, and that instrumentation wrote with `appendFileSync` - synchronously, on the
calling thread - with one probe firing inside the very window that decides the race. Extra
latency there makes failure MORE likely, so those counts are a lower bound on the true
pre-fix pass rate rather than an estimate of it. No pre-fix rate on a clean tree exists and
none can be taken now without un-applying the fix.

So the claim here is deliberately not "it went from zero to green". It is that the
mechanism is fixed, proven by a probe-free before-and-after against committed exports
extracted from the pre-fix commit - a destroy behind one unread frame is not consumed at
queue depth 1 before, and is consumed at depth 0 after - and that the fixed tree is green
on the tree that ships. Attribution is unaffected by probe cost, since the comparison that
established it varied only translation while holding instrumentation constant across all
three modes, and its packet-level half rested on netfilter counters and a capture, which no
JavaScript timing can influence.

`lookupBranchExpiry`, which was the only trigger that ever fired before, is never the
trigger in any of the ten runs. The rebuild now starts on the loss it is supposed to start
on, claims at +15 to +23ms and emits `rotated` at +122 to +215ms.

FAULT B WAS NOT INDEPENDENT. The replacement middle extension - which took 4965ms and died
on its deadline in the one disturbed run where it was ever reached, and was null in all 21
pre-fix failures - completes in 98 to 175ms in all five divergent runs once Fault A is
fixed. It needed no fix. It was a single observation of Fault A's downstream consequence: a
rotation starting 9.7s late against a topology that had been idle for ten seconds. The
caution three reviewers insisted on, against writing it up as a second independent fault,
was correct.

`scripts/live-route-rehearsal.sh` gained a second addressing mode because a
rehearsal where every role binds the address it publishes cannot catch anything that
confuses the two. That mode found three faults which had all passed the same
scenario at 125/125:

- `role-runner.js` built the endpoint role's bootstrap authority without the
  advertised pair, so it alone published its bound address. Fixed; note that the
  KI-7 entry above already claimed this path published the same address as
  everything else, which was true of `endpoint-bootstrap-authority.js` and not of
  its caller.
- `wire-services.js` used one tuple both to bind an exit's DHT-exit socket and as
  the reservation's `local`, which is the address a peer's reply must echo
  (`lib/private/dht-exit-reservation.js:403`, `lib/private/dht-exit-wire.js:164`).
  Fixed by taking an optional advertised pair; the socket still binds the local one.
- `live-process-suite.js` recomputed the learned-closer isolated-address digest from
  a candidate's bound address, while `topology-fixture.js:1030` mints those grant
  pools from the reachable one. Fixed. This one was silent: a digest keyed on the
  wrong address throws nothing and logs nothing, the responder simply never matches,
  so no stack exists anywhere for it.

What remains open is a fourth observation, and instrumented traces have now disproved
this entry's original description of it. It is not that the rebuild fails. The rebuild
never starts, and a second unrelated fault then breaks the rotation that eventually does
start. Two runs, one per mode, instrumented identically, with times relative to the
injected fault:

| step                                       | identical | divergent |
| ------------------------------------------ | --------- | --------- |
| `fault-outgoing-physical-link` on middle-a | +0.0ms    | +0.0ms    |
| endpoint consumes `BRANCH_DESTROY`         | +2.8ms    | never     |
| `branch-physical-loss` at the endpoint     | +4.7ms    | never     |
| signal that starts the rotation            | +5.8ms    | +9656.0ms |
| kind of that signal                        | loss      | expiry    |
| replacement middle extension completes     | +65.7ms   | never     |
| `emit-rotated`                             | +142.0ms  | never     |

So there are two faults, and both are a packet that does not arrive. They are not yet
known to be independent: Fault A is measured in both modes and is solid, while Fault B
has been observed exactly once, in a run whose rotation had already been started 9.7s
late by Fault A, so its 5s build deadline was competing with a topology that had been
idle for ten seconds. Until Fault B is reproduced in a rotation that started on time, it
may be a consequence of A rather than a second fault.

Fault A. The `BRANCH_DESTROY` that middle-a emits toward the guard is never consumed by
the endpoint's route transport: `consumeM3RouteBranchDestroy`,
`lib/private/m3-adjacency-runtime.js:842`, never runs, so
`takeM3RuntimePhysicalLossState` at `:847` never runs and the loss sink registered by
`commitBranchConnection`, `private-routing-controller.js:519`, never fires. There is no
pending promise anywhere: the rebuild is not stalled mid-flight, it is never entered,
which is why raising the coordinator's command timeout twelvefold changes nothing. What
does eventually rotate the branch is `BRANCH_ROTATION_LEAD_MS`, `route-manager.js:36`,
a scheduled timer that fires 5s before the branch material expires and would have fired
at the same moment if nothing had been faulted at all. Because the shipped command
timeout is 5s and the earliest possible rotation is 9.7s away, Fault A alone is fatal:
a divergent run that passes is one where the `BRANCH_DESTROY` did arrive, so delivery of
that one control message is at least the dominant variable. Whether anything else also
varies is open until Fault B's status is settled.

Fault B, provisional on the caveat above. Once a rotation does start, the replacement
middle extension to lookup-middle-b
gets no response and dies exactly on `REPLACEMENT_BRANCH_DEADLINE_MS`,
`route-manager.js:38`, measured at 4965.6ms against a 5000ms budget. Identical mode
completes the same extension in 39.5ms. This is the first packet ever sent on the
guard-to-middle-b path, so nothing about it is a stale-state problem. The deadline fires
correctly and the failure is clean: `enterUnavailable` runs, the controller reaches
UNAVAILABLE, and the role emits `unavailable`. That is why a run with a raised command
timeout fails as `PROCESS_PHASE_MISMATCH` rather than a deadline.

Attribution: the rehearsal's NAT is exonerated, and Fault A is in the routing code. A
third addressing mode, `REHEARSAL_ADDRESSES=unmapped`, makes bound and published
addresses differ with no packet translation at all - roles bind `0.0.0.0` and are reached
at `127.65.<index>.1` via `ip addr add` plus a per-role route carrying
`src 127.65.<index>.1`, selected by an `ip rule` on source port, with all four netfilter
tables verified bare. Fault A reproduces there, and in both runs the trace shows the
`BRANCH_DESTROY` handed to the wire 2.3ms BEFORE the harness's link rearm dropped any
link, and never consumed:

| event                        | run 1     | run 2     |
| ---------------------------- | --------- | --------- |
| destroy emit begins          | fault+2.6 | fault+2.4 |
| destroy handed to the wire   | fault+3.4 | fault+3.2 |
| harness rearm drops links    | fault+5.7 | fault+5.5 |
| destroy consumed by endpoint | never     | never     |

So the message is sent, untranslated, and not consumed. That falsifies two earlier
hypotheses outright: translation loss, and a race in which the harness's rearm tears down
the link before the destroy is emitted.

The mechanism is KI-10's head-of-line blocking, recorded below, and the full chain is now
measured at a real fault rather than assembled from parts. Two unmapped runs, times
relative to the injected fault, agreeing to within a millisecond:

| event                                          | run 1  | run 2  |
| ---------------------------------------------- | ------ | ------ |
| the scenario cancels operation 2               | -5.1ms | -4.9ms |
| the in-flight reply arrives with no reader     | -1.7ms | -1.4ms |
| the pump declines to read and does not restart | -1.3ms | -0.9ms |
| the link is faulted                            | 0.0ms  | 0.0ms  |
| middle-a hands `BRANCH_DESTROY` to the wire    | +3.2ms | +3.3ms |
| the harness's link rearm drops links           | +5.1ms | +5.2ms |
| the endpoint consumes the destroy              | never  | never  |

So: the cancel removes the reader; the reply to the cancelled operation lands about 3.4ms
later with no waiter and is queued; the pump refuses to read while a frame is queued and
does not restart; the link is faulted 1.4ms after that; middle-a emits the
`BRANCH_DESTROY` and it reaches the wire; nobody ever reads it; the branch loss is never
delivered; the rotation never starts; assertion 41 fails. The window that decides a run
is the interval between the cancel and the reply's arrival, 3.4ms and 3.5ms in these two
runs. Identical addressing wins that race and the translated and untranslated divergent
modes lose it, which is why the same code passes 28 of 28 one way and fails the other.

The comparison is symmetric and the separation is total. Twenty-seven instrumented runs
across all three addressing modes, classified by one binary feature with no exceptions.
Every run of every mode queues exactly two route frames with no reader; the modes differ
only in when the second one lands:

| mode      | runs | outcome | second queue event | destroy consumed | rotation      |
| --------- | ---- | ------- | ------------------ | ---------------- | ------------- |
| identical | 6    | pass    | +542 to +618ms     | +3.85 to +4.37ms | loss-driven   |
| divergent | 12   | fail    | -1.3 to -3.1ms     | never            | never started |
| unmapped  | 9    | fail    | -0.5 to -2.4ms     | never            | never started |

The first queue event is common to all twenty-seven runs, at -160 to -262ms, and is always
drained by a later reader. The second decides the run: in all twenty-one failures it lands
inside the last 3.1ms before the fault, so the pump is already wedged when the destroy
reaches the wire 3-6ms later; in all six passes it lands more than half a second after the
fault, long after the destroy was consumed and the branch rotated. The clusters are
separated by more than 540ms with no overlap.

That yields the sharpest statement of the fault, and it is not the obvious one: a queued
frame is not the fault. Frames queue with no reader twice per run, in healthy runs, in
every mode, and are drained harmlessly. The fault is a frame queued in the roughly three
milliseconds before a branch dies. Any fix or test that keys on "a frame was queued" will
look correct and prove nothing.

The trace-based finding is corroborated at packet level by an independent instrument. A
divergent run that reached `not ok 41` was observed with pure-counter netfilter chains and
`tcpdump` on `lo`, 272 packets captured across 17 samples:

- The DNAT and SNAT rules for roles 5 and 6 - `lookup-middle-b` and `lookup-exit-b`, the
  replacement pair - counted ZERO for the entire run, and no packet to either appears
  anywhere in the capture. The guard never dialled either one. Fault A stops the rebuild
  before a single replacement packet reaches the wire.
- No rule stopped matching: counters are monotonic across all 17 samples. No UDP mapping
  can expire, since the scenario is 6.8s end to end against a 30s unreplied timeout, and
  `conntrack_count` rose monotonically to 436 against a maximum of 262144.
- The uncovered-port catch-all counted zero packets, and every one of the 272 captured
  destinations falls inside the covered set. The earlier hypothesis that a rebuild might
  use a port the rules did not cover is dead by measurement rather than by reading.
- Zero packets escaped SNAT: 250 translated, 0 untranslated, measured in `filter INPUT`
  after both nat hooks. So nothing was silently discarded by a peer's source check.

Two tooling limits are worth stating rather than leaving implicit: `conntrack(8)` is absent
from the image and `/proc/net/nf_conntrack` does not exist, so per-flow listing was
impossible and only aggregate counters were available.

A limit on every load figure in this document, and on every timing number that depends on
one. The container VM has four vCPUs, not the host's ten, and three unrelated long-lived
containers share it - a relay and two Postgres instances, up four and seven days. They were
idle when measured, but idle-when-measured is not idle-at-the-time, and no run here was
taken with them stopped. So every recorded load average has an unmeasured floor under it.
This does not undermine the findings, because the load-bearing evidence is mechanism-level
and comparative rather than rate-level - a before-and-after on committed exports, and
comparisons that hold instrumentation and machine constant while varying one thing - but any
absolute rate in this document should be read as an observation under uncontrolled load
rather than as a measurement of the code alone.

Worse, every load figure recorded here is the macOS HOST one-minute average sampled before
the run, and no harness ever sampled inside the guest. That number is nearly blind to what
the container's four vCPUs were actually doing: the whole VM is one host process, so even a
fully saturated guest contributes only about four to six to the host figure. A host average
materially above that implies work outside the VM entirely - which, during this batch, means
the agents' own tooling, since a lease that disciplined containers never covered anyone's
`node`, `git` and `python` on the host. Two instruments that look like the answer are not. Guest `/proc/loadavg` reads 0.14-0.47
while the host is at 12-14, because host oversubscription DESCHEDULES the guest's vCPU
threads rather than lengthening the guest's runqueue - the guest runs slower in wall-clock
without its runqueue growing, so guest loadavg would read the same whether the hypervisor
gets full time or a third of it. Steal time, the normal metric for exactly that, is flat
zero in `/proc/stat` because colima on Virtualization.framework does not report it to the
guest. So neither reveals host starvation from inside a container on this setup.

What does work is timing a fixed amount of work inside the guest, and the harness already
records one: the scenario's own duration. Runs cluster tightly at 2775-3157ms across two
harnesses and three modes, so a run well outside that band had its vCPUs descheduled
whatever loadavg said. That is a zero-cost instrument, already present in every log.

One indirect guest-side measure does exist, and it is the only one in this document. The
trace intervals above are measured between lines inside a single container, so unlike a host
average they stretch under guest contention. Across the twenty-seven classified runs the
destroy was consumed at +2.8 to +4.4ms in six identical runs - a 0.5ms spread - with
emit-sent at +3.0 to +6.0ms and the deciding queue event at -0.5 to -3.1ms across
twenty-one failures in two modes. A guest under real contention does not hold a 0.5ms spread
on a millisecond-scale interval six times running, so the corpus behind this diagnosis was
taken on a guest that was not meaningfully contended - inferred from the intervals
themselves rather than from a figure nobody sampled. Note also what this does NOT cover: the
separation between clusters is 540ms, three orders of magnitude beyond any scheduling jitter
that could survive in intervals this tight, so contention cannot flip a classification
either way.

That inference is scoped to that corpus and must not be read as a claim about the session.
At a coarser grain the same guest was NOT stable: gate scenario wall times moved -1.3%,
+6.3%, +26.3% and -39.9% between two runs of the same four gates, with identical assertion
counts in every pair. Millisecond intervals inside one container over twelve minutes were
tight; multi-second scenario times across forty minutes swung by up to 40%. Both are true and
they measure different windows at different resolutions. Whether that swing is guest
contention, Bare runtime startup variance, or a real timing cost of the pump reading more is
unresolved - what it is not is a change in work, since every assertion count in those pairs
is identical.

Fault B is unreachable before Fault A is fixed, and that is measured rather than assumed:
`middleExtensionOpen` is null in all twelve divergent and all nine unmapped runs, so the
rebuild is stopped before the replacement middle extension is ever attempted, twenty-one
times out of twenty-one. No pre-fix capture in any mode can settle whether Fault B is
independent. Only post-fix runs can, read by rotation trigger rather than by assertion
number, since both faults fail the same assertion.

One measurement note that supersedes the rate table below for divergent. A later batch ran
twelve divergent rehearsals with the tree state and host load recorded for the first time
and found zero passes. Under the earlier 22% estimate twelve consecutive failures has
probability 5.4%, so this does not falsify the older figure, but the older figure was
measured under unknown load against an unrecorded tree and this one was not. Do not quote
22% as a post-fix baseline without that caveat.

Measured across two independent batches on the same image, counting runs that
reached 125/125. The second batch was run by a different party against the same tree
precisely because the first batch's stronger claim, that the failure had become
consistent, did not survive checking:

| batch  | mode      | runs | reached 125/125 |
| ------ | --------- | ---- | --------------- |
| first  | divergent | 33   | 6               |
| second | divergent | 12   | 4               |
| first  | identical | 15   | 15              |
| second | identical | 7    | 7               |

So it is intermittent, roughly one run in four passing, and not a failure that has
settled into always happening: an earlier draft of this entry claimed twenty-one
consecutive divergent failures, and twelve consecutive runs then produced four
passes. What is consistent is where it stops. Every one of the twenty divergent
failures across both batches stopped at the same place, assertion 41,
`PROCESS_COMMAND_DEADLINE`, with 40 of 41 assertions passing. Identical addressing
has never failed in 22 runs.

Because of this, divergent is not the default: a mode that passes 10 runs in 45 would
either be muted or be rerun until green, and rerunning until green is how the fault
it exposes disappears from view. Reproduce it with the documented container rehearsal
plus `--privileged` and the mode flag:

```
DOCKER_CONFIG=/tmp/hyperdht-private-routing-linux-gates-docker \
DOCKER_HOST=unix:///Users/jd/.colima/default/docker.sock \
docker run --rm --privileged --mount type=bind,source=$PWD,target=/app \
  --mount type=tmpfs,destination=/app/node_modules \
  --mount type=tmpfs,destination=/root/.config \
  -e REHEARSAL_ADDRESSES=divergent -e REHEARSAL_HOST_PREFIX=127.64 \
  -e XDG_CONFIG_HOME=/root/.config \
  -e BRITTLE_NODE=/node_modules/.bin/brittle-node \
  -e REMOTE_PEER_COORDINATOR_SECRET=<64 hex> \
  -w /app hyperdht-private-routing/linux-gates:ffd5f7f04db9 \
  bash -c 'mkdir -p /root/.config/hyperdht-remote-peer && printf "%s" "<64 hex>" \
    > /root/.config/hyperdht-remote-peer/secret && bash scripts/live-route-rehearsal.sh 240'
```

### KI-9: an expiry signal arriving during a rotation is lost permanently

**Status: FIXED. A production fault, not a harness artifact. Found by instrumenting a
rehearsal, not by review. The diagnosis below is kept because the mechanism is the
reason the fix is level-triggered rather than a queue.**

A branch expiry signal that arrives while the controller is `ROTATING` is dropped, and
the state needed to reissue it is destroyed at the same moment, so that branch never
rotates again for the life of the controller. `private-routing-controller.js:272`
refuses any signal delivered in a state other than `READY`, which alone would only
delay it. What makes the loss permanent:

- `route-manager.js:274-281`, `issueBranchSink` nulls `state.lifecycleSinks[key]`
  before issuing, and the signal is one-shot: it is consumed and added to
  `SPENT_SIGNALS` at `private-routing-controller.js:321-325`.
- `route-manager.js:314` deletes the handle from `state.branchExpiryTimers` before
  issuing, and `armBranchExpiry` is re-entered at `:322-324` only when the expiry has
  moved further out, which on this path it has not.
- `registerReplacementLifecycle`, `private-routing-controller.js:461-472`, recreates
  expiry sinks only for the branch class being rotated, never the other one.

So after the drop there is no sink and no timer for that branch class. The two branches
expire on independent clocks and a rotation takes seconds, so a lookup rotation that
overlaps the announce branch's expiry silently retires the announce branch's only
rotation trigger.

Observed in an instrumented divergent rehearsal: an `announceBranchExpiry` signal
arrived 11072.4ms into the run with the controller in `ROTATING`, 130ms after a lookup
rotation began, and was discarded with nothing rearming it.

This is independent of KI-8. KI-8 is about which signal starts a rebuild, and whether
the message that should start it arrives at all. This is about a signal that does
arrive, at a moment the controller cannot accept it, and is then unrecoverable.

The fix keeps the condition standing rather than queueing the event. A refused
`lookupBranchExpiry` or `announceBranchExpiry` delivery makes the controller mint a
replacement sink for the emptied slot, `private-routing-controller.js:298-302`, and
`renewRouteManagerBranchExpiry`, `route-manager.js:1235-1250`, re-arms the manager's
own clock at `BRANCH_EXPIRY_RETRY_MS` of 250ms - well inside
`BRANCH_ROTATION_LEAD_MS` - so redelivery does not depend on the controller reaching
any particular state. Only an empty slot can be filled, so a live sink is never
displaced. KI-10 now retains a refused branch loss separately on the published
branch and redelivers it after READY; expiry is no longer its recovery backstop.
Regression coverage for expiry remains
`test/private/branch-expiry-rotation.js:271`, which refuses an announce expiry during a
lookup rotation and asserts the redelivered signal rotates the announce branch.

### KI-10: native blackhole detection and refused-loss redelivery

**Status: native blackhole detection and refused-loss redelivery fixed.**
Loss reports now name the generation owned by the physical registration or live
route IO owner. RouteManager rejects a retired generation before changing
capabilities or recording fault demotion. A matching loss received during either
branch's rotation remains on the current published branch object.

The controller treats a loss signal as a wakeup, not as authority to lose an
arbitrary current branch. It checks the current manager-owned loss, restores a
refused one-shot sink, and redelivers standing losses in the `pairReady`
handler after `await installReadyGeneration(state)` completes, including old
transport teardown. No additional `dht.ready()` wait changes controller startup.
Replacement discards the old branch's lost flag; loss during that branch's own
build does not spend the replacement's lifecycle sink. Teardown destroys the
pending branch state. No loss retry queue, retry timer, or direct fallback is added.

`test/private/branch-expiry-rotation.js` reproduces both refusal windows: two
reports queued before the first controller transition, and a sibling report
issued after RouteManager enters ROTATING. Recovery completes with the lease
clock unchanged. It also checks delayed retired registrations and loss of a
branch already being replaced.
The retiring-branch regression also faults its replacement to prove that the
new loss sink remains usable. A network change with pending sibling loss
removes request authority and prevents recovery from restoring it. The shared
test harness now encodes its complete deterministic counter instead of
wrapping a byte-fill sequence into an invalid all-zero route identifier.
Failed replacement publication also requires the old branch to be both unexpired
and not lost before READY can be restored. A same-branch-loss regression fails
when `!current.lost` is removed: the old code reports ready and returns the
rotating error instead of `ERR_PRIVACY_UNAVAILABLE`.

This is separate from the verified silent-link detector. The head-of-line
blocking fault was closed with KI-8. Commits `d00ecef` and `6468028` added an
eleven-process proof of the existing detector; they did not introduce a new
heartbeat protocol.

`installLinkControl` in `lib/private/udx-cell-endpoint.js` installs a production
`LinkControlSession` on each authenticated adjacency. Its `runLiveness` sends
PING at `LINK_PING_AFTER` (500ms) and closes an adjacency after
`LINK_UNRESPONSIVE_AFTER` (1,500ms) without accepted activity. `closeState`
notifies circuit ownership and closes the physical link. M3 propagates that
loss to the controller and RouteManager. This is application link control
carried by UDX datagrams, not a native UDX per-peer close event.

`test/private/live-process-suite.js` leaves both healthy branches without
application traffic for two seconds, then blackholes the selected lookup
middle's route cells in both directions. The middle's process, bound socket,
bootstrap traffic, and test control stream remain alive. The scenario requires
a fresh lookup generation within five seconds, an unchanged healthy announce
generation, an exact immutable get through the replacement, and successful
suspend/resume and teardown. Elapsed detection time uses a monotonic clock.
Every selectable middle can receive the fault, including `announce-middle`;
role labels do not determine which branch uses a relay.

Scope: this proves complete bidirectional route-cell silence in the local
eleven-role topology. It does not prove loss tolerance under arbitrary delay,
a remote-network latency bound, or detection of a malicious relay that answers
heartbeats while discarding application cells. L0 still bounds an outstanding
operation. The existing heartbeat also reveals idle adjacency activity; fixed
cell size is not traffic-analysis resistance.

#### Historical diagnosis — before 2026-08-30, superseded

The original pump fault stopped `pumpM3RouteTransport` whenever
`record.received` held an unread frame. A `BRANCH_DESTROY` behind that frame was
never consumed because neither recursion nor the re-pump path restarted the
reader. The original measurement compared two cases:

| Historical case                        | Destroy consumed | Channel depth |
| -------------------------------------- | ---------------- | ------------- |
| Branch destroy alone                   | true             | 0             |
| Branch destroy behind one unread frame | false            | 1             |

Cancelled operations could leave a late reply without a reader. The same pump
served endpoint requests, DHT exits, and final-exit activation, so the KI-8 pump
fix addressed all three consumers. This table records the pre-fix failure, not
current behavior.

An early rehearsal reported a route change only after 9,656ms, at lease
rotation. The original diagnosis incorrectly concluded that no keepalive or
adjacency timeout existed. A later blackhole probe contradicted that premise:
it observed detection in about 1.48–1.52 seconds while idle and 1.30–1.34 seconds
with a get outstanding, versus about 14.7 seconds of no-fault silence.
Disabling the L0 operation deadline did not materially change those results.
At that point the detector had not been identified.

Commits `d00ecef` and `6468028` replaced that uncertainty with the production
`LinkControlSession` path and the native eleven-process blackhole gate described
above. The earlier claims of lease-only discovery, an unknown detector, and
unfixed idle pump blocking are withdrawn. They must not be used as reasons to
implement the unratified L1/L2 proposal.

The historical KI-8 field attribution remained uncertain: the proposed stale
frame had to arrive before the destroy, while one identical-addressing run
consumed the destroy after 2.8ms and took about 70ms for a routed get. That
uncertainty concerns the cause of a past field occurrence, not the current
native detector or the fixed pump.

### KI-11: a teardown phase mismatch, window found and closed

**Status: the window is CLOSED in the harness and the closure is confirmed by a
deliberate provocation that reproduces the exact failure on demand in 0.11s. What is
still open is attribution: the provocation proves the mechanism exists and that the fix
removes it, NOT that this mechanism is what produced the one field occurrence. That run
remains unmeasurable after the fact.**

One divergent rehearsal on the fixed tree failed at
`not ok 71 - PROCESS_PHASE_MISMATCH (lookup-exit-a/CONTROL)`, 70 of 71 assertions, where
assertion 71 is the first of the teardown loop, `t.is(snapshot.state, 'CLOSED')` at
`live-process-suite.js:499`. The run passed the rotate at 41, suspend and resume at 55-66
and network-change at 69-70, so it is a different phase and a different failure mode from
KI-8, which always failed at 41 with `PROCESS_COMMAND_DEADLINE`. A phase mismatch fires
when a role's phase sequence has advanced past what the suite believes, so it needs ONE
unexpected event from one role, not a slow run.

An interleaved A/B in identical mode - the only mode reaching teardown on both trees,
since every pre-fix divergent run stops at 41 - found nothing: eight runs with the KI-10
fix reverted and eight with it present, alternating on one machine, zero occurrences of
assertion 71 in either arm. At a 1-in-31 rate that is an underpowered null and not
evidence of absence. It was run with the guest effectively idle (VM load 0.39 while the
host read 11-13), so it is not an under-load result. Its one useful incidental: the two
arms' scenario bands overlap and the fixed arm's is slightly tighter, which is mild
matched evidence that the KI-10 fix costs no measurable wall time.

A second-order effect of the KI-10 fix was the original suspicion and remains DISFAVOURED
BY SOURCE, on two counts. First, a retired exit's route transport is DESTROYED rather than
wedged: retirement awaits `finalExitService.destroy()`, which reaches
`destroyDhtExitRouteTransportForIO` via `closeState`, `dht-exit-io.js:887-892`. A destroyed
transport cannot be wedged or drained, and teardown is 2.8s later. Second, and decisively,
the premise was wrong: LOOKUP-EXIT-A IS NOT RETIRED AT TEARDOWN. `retainForSuspend()`
clears `state.committed`, and `resume()` at `relay-candidate-directory.js:892` then calls
`choosePairs(state, now)` with NO exclusions, which returns the first diverse quad in
record order - and that order is the guard's fixed projection array, so resume re-selects
`lookup-middle-a` with `lookup-exit-a`. The suspend and resume at assertions 55-66 put
exit-a back in the live path before teardown. "The failing role is the retired exit", the
detail that made the fix look implicated, is simply false.

#### The mechanism, now measured rather than inferred

The harness's own control protocol had a race, independent of route transports and
therefore of the KI-10 fix. It is no longer an inference. Each of its three steps is in
source and the whole is reproducible:

1. Every event is validated against a single scalar, and by EXACT EQUALITY:
   `baseMessage` rejects the message unless `context.phaseSequence === phaseSequence`,
   `control-channel.js:964`. There is no tolerance for the immediately preceding phase.
2. `dispatch` maps any validation throw to one code:
   `PROCESS_PHASE_MISMATCH`, `coordinator.js:343-348`, which is also the catch-all for
   every other event validation failure.
3. The coordinator's expected phase for a role is advanced BEFORE the command that carries
   the new phase is written, because `send` validates the outgoing command against
   `record.phaseSequence`, `coordinator.js:481`. Advance-then-send is structural, not a
   choice the suite makes.

So for any role that speaks unprompted, every phase advance opens a window: an event
already emitted and not yet read carries the OLD phase, and is refused. By teardown
exactly one role class still speaks unprompted. Every `emit` site in `role-runner.js` is
either a direct answer to a command or one of `isolated-grant-request` (the three exits,
raised whenever the exit's own discovery finds an isolated candidate) and the endpoint's
`rotated` and `unavailable`, which are gated on `state === 'READY'`,
`role-runner.js:920-934`, and the terminal network-change immediately before teardown
leaves the endpoint UNAVAILABLE. The window is therefore an `isolated-grant-request`
overtaking the teardown loop, which accounts for the role identity, the phase, and why the
failure has never appeared at any other assertion.

#### The obvious fix is not the fix

The earlier proposal, and the one this batch was briefed with, was to stop the
learned-grant responders BEFORE the teardown loop instead of in its `finally`. That cannot
close this window, and the reason is worth stating plainly because it is easy to
re-derive wrongly: THE REQUEST IS EMITTED BY THE ROLE, NOT SOLICITED BY THE COORDINATOR.
The responders are coordinator-side standing waiters. Stopping one cannot unsend a frame
already in the pipe. The provocation confirms this directly rather than by argument: the
`stale` arm below never answers a single grant - it is run with granting already stopped -
and it still reproduces the mismatch.

Stopping the responders early is kept anyway, as hygiene, for two reasons that are its own
and not the window's:

- A grant answered after the advance is refused by
  `observed.phaseSequence !== record.phaseSequence`, `coordinator.js:516`, and
  `respondIsolatedGrant` throws SYNCHRONOUSLY there. The suite's
  `await control.respondIsolatedGrant(...).catch(noop)` cannot catch a synchronous throw,
  and `.then(onFulfilled, noop)` handles the SOURCE promise's rejection rather than its own
  handler's, so the throw escaped as an unhandled rejection - which takes the entire run
  down, not one assertion. Reachable today: a request dispatched at the correct phase
  resolves the waiter, the loop advances that role's phase at the next `await`, and the
  queued handler then calls into `respondIsolatedGrant`. The handler is now wrapped, so a
  future ordering cannot be fatal either.
- An exit handed a grant mid-teardown admits the closer and restarts the very discovery
  that emits the next request. Unanswered, it cannot: `requestIsolatedGrant` throws while
  one request is pending, `role-runner.js:335-342`, so at most one request per exit exists
  during teardown.

Withholding the grant is safe on the role side, which was checked before relying on it:
`stopOwners` rejects a pending isolated grant with `PROCESS_CANCELLED` before destroying
the exit service, `role-runner.js:816-821`, so an unanswered request cannot wedge the
`stop`. `stopGranting()` deliberately does NOT disarm the standing waiter - only `stop()`
does, in the `finally` - because a request that still arrives must be tolerated rather than
become `PROCESS_UNEXPECTED_EVENT`.

#### The fix

A round trip at the phase already in force, per role, immediately before that role's phase
is advanced: `live-process-suite.js:486`, ahead of the advance at `:487-489`. A role's
events reach the coordinator as one FIFO stream decoded in order, so once this snapshot has
been dispatched, every frame that role emitted earlier has been dispatched too, under the
phase it was emitted with. That is an ordering proof rather than a delay.

Three properties made this cheap. Re-sending at the current phase is legal because the
runner adopts whatever phase a command carries, `role-runner.js:968`, and it is already an
established pattern in this suite - both `immutable-get`s in the resume path reuse
`phases.get('endpoint')`. A `snapshot` command is pure, `role-runner.js:1050-1052`. And the
extra snapshots are audit-neutral: `validatePostSetupState` returns early for snapshots,
and for DHT roles every field `validateDhtSnapshot` constrains is structurally fixed,
because `snapshotFields` derives them from controller, wire and exit snapshots that are all
null for those roles, `role-runner.js:740-772`.

Rejected shapes, with reasons, so they are not retried:

- Sending `stop` at the current phase with no advance at all. This closes the window
  completely and was rejected anyway: it would let a stale event from the network-change
  step be accepted during teardown, which is a real loss of the phase separation the
  equality check exists to provide. Not a check worth weakening for a 1-in-64 event.
- Draining by yielding the event loop. Timing-shaped, no ordering guarantee, and it would
  read as a fix while proving nothing.
- Reordering the loop to stop the DHT roles first, starving the exits of referrals. Too
  clever, and it perturbs the wire record the namespace oracles read.

#### The provocation

`test/private/process/teardown-phase-window-probe.js`, standalone and deliberately NOT
registered in `test/private-routing.js` so its assertions cannot move the aggregate's
counts. Run it with `node test/private/process/teardown-phase-window-probe.js`; set
`PR_BRIDGE_TRACE` to also append the trace, in the same JSON-per-line shape the bridge's
own sniffer uses, `frameSniffer` in `role-bridge.js`. It drives the REAL coordinator with a synthetic role
that is a pair of streams, and models exactly one thing explicitly: `outbound`, the bytes
that have left the role and that the coordinator has not read yet. A frame's phase is
stamped when the role emits it, which is what makes a delayed frame stale; whether the byte
landed a microsecond before or after the advance is invisible to the coordinator.

Three arms, differing only in where the coordinator's read falls relative to the advance.
0.11s for all three:

| arm       | order                                                 | result                                           |
| --------- | ----------------------------------------------------- | ------------------------------------------------ |
| `control` | advance with NO frame in flight                       | no failure - the advance alone is harmless       |
| `stale`   | advance, then read (shipped order, no grant answered) | `PROCESS_PHASE_MISMATCH (lookup-exit-a/CONTROL)` |
| `drained` | read at the current phase, then advance (fixed order) | no failure; the request is accepted at phase 5   |

The stale frame, named by the trace:

```
{"t":1786915234793.8203,"side":"probe","pid":69822,"event":"frame","direction":"role->coordinator","type":"isolated-grant-request","generation":"7","phaseSequence":"5","queued":true}
```

`phaseSequence: "5"` is the phase in force when the exit emitted it; the coordinator
advanced to 6 before reading it. The `control` arm is what makes this attribution rather
than coincidence: the same advance with no frame in flight is clean, so the frame is the
cause and not the advance. The same run also confirms the second hazard directly - a grant
answered after the advance returns `PROCESS_CONTROL_INVALID` from `coordinator.js:516`,
observed in the `drained` arm.

What this establishes and what it does not. It establishes that the window is real, that
the shipped teardown order reproduces the exact recorded failure signature on demand, that
stopping the responders alone does not prevent it, and that reading before advancing does.
It does NOT establish that this is what happened in the one field occurrence. That would
need the failing run instrumented, and it was not.

#### What is left

- A residual window remains, one round trip wide instead of the whole loop wide: an exit
  can emit between answering the drain snapshot and receiving its `stop`. It cannot emit
  twice, because granting has stopped. A COMPLETE closure is not reachable from the suite:
  it needs either events validated against the phase in force at EMISSION rather than at
  read, or the `phase-pending`/`phase-ack` pair - which is fully defined and validated in
  `control-channel.js:1023-1026` and `:1130-1137`, exercised only by the codec tests, and
  wired to nothing. That pair looks like exactly this drain barrier, designed and never
  connected.
- The same advance-while-armed shape still exists, narrower, at the exit snapshot step,
  `live-process-suite.js:391-394`: it advances all three exits' phases while the responders
  are necessarily still granting, because the resumes ahead of it need grants. Not closed by
  this change and never observed; recorded so it is not rediscovered as new.
- Whether guest starvation occurred in the field run - fixed-work timing inside the guest,
  since the four instruments below cannot see it.

#### Why the field run cannot be re-read

The load explanation for that one run is neither confirmed nor excluded. It recorded a host
load of 15.31 against 2.39-3.73 for the five runs before it, with a decaying tail across
four subsequent runs that all passed. Four instruments were considered and each is blind to
what matters:

| instrument               | why it cannot answer                                                                  |
| ------------------------ | ------------------------------------------------------------------------------------- |
| host load average        | the whole VM is one host process, so it is nearly blind to guest saturation           |
| guest `/proc/loadavg`    | host oversubscription deschedules vCPU threads without lengthening the guest runqueue |
| steal time, `/proc/stat` | flat zero; colima on Virtualization.framework does not report it                      |
| scenario wall time       | a 3s aggregate; a 20ms stall moves it 0.7% and vanishes in the 2775-3157ms band       |

A fifth does work: timestamped trace intervals inside the run, which sample at millisecond
scale and show a transient stall directly, because a descheduling in the wrong place
stretches one interval while leaving the total untouched. That run carried none, correctly,
since it was measuring the shipping tree. Any future hunt for a millisecond-scale race here
must instrument the run itself; nothing outside it can see in.

One process note, and it is NOT "read the code first", because that rule would have failed
the KI-8 investigation. Ask whether the question is STRUCTURAL or EMPIRICAL before choosing
the instrument. Structural questions ask whether something can happen, whether a path
exists, whether a state is reachable. Empirical questions ask whether it does happen, how
often, under what conditions. Nothing that cracked KI-8 was answerable from source, and
every expensive detour there was a structural question attacked empirically. This entry is
the same lesson from the other side: "can a stale frame fail the phase gate" is structural,
and a 0.11s rig answered it and the fix's adequacy together, where sixteen interleaved
three-second runs had answered neither.

#### Verification of the fix

- `process:node` 125/125 three times, 3675ms cold then 2816ms and 2819ms, both inside the
  documented 2775-3157ms band, so eleven extra round trips cost nothing measurable.
- `process:bare` 125/125.
- Host aggregate 882 tests and 18138 asserts, which was the baseline at the moment this was
  measured and is not quoted here as the standing one - other slices in the same batch
  registered tests after it. The durable claim is the delta: this change adds no test and no
  assertion, so it moves the aggregate by zero whatever the baseline is. Note also that a
  host aggregate is NOT evidence about the eleven-role scenario, which it does not contain,
  by KI-2.
- Assertion counts are unchanged everywhere because the drain adds round trips and no
  assertions. The 44 successful drain round trips across those four runs are themselves the
  evidence that a command re-sent at the phase already in force is accepted: each is awaited
  under the 5s command deadline, so a refusal would have failed the run.

### KI-12: what the first real eleven-runner dispatches found

**Status: three findings, two closed and one open. All of them are conditions no
local rehearsal can produce, which is the argument for dispatching at all.**

The rehearsal simulates distance with loopback and iptables. A dispatch has eleven
roles on separate Azure hosts with real public addresses, real NAT in front of each,
and tens of milliseconds of RTT, driven by a coordinator on a laptop behind a
domestic NAT. Three things failed in that environment that are structurally
unreachable in any local mode.

FIRST, the runtime attestation could never have passed. `role-runner.js:876-884`
refuses to configure unless a role's own runtime version equals the version the
coordinator attests. That is a deliberate fail-closed check that every process in a
run is the same build, and on one machine it is trivially true because both sides
read the same `process.version`. The workflow installed `node-version: lts/*`, which
resolves to whatever the current LTS patch happens to be, so the check could only
have passed by coincidence. FIXED by making the coordinator's exact version a
dispatch input, like the coordinator pin before it. The check itself was not
touched; relaxing it to a major version would have hidden the class of thing it
exists to catch.

SECOND, eleven concurrent role jobs exceed what the account will schedule.
Observed: nine jobs started within 25 seconds and two stayed queued past a
ten-minute discovery window, so the run failed as `role 9 never reported:
PEER_NOT_FOUND` with nothing wrong in any role. Not a code fault and not fixable in
code. Either wait longer than the queue, or host some roles where the coordinator
runs - which is supported, and is the reason placement is a dispatch input.

THIRD, AND OPEN: a role hosted behind this domestic NAT is not reachable from a
runner, even though its address is correct and stable. With the endpoint and the
three DHT roles local, every role reported an address, all eleven attested and all
eleven bound, and then the ordered DHT setup timed out at the first role. With only
the endpoint local, the same run passed DHT setup and got four assertions further.

The distinction that explains it is worth stating precisely, because the local
evidence looks reassuring and is not sufficient. Each local bridge reported
`endpointStable: true` with two independent reflectors observing the same host and
port, which establishes that the NAT's MAPPING is endpoint-independent. It says
nothing about FILTERING. These roles dial each other directly at published
addresses with no hole punching, so a NAT that only admits inbound datagrams from
addresses the host has already written to will drop a runner's first packet to a
local role while every reflector still agrees on the address. That is exactly what
was observed, and it is why an endpoint can be local but a DHT role cannot: the
endpoint initiates.

FOURTH, NOW EXPLAINED: nothing in the eleven-role plan punches, so no role-to-role
datagram has ever been delivered in a dispatch. Established by source reading:

- `role-runner.js:638-657` issues three raw `dht.request(..., tupleForRole(11),
{ retry: false })` straight to a literal address, with no `connect()` and no punch.
- `role-runner.js:166-169` resolves that to dht-value's REFLECTED public address.
- `retry: false` sets `req.retries = 0`, so dht-rpc destroys the request at
  `io.js:601` after ONE unanswered datagram - the exact frame in the stack recovered
  from the runner.
- `topology-fixture.js:1073`, `:1080`, `:1087` wire every DHT edge one way, seed to
  referral to value, with nothing pointing back. dht-value therefore never sends to
  dht-referral, its NAT holds no mapping for it, and dht-referral's first packet
  inbound is dropped. No reply is possible, and raising any timeout cannot help
  because the packet is never delivered at all.
- `grep -c punch` is zero in role-bridge.js, role-runner.js, topology-fixture.js and
  across all of lib/private.

The source read also predicts the observed boundary, which is the strongest available
consistency check: assertions 1 to 10 are all satisfiable on a completely deaf
network, and the run dies at the 11th emission.

One precision about that emission, because it is the kind of line a later reader
re-derives wrongly. The eleventh assertion RESULT is the catch-block `t.fail` at
`live-process-suite.js:509-510`, reporting the role's REQUEST_TIMEOUT thrown out of the
`Promise.all` at `:168`. The eleventh assertion in SOURCE ORDER, the audit-open class
check at `:169`, was never reached. Both statements are true of different things, and
the distinction points at opposite halves of the system: had `:169` run and failed, the
diagnosis would be that three audit opens arrived with the wrong classes, a codec or
audit-arming fault, and a reader would search `AUDIT_CLASSES` and `armSetupDhtAudit` and
find nothing wrong. The events never arrived at all. Note also that once the store
completes, `:169` WILL execute, and "assertion 11" will then mean the audit-open check
rather than a caught role failure.

This repository already solved the same problem in a sibling harness.
`test/remote-peer/mesh.js` punches at ten sites, and states the principle at
`:294-297`: every member punches the moment the plan lands so the sends cross in
flight, because that is the only way two NAT'd hosts open a path neither can open
alone. The measured result is recorded earlier in this document: 90 of 90 directed
cell-socket pairs arrived between ten runners once every member punched
simultaneously, source port intact on all 90. So the mechanism is proven here; the
eleven-role plan simply never adopted it.

FIFTH, AND ITS OWN FAULT: the DHT-setup assertions cannot fail when the DHT is deaf,
so they are not gates. `live-process-suite.js:142-145` asserts
`t.is(ready.state, 'DHT_SETUP')` per DHT role and the suite reads it as evidence that
setup worked. It is evidence that a local variable changed. `role-runner.js:600-606`
awaits `dht.ready()` and then sets that state unconditionally, and a dht-rpc query
treats a request timeout as an error it counts and continues past, with
`_bootstrapping` additionally `.catch(noop)`. So `dht.ready()` resolves on a network
where nothing was ever answered. Three green assertions covered exactly that
condition, and the first assertion with teeth was eight later. This would be worth
fixing even if reachability were perfect: an assertion that cannot fail when the
subject is dead is not a gate. The fix is for it to require an ANSWERED request -
a success count from the bootstrap query, or one round trip - rather than a state
transition.

That fix is cheap but NOT free, and the reason is worth recording because the obvious
version does not work. Event shapes are strictly validated: `control-channel.js` builds
`EVENT_FIELDS` and then calls `exactObject`, which enforces an EXACT field list rather
than a minimum, so simply attaching an answered-request count to the `ready` event throws
at validation. It takes three edits: read `dht.stats.requests.responses` after
`await dht.ready()` in `role-runner.js` `activate()` and pass it to the `ready` emit; add
the field name to `EVENT_FIELDS.ready`, which is the shared control codec at
`control-channel.js:809`; and assert it is above zero for the two roles that must have
been answered. Routing it through the `snapshot` event instead is strictly worse, since
that path needs both a digest and the same field-list change. A corollary for anyone
wanting one value out of a role quickly: anything structured must pass `exactObject`, so
an unstructured diagnostic log is the only genuinely zero-cost probe in this harness.

Kept for the record, since it was the observable symptom: the setup store does not
complete over a real network. With the
command deadline raised and EVERY role on a runner, so nothing depends on the
laptop's NAT, the run reaches 10 of 11 assertions and then dies with
`PROCESS_ROLE_FAILURE (dht-referral/CONTROL)`. The role's own stack, recovered from
the runner, is `DHTError: REQUEST_TIMEOUT` raised inside `dht-rpc/lib/io.js:601` -
dht-rpc's own request timeout, not a harness deadline and not a check failing. Some
DHT request the referral role makes is never answered. Cause not established, and I
am not going to guess it: it reproduces with all eleven roles remote, so the laptop
is excluded, and it survives a ninefold increase in the coordinator's command
budget, so it is not the harness being impatient.

One asymmetry found while looking, worth recording because it is cheap to fix and
could contribute. The cell socket's address is reflected off TWO reflectors and the
bridge reports `endpointStable` only when both agree, which is what establishes that
the NAT's mapping is endpoint-independent. The exits' second socket, the DHT socket
at `43000 + index`, is reflected off reflectors in a loop that BREAKS on the first
success, so its mapping is confirmed once and never cross-checked. If a NAT were
endpoint-dependent for that socket, the published address would be the mapping for
that one reflector rather than the one other roles will see, and requests to it
would time out exactly as observed. That hypothesis is now ELIMINATED rather than open. The DHT
socket was given the same two-reflector agreement check as the cell socket, and the
coordinator names any disagreement before minting: on a further all-remote dispatch
no exit reported a disagreement and assertion 11 failed identically. So the exits'
DHT mappings are stable, cross-checked, and not the cause. The check stays because
it turns an address nobody verified into one that is verified, but it bought a
negative result rather than a fix.

The order these were found matters for anyone repeating the exercise, because each
one hid the next: runtime attestation, runner scheduling, laptop NAT filtering,
retransmission classification, setup-store timeout, and finally the cross-host
monotonic deadline. PR #45 removed that last protocol fault.

The next reviewed dispatches crossed every boundary the earlier runs could not:
140/140 directed punch pairs, answered DHT setup, immutable store/readback, every
role READY, guard-only endpoint authority, no retained bootstrap socket, and the
first exact routed immutable get across eleven Azure hosts. That closes KI-15
end-to-end for the exercised request.

The run then exposed a harness assumption: it awaited
`isolated-grant-request` from `lookup-exit-a` as mandatory, but real DHT ordering
returned the value directly without discovering a learned closer. The local
deterministic topology always takes the referral path, so it had hidden the hang.
Role snapshots now report `isolatedGrantRequestCount`; learned-closer events remain
served when present, but scenario progress and accounting accept both valid paths.

Further dispatches separated protocol from runner/NAT allocation:

- eleven remote jobs can leave one queued beyond the workflow's maximum discovery
  window, even though the eventual Actions jobs all pass;
- one allocation opened only 2/140 punch pairs, while another opened 140/140;
- co-located roles on this workstation cannot hairpin through their shared
  reflected public address;
- two Azure relay candidates can land in the same /24, which the privacy diversity
  rule correctly rejects during activation.

These are named environmental outcomes, not reasons to relax the route. A standing
remote gate needs placement/allocation control before a green 132/132 run is
repeatable; good allocations have exercised the complete lifecycle through
teardown, and the reviewed protocol remains fail-closed on bad ones.

### KI-15: an absolute deadline is built on a host-local monotonic clock

**Status: FIXED, including a real eleven-host routed immutable get.** The wire
now carries a RELATIVE budget and each host derives its own absolute deadline from
its own clock, so no clock value is compared across hosts. This entry originally
recorded the wrong cause - that the 3000ms budget was too small - and that diagnosis
is retracted below because the way it was wrong is instructive. Full remote
132/132 remains an infrastructure-allocation gate, not an open KI-15 claim.

#### The fix

`absoluteDeadlineMs` is gone. The uint64 at request body offset 39 is now
`operationBudgetMs`, a DURATION in milliseconds. The layout is bit-identical - the fixed
body is still 221 bytes and an encoded immutable-get is still 261 - so this is a semantic
change to one field, not a wire-format change.

- The endpoint mints the budget it already derived (`routed-dht-io.js`, `ROUTE_HOPS` x
  `PER_HOP_ONE_WAY_MS` x 2 + `EXIT_DHT_REFERRAL_MS`, clamped to the exit's advertised
  ceiling) and puts THAT on the wire. Its own absolute deadline stays local and is passed
  to `live-route-authority.js` as the `operationDeadlineMs` request option. It is never
  encoded.
- The exit admits on a duration-vs-duration comparison,
  `operationBudgetMs === 0n || operationBudgetMs > policy.timeoutMs`, which needs no clock
  agreement of any kind, then derives its OWN deadline as `exitNow + operationBudgetMs` for
  the ordinary DHT reservation and the referral probe cap.
- `dht-exit-destination-table.js` likewise derives before comparing, so the checks against
  `state.absoluteDeadline` and `entry.expiresAt` are exit-domain on both sides.
- `opaque-destination.js` is untouched. Its `deadline` is minted AND verified on the
  endpoint - `createRoutedReplyReferralAuthority` and
  `createAuthenticatedRoutedReplyAuthority` are both endpoint-side - so it was never a
  cross-host comparison and stays a local monotonic absolute.

Why a relative budget and not the alternatives the earlier entry listed: a wall-clock
domain would import skew and a time-sync dependency into an admission check; an exit-minted
deadline echoed back would move who is trusted to bound the operation. The objection to a
relative TTL was that decrementing per hop leaks or bounds path length - which does not
apply here, because relays never read this field. The routed request is encrypted
end-to-end between endpoint and exit, so there is nothing to decrement and no hop count to
leak: exactly two parties read the number, and each reads it in its own domain.

The endpoint holds itself to the same bound it advertises. `requestProduction` samples its
clock once and refuses a zero budget, a budget above the exit's ceiling, and a local
deadline that either lies in the past or outlasts the advertised budget. The ceiling is
read from `EXIT_ORIGIN_SERVICE_POLICY` - the same table the exit enforces - rather than
restated as a constant, since two constants agreeing by coincidence is how this fault was
built in the first place.

What pins it: `test/private/routed-dht.js` admits ONE encoded request at exit clocks `0n`
and `10_000_000n` and refuses `0n` and `3_001n` budgets at both, and reverting the
admission check makes the far-clock arm throw `ERR_AUTHENTICATION` - the KI-15 failure
reproduced on demand. `test/private/routed-dht-io.js` mints from clocks with unrelated
origins and asserts the budget BYTES are identical while the local deadlines differ, so a
frozen clock cannot satisfy it vacuously. `test/private/live-route-authority.js` proves the
endpoint still arms a real timer off its own absolute deadline and still reports the branch
lost when it fires; feeding the wire budget to that timer instead fails the test.

Gates after the change, and after the three audit fixes it prompted, all at `e3cf206`: the
aggregate is 902/902 tests and 18326/18326 asserts under Node and 881/881 and 18267/18267
under Bare, measured in the Linux container and again on the macOS host with both agreeing
exactly; and in the container only, because they cannot run anywhere else, eleven-role live
127/127 under both runtimes, namespace 27/27, and namespace-live 137/137.

#### The fault, as it stood before the fix

`absoluteDeadlineMs` is minted from the endpoint's `monotonicNow` and compared against the
EXIT's clock in production code: `dht-exit-io.js:519` evaluates
`current + 1_000n < request.absoluteDeadlineMs`, where `current` is the exit's own sample.
So two peers' monotonic clock values are compared directly.

A monotonic clock is host-local by definition, and the harness supplies exactly that,
correctly: `test/private/process/runtime-clock.js` builds it from `process.hrtime.bigint()`
and its own comment says the clock must keep hrtime's machine-wide scale rather than
restarting per process. That is right for a monotonic clock and it is not the bug. The bug
is that the protocol compares two of them. On one host both sides share an origin, which is
why every container rehearsal and every gate passes.

Across two hosts the origins are unrelated, and admission requires
`endpointNow - exitNow` to fall inside a bounded window, so the comparison is against an
arbitrary boot-time delta. The exit therefore refuses the request outright and the
endpoint waits out its full budget.

That made this a design fault rather than a tuning error: an ABSOLUTE deadline expressed in
a RELATIVE clock domain. The three candidate domains were a wall clock, a relative TTL, and
an exit-minted deadline echoed back; the fix above takes the relative one and records why.

RETRACTED DIAGNOSIS, kept because the error is worth more than the conclusion. This entry
first read the observed 3.048 seconds as evidence that a four-hop route needs more than
3000ms. It is not: it is the signature of the endpoint's own deadline firing after the
exit rejected the request. Two checks would have caught it and neither was done before
writing it down:

- The endpoint's 3000ms is not an independent constant. It is exactly the exit's policy
  ceiling for IMMUTABLE_GET_V1, and the admitted window measures as exactly
  `[exitNow, exitNow+3000]`, with a 3001ms budget rejected as `ERR_AUTHENTICATION`. So
  raising it - which the retracted entry implied - would have reddened `process:node` and
  `process:bare` immediately while doing nothing for the dispatch.
- The measurements already in this document refute the premise. Single-link p95 round trip
  is 115.7ms, so eight transits plus the exit's 1000ms referral round is roughly two
  seconds, comfortably inside 3000.

The general lesson, since it has now cost an hour of wrong record: A TIMEOUT IS NOT
EVIDENCE OF SLOWNESS. It is evidence that something did not arrive, and a rejected request
looks exactly like a slow one from the waiting end.

One change did land from this, and it is worth keeping on its own terms: the endpoint's
budget is now derived and clamped to the exit's advertised ceiling rather than being a
second constant that must agree with the first by coincidence. It evaluates to the same
value today, so nothing on the wire or in the live path changes.

### KI-13: the punch that makes a dispatch work is in the harness, not in production

**Status: endpoint↔guard edge proven on real NAT, including the full
eleven-role lifecycle. Run 34061028552 (fourth `-p` dispatch) showed
same-socket reflection, a bilateral plan over the topology owner's channel, a
punch from the production socket, authenticated bootstrap and an exact routed
get with no harness punch on that edge; run 34062848870, after the KI-17
fixes, passed 141/141 with both punch directions crossing, rotation under a
blackhole inside its 5 s bound, suspend, resume and network change. Open
residuals: the coordinator's 5 s per-command wait is a loopback constant for
the remote `activate` step (the passing run raised it through the documented
diagnostic override); relay pairs still depend on the harness pre-punch; the
second dispatch measured a runner NAT that did not preserve the mapping across
close-and-rebind (production failed closed). NAT'd middles and exits remain
unsupported by decision D7: they are dialed cold at rotation time and have no
pre-link channel, so the harness pre-punch below still opens those pairs and
is test topology plumbing, not production. The paragraphs below describe the
harness and remain accurate for the relay pairs.**

The eleven-role dispatch now opens role-to-role NAT mappings before any role starts:
the coordinator distributes all eleven addresses over a fourth bridge mode byte, and
every role punches simultaneously from probes bound to the exact ports it will later
own, following the mechanism `test/remote-peer/mesh.js` already proved here.

Stated as plainly as it can be, because a green run will otherwise be read as more than
it is:

> The punch is in the harness, not in production. `lib/private` contains zero punching.
> A green eleven-role dispatch proves the SCENARIO can run across NAT'd hosts because
> `test/remote-peer/role-bridge.js` opens the mappings before any role is attached. It
> does not prove two NAT'd relays can join a route in production. The rehearsal cannot
> narrow this: identical mode passes `--reachable-host`, and the bridge's
> `if (options.reachableHost !== null)` branches skip reflection entirely when that is
> set - `role-bridge.js:452-454` for the exit's DHT socket and `:475` for the cell
> endpoint - so no local mode reflects or translates
> and 140/140 on loopback is the floor, not evidence. A rehearsal proves the frame path,
> the one-tick plan distribution and that the probes release the role's ports. Only a
> dispatch tests traversal.

When this was written, `udx-cell-endpoint.js` owned its socket with no injection
point. That seam now exists for the endpoint↔guard edge only:
`prepareEndpointNatTraversal` and `armNatPunch` punch from the production socket.

Three limits belong beside it, and together they mean a green store assertion says the
pair was open at that moment rather than that the topology is durably connected:

- Nothing refreshes a mapping for the length of a 900-second run.
- The punch sits at the earliest point in the run, so the gap to the store is the
  largest possible, and it grows with RTT while the NAT's idle timeout does not.
- `retry: false` at `role-runner.js:641`, `:649` and `:656` means one lost datagram
  still fails the store with a perfect mapping.
- The three DHT roles hold the LONGEST unbound window of any role, and they are exactly
  the ones the store depends on. `role-runner.js:532-537` has `prepare()` for a DHT role
  set `PREPARED` and bind nothing; its socket is bound only later at activate, via
  `createDhtOwner` and `dht.ready()` at `:595-597` and `:600-606`. Every other role binds
  its cell endpoint during its own prepare at `:538-539`. So for dht-seed, dht-referral
  and dht-value the port is unbound from probe-release until activate, spanning role spawn
  plus eleven configures plus eleven prepares - and the mapping-survival measurement above
  covers a QUICK rebind, not that.

AND ONE HOP NOBODY HAS MEASURED, which is precisely the seam this design rests on. Two
measurements exist and neither covers it: the record above shows a MAPPING survives
close-and-rebind, and the 90-of-90 result never rebinds at all, because `mesh.js`
punches and receives on one live socket. So nothing measures whether a NAT still ADMITS
a previously punched peer after the local socket has been closed and rebound. If a
dispatch reports a partial punch matrix, that is the first place to look.

### KI-14: a rotation re-qualifies the hop it just rotated away from

**Status: preferred-tier fault demotion is implemented for initial, reconnect,
and replacement selection.** The all-candidate tier remains available when no
preferred combination is possible; demotion is not hard exclusion. A minimal
three-plus-three pool can still require a previously faulted pair. KI-6 now
selects uniformly within the chosen tier and its harness coupling is fixed.
The rotation-only scope and harness blocker described below are historical;
the small-pool exposure remains current.

The honest cost first, because it is the part a later reader most needs and least wants.
At three middles and three exits, `reserveReplacement` already excludes the live opposite
pair and the pair being replaced — two of three middles and two of three exits — so the
only qualifying pair IS the one just vacated. The preferred tier therefore comes back
empty, the fallback admits the vacated pair, and the selection is byte-for-byte what it
was before this fix. That is not an oversight: it is the property that keeps a legitimate
rotation from failing closed, and it is why the process gates cannot go red. The fix
helps a deployment with a genuinely larger relay pool and does nothing for the minimal
one. Both halves are pinned by tests, so neither can change unnoticed.

#### The design question came first: was a reason available at all?

A rotation fires for at least two unrelated reasons. Material expiry is routine and
implies nothing about the hop. Failure or suspected misbehaviour does. The directory could
not tell them apart, so the first question was whether the signal reaching it carried a
reason, and if not, where one would have to come from.

It did carry one, and no protocol change or new signal was needed. Both triggers converge
on `issueBranchSink(state, branchClass, suffix)` in `route-manager.js` with the suffix
`'BranchLoss'` or `'BranchExpiry'`, so the four controller signal kinds —
`lookupBranchLoss`, `announceBranchLoss`, `lookupBranchExpiry`, `announceBranchExpiry` —
already encode expiry-versus-fault. The reason was discarded at exactly one place: the
four-kind case arm in `private-routing-controller.js` reads `signal.kind` only to derive a
`branchClass` and then calls `routeManager.rotate(branchClass)`. Nothing below that hop
ever saw a reason: `rotate` to `createRotationDraft` to `createReplacementBranchDraft` to
`reserveReplacement({ branchClass, generation })`.

Two seams were possible. Threading a reason down all four files would have widened two
`exactObject`-pinned lists, `REPLACEMENT_FIELDS` and `REPLACEMENT_BRANCH_FIELDS`, to carry
information the controller already had. The controller was also the wrong place to tell
the directory directly, for a reason worth recording: **the controller holds no live
directory handle.** `state.suspendedDirectory` is null except across suspend and resume,
because the directory is owned by the route manager. Hooking there would have meant adding
a handle to controller state and keeping it coherent across suspend, resume and
unavailable.

The seam used is one hop upstream, where the handle is already in hand:
`reportRouteManagerBranchLoss`. It is the manager's **exclusive** fault path — expiry
reaches `issueBranchSink` from `armBranchExpiry` under the other suffix and never passes
through it — it is where `branch.lost` is set, so it is the authoritative statement that
this branch failed for cause, and every fault source funnels through it, including the
physical-loss registration and L0's owned-route failure. The change there is one advisory
call, deliberately wrapped so a directory that cannot record the demotion still cannot
stop the branch being reported lost.

#### Demotion, not exclusion, and why hard exclusion would have been worse

Hard exclusion is the obvious reading of "fault-based exclusion" and it is wrong here.
Because the exclusion set already leaves exactly one qualifying pair at three-plus-three,
removing the just-failed pair makes the sibling rotation throw `ERR_INCOMPATIBLE_RELAY` —
so **any relay could deny the endpoint a route by failing.** That trades rewarded
observation for rewarded denial, which is a strictly worse bargain: the first costs
privacy against one adversary, the second costs availability to anyone.

Instead a faulted record is **demoted**: still eligible, but only after every unfaulted
combination has been tried. Availability is bit-for-bit unchanged, and the pool can never
be exhausted by exclusion. What the fix removes is not the suspect's eligibility but the
_reward_ — failing can no longer be a way to get selected sooner.

**This is expressed as a PARTITION, not as a position in a list, and that matters for
KI-6.** `validCandidates` returns `{ preferred, all }`, and a selection exhausts
`preferred` before admitting anything from `all`. Had the demotion been implemented as
"move faulted records to the back", a future KI-6 fix that randomises selection would have
silently disabled it. As a tier, a randomised selector may randomise _within_ a tier and
the property survives; only a selector that draws from `all` directly discards it. That
constraint is written into `relay-candidate-directory.js` as a comment on
`validCandidates`, where a KI-6 fix will trip over it, rather than only here.

One consequence recorded plainly: **candidate order — specifically the ordering between
the two tiers — is now load-bearing for a security property.** Before this fix, order was
merely an arbitrary artefact, which is what KI-6 exists to complain about.

#### The two-pair build is deliberately NOT tiered, and the reason is a measured coupling

The demotion applies to `chooseReplacementPair`, the rotation path, and NOT to
`choosePairs`, which builds both branches at once — the initial route and the bootstrap
pair after a reconnect. Two reasons, one principled and one measured.

The principled one: KI-14's harm is a rotation handing the SIBLING branch the hop it just
rotated away from, so the relay gains a second view of one live route. A build from
scratch has no sibling to protect; there is no live branch for a demoted hop to see more
of.

The measured one is the finding worth keeping. Tiering `choosePairs` turns the
eleven-role gate red: `process:node` fails at the assertion after the suspend step, with
the guard's dial rejecting — `ROUTE_UNAVAILABLE` thrown at `guard-link.js:199` from the
dial-rejected arm, reached through `openTailAdjacentLink`. **That failure is not caused by
this fix.** On pristine HEAD, with no demotion anywhere, reversing the candidate order in
`validCandidates` — one line, no faults involved — ALSO fails the gate, deadlocking at the
first routed get without ever reaching the rotation. Three runs, isolation trees from the
same commit:

| tree                                          | process:node        |
| --------------------------------------------- | ------------------- |
| pristine HEAD                                 | pass, 125/125       |
| HEAD + this fix, demotion on all paths        | FAIL at the suspend |
| HEAD + this fix, demotion on rotations only   | pass, 125/125       |
| pristine HEAD + candidate order reversed only | FAIL, deadlock      |

So the eleven-role fixture cannot tolerate ANY change to which pair first-match returns.
Tiering does not fail closed there — it succeeds and returns a different, equally valid
pair, which the fixture then cannot service.

**This is a hard blocker for KI-6 and is larger than this entry.** Randomising hop
selection would not merely weaken this demotion; it would break the eleven-role gate
outright, because the scenario depends on first-match's exact assignment of the six relay
roles to branch positions. KI-6 cannot land until that coupling is fixed, and the coupling
lives in the harness — `live-process-suite.js`, `role-runner.js`, `wire-services.js` — not
in the directory.

**What is NOT given up.** The demotion is not forgotten across a reconnect. It survives in
the directory and still binds every later rotation, so a reconnect buys a faulted relay
ONE bootstrap selection rather than a reset. That residual is asserted, with a control, by
'a demotion survives a reconnect and still binds a later rotation'.

#### The bound, and why this is not `quarantine`

The demotion lasts until the LATER of the record's own `expiresAt` and
`FAULT_DEMOTION_MS` — 60s, minted in `relay-candidate-directory.js` — from the moment of
the fault.

The floor was added after a fresh-context security review of this entry. The original
bound was the record's own `expiresAt` and nothing else, which is **a number the demoted
relay signs for itself**: the only checks on it are `expiresAt > now` at admission and
`MAX_CAPABILITY_LIFETIME` (30 minutes) as a ceiling in `relay-capability.js`, and there is
no minimum anywhere. Because a branch fault demotes BOTH hops of the failed pair, that is
an asymmetry an attacker can exercise: a malicious middle advertises a two-second
capability, blackholes the branch it is carrying, serves a two-second penalty and
re-advertises, while the honest exit it dragged down — whose expiry it does not control —
serves up to the full thirty minutes. Repeated across partners it drains honest hops out
of `preferred` while the attacker cycles back in, biasing `chooseReplacementPair` toward
attacker-controlled hops. For a heuristic penalty the duration IS the entire penalty, so
an attacker-chosen duration removes the penalty for the attacker alone. Quarantine's bound
did not carry over the way the original reasoning assumed: quarantine acts on proof of
equivocation, where the identity is already forfeit and a self-chosen duration costs
nothing. A heuristic demotion is not that.

**The invariant traded away, stated plainly.** A demotion previously could not outlive the
record it applied to, because `pruneInvalidRecords` dropped the record and the demotion on
one sweep. Under the floor it can, and that is the point: shedding a penalty by
advertising a short-lived capability and re-advertising is precisely the move being closed,
so the penalty has to be able to outlive the advertisement it was earned on. What survives
is the part that was load-bearing. The entry is still swept on `expiresAt <= now`, so a
demotion stays temporary and never becomes a bar; and the map is still bounded by
`MAX_IDENTITIES`, because only an identity already in `state.records` is ever inserted and
that set is fixed at seal and only shrinks. The floor is computed from the same wall
sample the sweep compares against, so a floored entry expires on the clock that prunes it.

60s is minted locally rather than derived: four `MAX_ROUTE_LIFETIME_MS` route lifetimes and
twelve `BRANCH_ROTATION_LEAD_MS` rotation leads, so a demotion binds several consecutive
rotations instead of lapsing inside the one that earned it, and a thirtieth of the
capability ceiling, so it stays far below the longest demotion an honest long-lived
advertisement already accepts. Deriving it from either constant would tie this module to
the route manager's and the extension's clocks for no gain, and both remain rejected as
the bound itself: a demotion shorter than the record's selectable life reopens the window
at the next rotation.

The two mechanisms are kept **separate**, and conflating them would be unsafe in both
directions. Quarantine answers a question about _identity_: one key advertising two digests
at one epoch is proof of equivocation, so a hard bar there has no false positives. A fault
is a _heuristic_ about _behaviour_ — a timeout or a physical loss can be the network, the
local host, or an unlucky but honest relay, and attribution to the hop is unproven. This
fix therefore never writes `quarantine`, and a test asserts `quarantineCount` stays zero
across a reported fault. Attribution is also to the **branch**, not to a hop: nothing in a
physical loss or an elapsed deadline says whether the middle or the exit failed, so both
hops of the failed branch are demoted.

#### What is proven, and by which test

- **A faulted hop is not handed to the sibling, measured at four-plus-four** — the shape
  where KI-14 measured reuse six times out of six. The test runs both arms over the same
  pool, and the **control is the load-bearing half**: with no fault reported the vacated
  middle and exit ARE reused, reproducing the original finding; with the fault reported
  neither is. Without that control the test would only show that some pair was selected.
- **A rotation never fails closed at three-plus-three**, on both the expiry-driven and the
  fault-driven arm, and the demoted pair is confirmed to be the one selected — pinning the
  no-effect caveat above as an assertion rather than a claim. Hard exclusion would throw on
  both arms.
- **A demotion survives a reconnect and still binds a later rotation**, with the same
  control shape: without the fault report the demoted pair IS reused one reconnect later.
  This is the property that makes scoping the fix to rotations defensible rather than a
  quiet retreat.
- **The bound is the later of the record's expiry and the 60s floor**, proven from both
  sides. A middle that signs itself a two-second capability still carries its demotion ten
  seconds later, when its own record has already been swept out of the candidate set; and a
  record advertising two minutes carries its demotion for exactly those two minutes and not
  a sweep longer. Three mutations were confirmed to bite: dropping the floor, replacing the
  record's expiry with the floor, and adding the two rather than comparing them.
- **Suspend/resume does not launder a demotion** — `retainForSuspend` clears the committed
  pairs, so without this a reconnect would be a free pardon.

#### Residual exposure, stated rather than implied

Demoting on a heuristic creates an inverse move: an adversary who can induce false
positives on honest relays shrinks the preferred tier toward itself. This is strictly
weaker than the fault it replaces — that one required only failing once — and it degrades
gracefully, because once every candidate is demoted the tier collapses and selection is
identical to today's. So an adversary gains nothing by demoting everyone; it would have to
demote exactly everyone else.

#### Effect on the branch-liveness sub-gate

`docs/private-routing-branch-liveness-design.md` records that L1's keepalive-driven
teardown must not land before fault-based exclusion exists, or failing becomes a rewarded
strategy. That precondition is now met **only for pools larger than three-plus-three**. In
the minimal shape a relay that fails is still handed the sibling branch, so L1 remains
blocked there, and the blocker is pool size rather than a missing mechanism.

#### Generation binding after refused-loss redelivery

Before redelivery, the no-yield publish/swap/revoke sequence prevented an old
physical registration from reaching a new pair through native I/O interleaving.
That argument depended on refusing and spending every report during ROTATING.
It is not sufficient once losses can survive a rotation.

`createRouteManagerBranchLossRegistration` now captures the published material's
generation. Live route IO passes its owner generation through the same
`reportRouteManagerBranchLoss` boundary. A mismatched generation is rejected
before marking the branch lost or demoting its selected pair.

Pending loss belongs to the published branch object, not to a branch-class-only
event queue. Publishing its replacement removes that standing loss. A queued
controller wakeup must still find a current manager-owned loss to start rotation.
The regression deliberately retains a physical registration across publication
and proves that issuing it cannot lose the replacement.

### KI-4: intermittent wall-clock deadline rejections on CI

**Status: responder-side offer admission repaired under a reviewed contract;
see the verification table in that checkpoint for the gate evidence. Remote
confirmation on real links is a separate dispatch.** The earlier two causes
and handshake-completion clock-skew rejection were fixed first. Run
[`34147485033`](https://github.com/ayooooo123/hyperdht/actions/runs/34147485033)
then exposed the responder-side instance at initial guard-offer admission:
15,027 ms remaining against a 15,000 ms bound. See the guard offer deadline
checkpoint for the diagnosis and the "KI-4 cross-host time contract for
offer admission" checkpoint for the contract, the review lane, and the
regressions. The startup-anchor clock mechanism is specific to the process
harness; the responder's future-deadline comparison was protocol-level and
is gone. Signature, local expiry, and replay checks remain enforced.

On 2026-09-05, collection commit `efb5051` produced:

```
not ok 73 - PROCESS_FAILURE (guard/CONTROL): ERR_AUTHENTICATION
```

The [push run](https://github.com/ayooooo123/hyperdht/actions/runs/33992418356)
passed both deterministic jobs but failed the Node process scenario immediately
after `suspend has no send-capable guard edge`. The
[companion run](https://github.com/ayooooo123/hyperdht/actions/runs/33992419663)
passed all three private-routing jobs on the same commit; the
[build matrix](https://github.com/ayooooo123/hyperdht/actions/runs/33992419669)
also passed on Linux, macOS, and Windows. These results do not clear the failure.

The first recorded stack started at `actorFailure` in `role-runner.js`, which
replaced the original error before logging it. It therefore did not identify
the originating authentication check. At that checkpoint, the cause was not
established and no runtime fix was claimed.

An isolated copy retained the original actor error stack for diagnosis and ran
eight Node plus eight Bare live process scenarios in the local Linux container.
All 16 passed 136 assertions each; the CI failure did not recur. This is a
non-reproduction, not a fix. The diagnostic copy was removed. The same
one-line stack-preservation change is now retained in the role harness:
actual `Error` objects reach the existing opt-in fatal log unchanged; a
non-Error value still gets a normalized fallback error. The control channel
still sends only `sanitizeCode(err)`. That diagnostic commit did not change
protocol acceptance and did not itself fix the authentication rejection.

A deterministic fault-path smoke injected a marked authentication error in a
temporary relay actor. Before the fix, Node logged a replacement stack and
Bare wrote no diagnostic file: the shared `require('fs')` lacked a Bare module
mapping. The package now maps `fs` to the pinned `bare-fs` development dependency
under Bare, following the existing cross-runtime import pattern.
After the fix, both runtimes logged the original marker and `Object.serve`
source stack; both control failures still contained only
`PROCESS_FAILURE (guard/CONTROL): ERR_AUTHENTICATION`. The injected fault and
temporary worktree were removed. This proves diagnostic preservation, not a
fix for the intermittent CI rejection.

#### Signed clock-skew rejection reproduced and fixed

The [next failing Bare CI run](https://github.com/ayooooo123/hyperdht/actions/runs/33993769484)
on `3c8e48f` preserved the originating stack at `completeExtensionLink`'s
ACCEPT validation. A deterministic valid signed reply with the responder
1 ms ahead of the initiator failed at `acceptedAtMs > current`.
The equivalent index-zero case failed too. An independent clock experiment
also showed how the role clock's fractional start phase can produce a signed
timestamp of `1600000001002` followed by a receiver reading `1600000001001`.
Separate real hosts can have clock skew as well; synchronizing the fixture
would hide rather than fix that protocol assumption.

Both completion paths now require the authenticated ordering
`acceptedAtMs < admittedLimits.expiresAtMs`, while retaining
`acceptedAtMs <= offerDeadlineMs`. They no longer compare the peer's accepted
time with the receiver's current time. The receiver still rejects completion
at or after its offered deadline and rejects already expired admitted limits.
Signatures, exact offer/identity bindings, nonces, one-shot pending ownership,
and proof verification are unchanged.

For extension links, admitted expiry must also remain at or before the
offered deadline. Index-zero link lifetime remains bounded by its authenticated
requested/admitted limits; the handshake deadline does not shorten that lifetime.
No clock-skew allowance constant, retry, or shared-clock fixture was added.

Both positive-skew regressions fail before the fix. After it, the focused
guard-link suite passes 51 tests and 1,059 assertions, including both skew
directions, a signed accepted time at admitted expiry, a signed time beyond
the offered window, forged signatures, late completion, cross-offer
substitution, and replay rejection. The extension cases use native UDX
ownership and production responder proofs.
The index-zero inclusive boundary is also pinned: a signed accepted timestamp
equal to the offered deadline can complete before that deadline while retaining
the longer authenticated link lifetime. Changing the rejection from `>` to
`>=` in an isolated module-loading mutation makes that regression fail.

Historical evidence for the two established causes follows.

Three fail-closed rejections on the GitHub `ubuntu-latest` runner, in three of
the twelve `live-linux` executions observed before the fix below, all tied to a
wall-clock boundary and none reproducible on the local arm64 Linux VM.

Signature A, in the eleven-role scenario around the suspend step, seen in both
the Node-roles and Bare-roles variant:

```
not ok 62 - PROCESS_FAILURE (announce-middle/CONTROL): ERR_AUTHENTICATION
```

Signature B, in the Bare aggregate during the initial branch build:

```
ERR_PRIVACY_UNAVAILABLE
    at sealTailExtend (lib/private/tail-control.js:892)
    at RouteExtensionSession.open (lib/private/route-extension.js:418)
    at openInitialBranch (lib/private/private-routing-controller.js:586)
```

Signature C, in the Bare aggregate at adjacent-link setup, and the one that
carried enough stack to be actionable:

```
ERR_AUTHENTICATION
    at createExtensionLinkOffer (lib/private/guard-link.js:2199)
    at openTailAdjacentLink (lib/private/tail-control.js:3050)
    at Object.serve (test/private/hosted-tail-fixture.js:220)
```

**C is fixed, and it was a harness defect.** `createExtensionLinkOffer` converts
a wall duration into the monotonic domain and rejects a derived deadline above
the one it was handed. Four test sites supplied `wallNow` and `monotonicNow` as
two independent `() => BigInt(Date.now())` calls, so a millisecond boundary
falling between the samples inflated the derived deadline by exactly one
millisecond. `test/private/coherent-clock.js` now derives both from a single
cached sample, the same guarantee `runtime-clock.js` already gave the role
runtimes. Signature A plausibly shared this cause, since the eleven-role fixture
was one of the four sites, though that is not proven.

Eight consecutive `live-linux` runs passed after the fix, against roughly one
failure in four before it. That is evidence, not proof: at the earlier rate,
eight clean runs would happen by chance about one time in eight.

**B is now fixed.** The deterministic characterization is now the regression
`TailControl keeps committed limits valid when only the operation deadline shortens`:
limits whose expiry equals the authenticated route lifetime seal both with the full
operation window and with that operation window shortened by one millisecond.

The fault was a two-bound model representing three different facts. The replacement
deadline snapshot keeps:

- `wireExpiresAt`, the immutable authenticated wall-clock route lifetime;
- `routeLocalDeadline`, its coherent monotonic projection, sampled once and retained;
- `operationDeadline`, a separately mutable local timeout for the current operation.

An operation may shorten only `operationDeadline`. An authenticated earlier proof/request
wall expiry is always projected from the retained `(wireExpiresAt, routeLocalDeadline)`
anchor, never from the mutable operation deadline and never from fresh clock samples.
TailControl carries the final M3 monotonic high-water across ownership, rejects rollback,
reserves one-shot transitions before every injected clock call, and rechecks the operation
deadline after the clock-bearing final route take before publishing its transport.

No protocol frame, transcript, admitted-material key, or final-handoff key changed. The
fix separates actor-local scheduling from the route lifetime the peer authenticated.

#### Pre-fix diagnosis retained

The shortening was not exotic. `createTailControlSession` shortened whenever the
`absoluteDeadline` it was handed was below the tail's local projection, and the old
`shortenM3TailLifetime` moved `wireExpiresAt` down by the same delta. But the value
`RouteExtensionSession` handed it was an _operation_ budget, bounded by
`MAX_EXTENSION_MS`, not a statement about how long the route should live. Narrowing one
extension window therefore shortened the route's wire lifetime and made limits committed
against the longer lifetime unpresentable.

Choosing a remedy has an overhead dimension, so the shortening was measured
across one aggregate run. It fires 48 times: 28 from `createTailControlSession`
and 20 from the rearm path. Twenty-four of those lose 13,000 ms of wire lifetime
each, and the granted lifetime at seal clusters at 4,000 ms where a shortening
happened against roughly 14,990 ms on the one real-clock path where none did.
Those absolute numbers are fixture-scale rather than production, but the ratio
is the mechanism: narrowing the operation window shortens the route's wire
lifetime one for one.

That reverses the earlier preference order. Adding headroom at negotiation buys
robustness by making every route permanently shorter, which raises the rotation
rate and therefore the branch-build cost, the most expensive operation in the
system. Decoupling instead is free and cuts overhead: how long a handshake may
take and how long a route may live are different quantities, and only the first
should be bounded by `MAX_EXTENSION_MS`. It also removes the shortening that
invalidates committed limits, so the performance choice and the correctness
choice coincide.

The implementation cost of decoupling was retaining the authenticated wall/local route
pair while carrying the operation deadline independently through TailControl. A rejected
one-line attempt preserved `wireExpiresAt` but projected later proof expiries from the
already-shortened operation deadline; it mapped `(wire, routeLocal)=(20,000,29,000)`,
operation `16,000`, proof `4,500` to `500` instead of `13,500` and broke normal tail
completion. That failure is why all three bounds are explicit.

Instrumenting every `sealTailExtend` in the private aggregate and recording the
distance from the requested wire expiry to each bound gives, identically under
Node and Bare, over 44 seals:

| `tailWireExpiresAt - requested` | seals                                                                |
| ------------------------------- | -------------------------------------------------------------------- |
| -1 ms                           | 1, from a deliberate negative test in `test/private/tail-control.js` |
| 0 ms                            | 21                                                                   |
| 2,000 ms                        | 20                                                                   |
| 4,000 ms                        | 1                                                                    |
| 5,499 ms                        | 1                                                                    |

Both real seals in `test/private/route-extension.js` sit at exactly 0. The
advertisement is never the binding bound: its slack on the real-clock paths is
about 45,000 ms.

So the protocol routinely asks for precisely the tail's wire deadline, and
passes only because the comparisons are strict `>`. Three sites share the shape,
all against `state.deadline.wireExpiresAt`:

- `sealTailExtend`, throwing `ERR_PRIVACY_UNAVAILABLE`, which is signature B;
- `clampTailControlProofDeadline`, whose next line treats `===` as the normal
  path and whose `>` calls `authentication()`, which is signature A;
- the responder mirror in the extend-admission path.

A single millisecond of divergence between the two independently derived wall
values therefore turns a normal operation into a fail-closed rejection. That is
the same hazard already recorded for the role clocks further down this document,
where independent `Date.now()` and `hrtime` samples straddling a millisecond
boundary produced exactly this rejection and were fixed by deriving both from
one cached sample. The production path still has the hazard between the extend
requester and the tail state.

Both rejections are fail-closed. The route build aborts rather than continuing
with an expiry the relay never authorised, so this is an availability defect
under load, not a privacy one. It must not be retried away: zero margin means
the next perturbation reproduces it.

The obvious remedy does not work, and the reason narrows the fix usefully.
Having the requester ask for slightly less than the bound was tried and
reverted: `expiresAtMs` is not the requester's to choose. It is proposed by the
peer in `LINK_ACCEPT`, hashed by `digestAdmittedLimits(accept.admittedLimits)`
into `admittedLimitsDigest`, and bound into the M3 transcript, so
`authenticateRequestedLimitsDigest` rejects any request that does not present
exactly the accepted bytes. Lowering the value client-side fails authentication,
correctly. That also explains why the zero margin is so consistent: the request
is stable across derivations precisely because the deadline term binds it, which
is load-bearing rather than accidental.

The alternatives remain rejected. Negotiation headroom permanently shortens every route
to buy transient operation slack; comparison tolerance relaxes an authentication bound;
and fresh reprojection loses the one coherent wall/monotonic anchor. The shipped model
instead removes the second derivation: authenticated route values remain stable while the
local operation expires independently.

The two bounds in `sealTailExtend` are now thrown separately so a stack
attributes a future rejection to the one that fired. Same error, same
fail-closed behaviour, no wire or semantic change.

Instrumentation is in place for the next occurrence. Setting `PR_ROLE_FATAL_LOG`
makes each role append its stack to that file, the coordinator forwards that one
variable into the otherwise empty role environment, and the Linux CI job prints
the file whenever a scenario step fails. The control channel still carries only
a strict error code, so no diagnostic text reaches the wire.

### KI-5: subnet diversity is a weak proxy for operator diversity

`validatePathDiversity` requires the guard and all four branch positions to
differ by identity and by endpoint subnet, /24 for IPv4 and /48 for IPv6. That
stops the naive case of several hops behind one address block, and it fails
closed rather than relaxing.

It does not stop an adversary who rents addresses across many blocks, which is
cheap. Real diversity would key on autonomous system, hosting provider, or a
declared operator family, none of which the advertisement carries today. Veilid
uses the same IP-block proxy and additionally relaxes it away on small networks,
so this is a shared limitation of the approach rather than something to copy
from elsewhere.

Until relay identity has a cost, path diversity constrains the shape of an
attack without bounding the attacker's share of the candidate set.

The rule also decides whether a fault can be survived. `reserveReplacement`
applies it against the live opposite pair and the pair being replaced, so
in a three-plus-three pool the one spare exit must differ by subnet from the
exit it succeeds. Run 34072979459 (the 2026-09-09 review checkpoint) placed
`lookup-exit-b` and `announce-exit` in one `/24` on the runners; after the
blackhole the replacement was `ERR_INCOMPATIBLE_RELAY` and the controller
went `UNAVAILABLE`. That is the rule failing closed, reproduced at the
directory level with the same placement; it is not a selector defect and
the selector is unchanged.

### KI-6: hop selection is first-match, not random — FIXED

**Status: FIXED.** Initial, reconnect, and replacement selection now draw
uniformly over the valid diverse ordered combinations in one chosen demotion
tier. The preferred tier is counted and exhausted first; the all-candidate tier
is considered only when the preferred count is zero. Candidate order is now only
the enumeration order behind the random index.

Selection is allocation-flat in the size of the combination space: one pass
counts valid combinations, rejection sampling draws an unbiased index, and a
second pass walks to that index. No combination array is materialized. A
three-middle/three-exit directory has exactly 36 valid ordered quads. Fixed draws
0 through 35 select all 36 in enumeration order; draw 0 selects
`middle-1/exit-0, middle-2/exit-1`, and draw 35 selects
`middle-3/exit-2, middle-2/exit-1`. The four valid replacement pairs after a
four-plus-four fixture's initial two pairs are likewise reached by draws 0
through 3.

Counts up to 256 use one random byte; larger bounded counts use two. The
eight-plus-eight maximum-shape fixture has 3,136 valid ordered quads and requests
two bytes. A singleton spends no entropy. For the 36-combination case, byte 252
is rejected and byte 35 selects index 35 rather than introducing modulo bias.
Repeated rejection is capped at 128 draws and invalidates the directory, so a
hostile entropy callback cannot retain ownership or loop forever.

The sink's exact source contract now owns `randomBytes` beside both clocks and
threads it through the sealed token into the directory. The initial endpoint
passes its already-injected capability; reconnect uses the existing
`cryptoSuite.randomBytes` capability already passed to bootstrap IO at that
construction seam. Every constructor validates own data exactly. Throwing,
malformed, endlessly rejecting, reentrant, and destroy-during-draw callbacks
clear candidate ownership, retain no callback, and publish no reservation.

The original blocker was the eleven-role fixture, not the directory. It minted only
three matched middle-to-exit grants (`3-4`, `5-6`, `7-8`), while a directory of
three middles and three exits has 36 ordered diverse quads and only six use those
matched pairs. Uniform selection therefore produced a harness-servicable topology
only one time in six.

The fixture now models the production contract:

1. `ALLOW_EDGES` and signed topology grants contain the full 3x3 middle/exit
   bipartite matrix.
2. Every middle receives all three exit contacts/grants and resolves the
   authenticated selected identity and endpoint dynamically.
3. Every exit atomically pre-arms all three possible predecessor grants. The
   endpoint-selected opaque source handle is preserved through the role callback;
   a boolean-only TEST_ONLY matcher dispatches the datagram only to the exact
   session that owns that live source relation. No tuple, identity, or handle is
   exposed.
4. Winner/loser cleanup is one ownership transaction. A teardown lock and shared
   completion promise prevent new acquisition or overlapping fault/destroy from
   missing held sessions; cross-arm packets consume no grant.
5. Snapshots expose only nullable reciprocal role indexes. The coordinator derives
   active lookup, announce, standby, rotation, and the physical-fault target from
   those relationships and observed counters rather than role labels.

Before production randomness was enabled, the corrected harness proved both
candidate orders with different fixed first-match paths and a state-derived fault
target. Restoring the fixed `lookup-middle-a` target made the reverse run fail at
assertion 45, proving the mutation reached the formerly coupled path. That was
the structural prerequisite; selection is no longer pinned to either recorded
pairing.

One shortcut is worth ruling out explicitly, because it looks cheap. Pinning the
draw inside the harness so the first combination always wins would keep the gates
green without generalising anything. It does not work. The harness passes the real
`cryptoSuite.randomBytes` into `createEndpointBootstrapAuthority` at
`role-runner.js:234`, and that same capability supplies bootstrap nonces, so it
cannot be pinned in isolation. Pinning only the draw means a second,
selection-only entropy capability whose only caller is the harness, and it would
make middle i with exit i a permanent fixture assumption, which is the coincidence
the `exitPairs` correction below removed. It buys green gates by having them prove
something production would not do.

The production draw exposed a real reconnect race, not a harness race: the
preferred tier can legitimately redraw a pair that was live immediately before
suspend, while its remote circuit still owns the link grants. Waiting on the
1.5-second link-liveness bound does not release it because the old middle and exit
continue heartbeating each other.

Suspend now performs an authenticated end-to-end teardown before publishing
reconnect authority. `BRANCH_TEARDOWN_V1` (`0x0027`) travels endpoint → guard →
middle → exit and `BRANCH_TEARDOWN_ACK_V1` (`0x0028`) returns only after each
downstream actor has drained operations and joined its link/grant release. Both
carry the exact branch class, branch ID, circuit ID, generation, intentional
suspend reason, and a nonzero 16-byte teardown ID in one 58-byte M3 datagram body.
Same-ID retries are idempotent, completed exits can resend a bounded cached ACK,
and a different ID is replay-fatal.

The endpoint retries at the existing 500ms link-ping cadence under the existing
5s circuit-teardown deadline. Timeout, malformed ACK, release failure, network
change, or destroy cancels both branch transactions and enters `UNAVAILABLE`;
release is never inferred. Success ordering is exact: stop applications, settle
both exit releases, settle middle then guard downstream releases, receive both
ACKs, destroy both branch materials, retain the directory, suspend the guard
lease, then publish reconnect authority. The eleven-role test still calls
suspend → resume directly; there is no coordinator-only prepare command or
pre-resume barrier.

Final Linux process gates pass through teardown in all four required modes:
normal Node 132/132, normal Bare 132/132, reversed Node 132/132, and reversed
Bare 132/132. Host-only aggregation remains insufficient evidence because the
eleven-role scenarios are excluded from `test/private-routing.js`.

Focused teardown proofs pass: M3 48/48 tests (373 assertions), DHT exit 8/8
(52), route manager 19/19 (280), controller 8/8 (77), protocol 14/14 (755),
live authority 11/11 (63), and process services 4/4 (46).

Mutation proofs are load-bearing. Replacing the unbiased draw with fixed index
zero makes the directory suite fail 27/31 tests with only one of 36 combinations
reachable. Drawing reconnect bootstrap pairs directly from `all` makes the KI-14
test fail both assertions that the faulted middle and exit are not redrawn.
Removing teardown send, acknowledging before downstream release, accepting a
different teardown ID, disabling retry, treating timeout as success, or
publishing reconnect after only one ACK each fails its focused ordering gate.

## Comparison with Veilid

Reviewed `veilid-core/src/routing_table/route_spec_store` on `main`, since Veilid
solves a closely related problem on a permissionless P2P network.

Veilid composes a route from a sender-allocated safety route and a
destination-published private route, one hop each by default. Allocation tries
progressively looser passes, `UniqueIpblockDiverse` then `Unique` then
`AllowDuplicateHops`, crossed with a relay-capability preference of all hops,
last hop only, then none, over a high-pass-filtered slice of the routing table.
Selection sorts candidate routes by whether they need testing, then stability,
then latency, and round-robins among the top tier with an atomic counter.
Allocated routes are persisted and reused, and a caller may pin a preferred one.

Three things were checked against that design:

- **Nodes learned through a route.** Veilid had to isolate nodes discovered only
  via a private route so the general routing table does not ping them, which
  would correlate a route participant with an IP. That exposure does not exist
  here. `relay-candidate-directory.js` performs no network I/O at all, and after
  readiness the endpoint holds no direct send authority, which the namespace
  oracle already proves by observing that its only edge is its guard.
- **Hop diversity.** Present, and stricter. Ours applies across the guard and
  both branches at once and fails closed; Veilid's equivalent is dropped on
  small networks.
- **Exclusion when rebuilding.** Present. `chooseReplacementPair` takes an
  exclusion set and diversity is revalidated at commit.
- **Which qualifying hops get chosen.** The first-match gap identified in this
  comparison is fixed under
  [KI-6](#ki-6-hop-selection-is-first-match-not-random--fixed): initial,
  reconnect, and replacement selection now sample uniformly within the chosen
  valid diversity/demotion tier. The earlier comparison with Veilid's
  predictable round-robin selection is historical, not an open first-match task.

Two of Veilid's choices are deliberately not adopted. Latency-ranked selection
prefers well-resourced relays, which is exactly what a funded adversary can most
cheaply supply. Silent relaxation of diversity trades a privacy property for
availability without telling anyone; for this system "no route" is a better
failure than "worse route".

Two real differences remain in Veilid's favour or as future work. Veilid hides
the destination as well as the sender, whereas here the exit performs an ordinary
DHT operation and the capture shows the retrieved value plainly on that edge.
Veilid also maintains a pool of routes and distributes across it, where this fork
builds one set per generation; a pool would be the prerequisite for choosing
among qualifying routes at all.

## Reviewed prototype source

Every migrated module below came from the reviewed private-routes prototype at exact commit `0305df915b6a767093f9e75e6c06bc0a35da6169`. The migration changed ESM imports and exports to HyperDHT's CommonJS module style, changed local import paths, and retained the listed focused/vector coverage. Subsequent fork review added defensive ownership, hostile-shape handling, intrinsic capture, bounded allocation, and clearing checks without intentionally changing the listed normative protocol bytes.

| Migrated private file                      | Exact prototype source and commit                                                                                                                                                                                    | CommonJS adaptation and retained focused/vector coverage                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     |
| ------------------------------------------ | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `lib/private/errors.js`                    | `packages/private-routes/lib/errors.js` at `0305df915b6a767093f9e75e6c06bc0a35da6169`                                                                                                                                | ESM exports became a CommonJS object containing frozen error-code registries and the error class. `test/private/protocol.js` retains the error assertions adapted from prototype `test/protocol.test.js` and `test/m3-protocol.test.js`.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     |
| `lib/private/protocol.js`                  | `packages/private-routes/lib/protocol.js` at `0305df915b6a767093f9e75e6c06bc0a35da6169`                                                                                                                              | ESM imports/exports became local `require()` calls and a CommonJS object containing frozen registries, maps, and values plus codec helpers. `test/private/protocol.js` retains the protocol, message-ID, domain, role, strict-shape, and hostile-buffer vectors adapted from prototype `test/protocol.test.js` and `test/m3-protocol.test.js`.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               |
| `lib/private/crypto-suite.js`              | `packages/private-routes/lib/crypto-suite.js` at `0305df915b6a767093f9e75e6c06bc0a35da6169`                                                                                                                          | ESM imports/exports became CommonJS using HyperDHT's existing `sodium-universal`, `hypercore-crypto`, and `b4a` dependencies. `test/private/crypto-suite.js` retains generic transcript/KDF, X25519, nonce, substitution, and clearing vectors adapted from prototype `test/crypto-suite.test.js` and relevant `test/adversarial.test.js` cases. Exact M3 transcript construction is intentionally absent.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   |
| `lib/private/counters.js`                  | `packages/private-routes/lib/counters.js` at `0305df915b6a767093f9e75e6c06bc0a35da6169`                                                                                                                              | ESM exports became CommonJS; counter semantics and bounds remain covered by `test/private/counters.js`, adapted from prototype `test/counters.test.js` and the counter cases in `test/adversarial.test.js`.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  |
| `lib/private/cell-codec.js`                | `packages/private-routes/lib/cell-codec.js` at `0305df915b6a767093f9e75e6c06bc0a35da6169`                                                                                                                            | ESM imports/exports became CommonJS with local private-module paths. `test/private/cell-codec.js` retains exact layout/hash, padding, authentication, substitution, allocation, hostile-buffer, and clearing coverage adapted from prototype `test/cell-codec.test.js`, `test/property.test.js`, and `test/adversarial.test.js`.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             |
| `lib/private/route-payload.js`             | `packages/private-routes/lib/route-payload.js` at `0305df915b6a767093f9e75e6c06bc0a35da6169`                                                                                                                         | ESM imports/exports became CommonJS with local private-module paths. `test/private/route-payload.js` retains exact payload, direction/class/generation substitution, replay, ownership, nonce, and clearing coverage adapted from prototype `test/route-payload.test.js`, `test/property.test.js`, and `test/adversarial.test.js`. Gate 3A retains a fail-closed process-local ceiling of 4,096 nonce-domain claims; durable generation ownership is deferred.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               |
| `lib/private/fragments.js`                 | `packages/private-routes/lib/fragments.js` at `0305df915b6a767093f9e75e6c06bc0a35da6169`                                                                                                                             | ESM imports/exports became CommonJS and the reviewed Gate 3A resource ceilings were reduced and made explicit. `test/private/fragments.js` retains and extends prototype `test/fragments.test.js` and fragmentation cases from `test/property.test.js`, including ceilings, expiry, allocation order, conflict handling, ownership, and clearing.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            |
| `lib/private/exit-policy.js`               | `policyEntry`, the nine `EXIT_ORIGIN_SERVICE_POLICY` entries, and policy encode/decode/digest pieces from `packages/private-routes/lib/final-exit.js` at `0305df915b6a767093f9e75e6c06bc0a35da6169`                  | Only the immutable policy pieces were extracted into CommonJS; live exit state, socket ownership, and activation were not migrated. `test/private/exit-policy.js` retains the exact policy bytes/digest and immutability assertions adapted from prototype `test/final-exit-activation.test.js`.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             |
| `lib/private/routed-dht.js`                | `packages/private-routes/lib/routed-dht.js` at `0305df915b6a767093f9e75e6c06bc0a35da6169`                                                                                                                            | ESM imports/exports became CommonJS and the policy import points to the extracted local module. `test/private/routed-dht.js` retains exact destination/request bytes, policy equality, branch, deadline, size, hostile-shape, and clearing coverage adapted from prototype `test/routed-dht.test.js` and the policy assertions in `test/final-exit-activation.test.js`. The prototype supplies no routed-reply wire codec, so none is claimed here.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          |
| `lib/private/relay-capability.js`          | `packages/private-routes/lib/relay-capability.js` at `0305df915b6a767093f9e75e6c06bc0a35da6169`                                                                                                                      | Gate 3B1 retains the exact advertisement, endpoint, DHT-node-ID, provider-policy, CAPS-cookie, active-challenge, response, signature, and digest bytes covered by prototype `test/relay-capability.test.js`. The CommonJS migration narrows accepted capability masks to circuit-only safety relays (`1`) and circuit-plus-DHT private exits (`3`), adds strict own-data validation and defensive ownership, and replaces the prototype directory state machine with the internal `RelayCapabilityVerifier` epoch, quarantine, active-proof, clock-rollback, expiry, and erasure owner tested by `test/private/relay-capability.js`. It exposes no public discovery or dialing API.                                                                                                                                                                                                                                                                                                                                                                                          |
| `lib/private/link-setup.js`                | `packages/private-routes/lib/link-setup.js` at `0305df915b6a767093f9e75e6c06bc0a35da6169`                                                                                                                            | CommonJS port retaining exact LINK CREATE/CREATED vectors, one-shot ticket ownership, replay bounds, timer behavior, hostile crypto adapters, and deep zeroization from prototype `test/link-setup.test.js`, now in `test/private/link-setup.js`.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            |
| `lib/private/topology-grant.js`            | `packages/private-routes/lib/topology-grant.js` at `0305df915b6a767093f9e75e6c06bc0a35da6169`                                                                                                                        | CommonJS port retaining the exact signed-grant bytes, adjacency/role checks, bounded grant and link-handle tables, replay tombstones, long-horizon timers, reentrant callback cleanup, and destroy behavior from prototype `test/topology-grant.test.js`, now in `test/private/topology-grant.js`.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           |
| `lib/private/link-parameters.js`           | Pure admitted-limit functions from `packages/private-routes/lib/tail-control.js` and pure payload-parameter functions from `packages/private-routes/lib/final-exit.js` at `0305df915b6a767093f9e75e6c06bc0a35da6169` | One CommonJS owner freezes the exact 26-byte admitted-limit and 20-byte payload-parameter formats and their registry digests. No tail or final-exit state was imported.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      |
| `lib/private/guard-link.js`                | Index-zero portions of `packages/private-routes/lib/guard-link.js` at `0305df915b6a767093f9e75e6c06bc0a35da6169`                                                                                                     | Intentionally partial CommonJS port exposing only index-zero offer/responder/complete/abort and established-link ownership. `test/private/guard-link.js` retains the exact fixed messages, transcript digest, mutual contexts, substitution/replay/reentry cases, and destruction checks. Tail extension, redacted responder proof, adjacency adoption, and final-exit paths remain deferred to Gate 3B1 Chunk 2 tasks.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      |
| `lib/private/bootstrap-envelope.js`        | `packages/private-routes/lib/bootstrap-envelope.js` at `0305df915b6a767093f9e75e6c06bc0a35da6169`                                                                                                                    | CommonJS port retaining the exact 1,200-byte envelope, 150-byte header, signature domain, request/body bindings, bilateral link ownership, five-second deadline, pending/cache/tombstone bounds, replay handling, allocation order, and reentrant adapter cleanup from prototype `test/bootstrap-envelope.test.js`, now in `test/private/bootstrap-envelope.js`. The source tuple remains out-of-band and no wire field was added.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           |
| `lib/private/bootstrap-io.js`              | Cold-start authority narrowed from `packages/private-routes/lib/bootstrap-io.js` at `0305df915b6a767093f9e75e6c06bc0a35da6169`                                                                                       | Gate 3B1-only owner for one to three numeric configured endpoints, at most sixteen signed candidates, sequential prospective-guard challenges, one ten-second budget, redacted exposure, exact index-zero establishment, Task 3 directory sealing, generic-send revocation-before-resolution, and atomic one-shot guard-pin transfer. Task 5 replaces the old fake M3 handoff with one opaque reservation, opens the shared LINK CREATE/CREATED session under the absolute operation and signed-advertisement deadlines, awaits establishment, and pins that exact token. The Task 4 fake-datagram boundary implements the same nonforgeable open/pin contract. It has no public state callback, DNS, referral, fallback, middle, or exit contact surface.                                                                                                                                                                                                                                                                                                                   |
| `lib/private/guard-reconnect-authority.js` | Adapted from `packages/private-routes/lib/guard-revalidation-io.js` at `0305df915b6a767093f9e75e6c06bc0a35da6169`                                                                                                    | Replaced the broad revalidation IO with one zero-argument WeakMap capability permanently bound to the pinned identity, canonical tuple, advertisement digest/epoch/expiry, local identity, and a single five-second operation. Task 5 permits the transport to be obtained only through a zero-argument one-shot exact-tuple factory after the authority becomes spent; the previous direct fake transport remains solely for focused compatibility tests. It performs only self-CAPS, active challenge, and index-zero guard link setup; revoke before/during IO is terminal.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               |
| `lib/private/m3-context.js`                | `packages/private-routes/lib/m3-context.js` at `0305df915b6a767093f9e75e6c06bc0a35da6169`                                                                                                                            | CommonJS port retaining the exact 54-byte associated-data layout and fixed 1,101-byte context envelope from prototype `test/m3-vectors.test.js` and `test/m3-adjacency-runtime.test.js`. `test/private/m3-context.js` freezes the byte vector and rejects field, direction, version, width, authentication-tag, nonce-counter, and trailing-byte substitution.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               |
| `lib/private/link-bootstrap-session.js`    | `packages/private-routes/lib/link-bootstrap-session.js` at `0305df915b6a767093f9e75e6c06bc0a35da6169`                                                                                                                | CommonJS port of the exact LINK CREATE/CREATED adjacent bootstrap lifecycle. Gate 3B1 additionally requires inherited `absoluteDeadline` and `signedExpiry`; the session can use only `min(start + 5,000, absoluteDeadline, signedExpiry)`. Focused Node/Bare tests cover identical retry bytes, one-shot establishment, opaque link ownership, delayed route-extension budget, rejection, and deterministic close.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          |
| `lib/private/link-control-session.js`      | Adjacent-link portions of `packages/private-routes/lib/link-control-session.js` at `0305df915b6a767093f9e75e6c06bc0a35da6169`                                                                                        | Narrow CommonJS port retaining fixed link-control wire bytes, CONTROL/STREAM ordering, DATAGRAM replay delivery decisions, bounded ACK state, 500 ms ping, 1,500 ms unresponsive close, five-second ACK/circuit teardown, counter exhaustion, opaque direction capabilities, and clearing. Prototype remote-actor and async route-control integrations are deliberately absent from this Task 5 owner.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       |
| `lib/private/udx-adapter.js`               | `packages/private-routes/lib/udx-adapter.js` at `0305df915b6a767093f9e75e6c06bc0a35da6169`                                                                                                                           | CommonJS adapter pinned to direct runtime dependency `udx-native@1.20.7`; it owns the reviewed internal symbol registry and platform-specific numeric loopback selection without adding any public dial API.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 |
| `lib/private/udx-cell-endpoint.js`         | Adjacent socket-owner portions of `packages/private-routes/lib/udx-cell-endpoint.js` at `0305df915b6a767093f9e75e6c06bc0a35da6169`                                                                                   | Sole native UDX instance/socket owner for one role process, with exact tuple/identity/generation reservations, PENDING/OPEN demultiplexing, 64-packet and 76,800-byte global queue bounds, per-peer inbound bounds, atomic reservation before packet copying, listener/native-send/socket close ordering, opaque local-secret/bootstrap authorities, pin-time direct-send revocation, and shared `GuardLeaseMaterial`. Established ownership binds and consumes an opaque internal token rather than exposing endpoint/session reservations. Lease destruction closes the original established owner exactly once. The zero-argument reconnect factory starts and awaits that same close before creating and binding a fresh socket owner, remains exact-tuple and one-shot, and closes the fresh owner on setup failure or revocation. Fake adapters are reachable only through the symbol-keyed one-shot test issuer; production Node/Bare loopback tests use the default native adapter. Prototype actor-control paths are excluded with the narrowed link-control owner. |

### Gate 3B1 authenticated M3 transport and tail ownership amendment

The exact Task 5 production contract now lives in the Gate 3B1 design's
[`AdjacentLink`](superpowers/specs/2026-07-18-private-routing-gate-3b1-live-immutable-get-design.md#adjacentlink)
section. The exact Task 6 stable owner, logical lifetime, authenticated
transport borrower, responder stages, forwarding, final-exit, and destruction
contracts live in the
[Task 6 responder-authority design](superpowers/specs/2026-07-19-private-routing-task6-private-responder-authority-design.md).
Those sections, not provisional structural objects, are the migration
boundary.

Migration must preserve these compatibility rules:

1. `udx-cell-endpoint.js` remains the sole UDX socket and established-record
   owner. An OPEN record first issues a slot-reserving one-shot
   `M3CellLinkTransferIssuer`; lexical `guard-link.js` authentication
   separately issues the exact `M3AuthenticatedBranchBinding`.
   `registerM3CellLinkTransfer(issuer, binding)` consumes and joins both,
   compares endpoint/link/setup, tuple/peer, link provenance, M3
   branch/circuit/generation/cell directions, and record-owned physical policy,
   then issues `M3CellLinkTransfer`. Revoke/failure removes tentative
   registration/charges and releases the slot exactly once. No production or
   test migration may replace either proof with a structural channel or fake
   issuer.
2. Existing 64-packet/76,800-byte global and 8-packet/9,600-byte per-peer UDX
   bounds remain exact. Record-bound `{ epoch, circuitId, direction }` M3
   dispatch uses the M3 branch/runtime generation as offset-4 `epoch`; the
   established LinkControlSession epoch is separate provenance checked during
   issuer registration, transfer take, and adoption. The specified
   four/shared or one/non-shared borrower limits, two initiator or one
   responder receive reservations, and full 1,200-byte receipt/envelope
   charges are additive. Logical release returns every charge/registration
   without closing a shared GuardLease physical link.
3. Non-shared relay M3 runtime ownership moves only the exact opaque
   `physicalOwner`; shared pinned-guard runtimes never gain physical close
   authority. `extension-setup-channel.js`, `guard-link.js`, and
   `M3AdjacencyAuthority.adopt` move the issuer, authenticated binding, and
   registered transfer instead of reading `physicalChannel.destroy`.
4. Task 6 takes the authenticated borrower into one stable `TailControlOwner`
   and independently timed `M3TailLifetime`. Client completion, both successor
   sessions, RouteExtension transfer, final-exit handoff, and Task 7/Task 9
   same-runtime activation move that same state; none creates a replacement
   deadline, timer, transport, lifetime, or borrower.
5. Clean cutover removes structural `tailControlTransportFactory` input and a
   consumer `.destroy()` method. The session remains exactly five methods;
   destruction and borrowing use package-private `destroyTailControlSession`
   and `borrowTailControlTransport`.
6. Responder forwarding carries the stable owner through a one-shot
   `TailForwardingTransfer`. `completeTailExtend` emits the exact frozen
   `{ transfer, publicationClaim }` runtime-event payload, and the registry
   presents that object-identical claim when taking the transfer synchronously.
   Its exact M3 lease owns lifetime/callback and both borrower identities; the
   taken value carries opaque owner, lease, claim, and forwarding facade. The
   registry publishes both runtime records before an exact receipt permits
   logical lifetime/transport release. Clock/deadline mismatch fails
   publication; every rollback destroys the pair and releases both slots. No
   facade-only transfer or hidden-claim lookup is compatible.
7. `final-exit-activation.js` alone issues
   `FinalExitActivationClaim`/`FinalExitActivationOwner` and exposes the exact
   `claimFinalExitActivation` operation. Its fixed prepare/commit/revoke bridge
   keeps `TAIL_CONTROL_OWNERS` lexical, verifies the live handoff,
   lifetime/callback/clocks/deadline/generation, and routes cleanup from either
   module without accepting an arbitrary destructor.
8. Task 7 ports the terminal DHT-exit ACTIVATE/READY/ACK/OPEN codec and
   derivation layer, binds READY signing to a relay-identity-owned
   `DHT_EXIT_READY` one-shot signer, and keeps endpoint actors on claimed
   activation owners instead of raw identity secrets, raw handoff material, or
   arbitrary callbacks. `final-exit-activation.js` lexically issues the
   terminal `OpenRouteHandoff` only after authenticated OPEN; the deep import
   exposes only consume/revoke/destroy, and unconsumed handoffs are revoked by
   activation-owner destruction.

Task 6 changes no existing wire byte, message order, public HyperDHT API,
direct-mode behavior, or address-authority boundary. One 1,101-byte M3 context
envelope still produces one 1,200-byte CONTROL cell. The implementation depends
on Task 5 production OPEN-record issuers, record-bound demultiplexing, and
reservation accounting; fake issuers, raw sockets, arbitrary callbacks,
physical destructors, and direct dial authority remain incompatible
substitutes.

Local Task 6 verification used Node v22.19.0, npm 11.10.0, and the exact Bare
v1.30.3 runtime restored into `/tmp/hyperdht-bare-v1.30.3` outside the
repository:

- Focused Task 6 suite
  (`test/private/route-extension.js`, `test/private/guard-link.js`,
  `test/private/udx-cell-endpoint.js`, `test/private/m3-adjacency-runtime.js`,
  `test/private/tail-control.js`, `test/private/tail-extension-committer.js`,
  `test/private/final-exit-handoff.js`, and
  `test/private/final-exit-activation.js`) passed independently in Node and
  Bare with 135/135 tests and 1,660/1,660 assertions.
- Complete private aggregate `test/private-routing.js` passed independently in
  Node and Bare with 662/662 tests and 14,937/14,937 assertions.
- `npm test` passed its repository-wide Prettier check, then reproduced the
  documented local host-topology exception in direct-mode
  `createServer + connect - same-LAN explicit keypair opens server`: Node
  observed `HOLEPUNCH_ABORTED` in top-level test 18 and timed out without a
  final TAP summary. This local full-suite run is not reported as green.
- Exact Bare v1.30.3 direct full-suite verification reached 749 top-level
  tests and 15,264 assertions, failing only the same direct-mode same-LAN
  explicit-keypair case with `ETIMEDOUT`; final TAP was 748/749 tests and
  15,263/15,264 assertions. This local full-suite run is not reported as
  green.

Local Task 7 verification used Node v22.19.0, npm 11.10.0, and Bare v1.30.3:

- Focused Task 7 suite
  (`test/private/final-exit.js`, `test/private/final-exit-activation.js`,
  `test/private/final-exit-handoff.js`, `test/private/open-route-handoff.js`,
  and `test/private/relay-identity-signer.js`) passed independently in Node
  and Bare with 27/27 tests and 273/273 assertions.
- Complete private aggregate `test/private-routing.js` passed independently in
  Node and Bare with 675/675 tests and 15,054/15,054 assertions.

Local Task 8 verification used Node v22.19.0, npm 11.10.0, and Bare v1.30.3:

- `lib/private/relay-service.js` ports bounded opaque relay forwarding from
  the reviewed prototype, retaining the canonical 128 global circuits, 32
  circuits per observed neighbor, 256 KiB per-circuit queue, 8 MiB global
  queue, five-second relay deadlines, replay tombstones, downward-only
  negotiated limits, and `ERR_BUSY`/`ERR_QUOTA_EXCEEDED` failure split.
- The relay service stores only opaque previous-hop and next-hop capabilities
  plus local circuit/generation/accounting state. Queue accounting is reserved
  before payload copies; allocation/callback failures roll back queue bytes and
  replay counters, with the admission-boundary callback rollback covered
  explicitly. Destroy tombstones routing state before closing adjacent
  capabilities so reentrant callbacks see destroyed state.
- Focused Task 8 suite (`test/private/relay-service.js`) passed independently
  in Node and Bare with 12/12 tests and 73/73 assertions.
- Complete private aggregate `test/private-routing.js` passed independently in
  Node and Bare with 689/689 tests and 15,147/15,147 assertions.

Local Task 9 Step 1 verification used Node v22.19.0, npm 11.10.0, and Bare
v1.30.3:

- `lib/private/guard-lease.js` adds the opaque GuardLease owner for a pinned
  SHARED_GUARD bootstrap material record. Lease creation consumes the
  `GuardLeaseMaterial`, binds the separately returned pinned guard identity and
  endpoint tuple, and retains physical close authority without exposing raw
  endpoint, established-link, or secret material.
- `lib/private/udx-cell-endpoint.js` brands the OPEN record only during
  bootstrap pinning, rejects preexisting generic M3 transfer ownership before
  branding, and permits at most four live shared-guard M3 transfer issuer/
  transfer slots. Destroying a shared logical transfer releases only its slot;
  GuardLease destroy revokes every shared slot before closing the physical
  owner once.
- Focused Task 9 Step 1 suite (`test/private/guard-lease.js`,
  `test/private/udx-cell-endpoint.js`, `test/private/guard-link.js`,
  `test/private/m3-adjacency-runtime.js`) passed independently in Node with
  102/102 tests and 1,419/1,419 assertions.
- Complete private aggregate `test/private-routing.js` passed independently in
  Node and Bare with 693/693 tests and 15,170/15,170 assertions.

Local Task 9 Step 2 verification used Node v22.19.0, npm 11.10.0, and Bare
v1.30.3:

- `lib/private/branch-path-authority.js` builds an atomic initial lookup/
  announce draft from one relay-directory transaction. It consumes exactly four
  selected evidence objects, binds the directory scope to the pinned
  `GuardLease`, rejects guard/candidate identity and subnet collisions, reserves
  four shared-guard M3 slots, and aborts without committing on destroy or
  failure.
- `lib/private/route-extension.js` and `lib/private/final-exit-activation.js`
  own the empty opaque route-extension/final-exit factory capabilities. The
  wrappers `openRouteExtension(factory, exactOptions)` and
  `openFinalExit(factory, exactOptions)` inject only the factory-owned wall
  clock, monotonic clock, random source, scheduler, and cancellation function;
  final-exit retry and retired/replayed OPEN helpers also reject caller RNG.
  `lib/private/route-manager.js` validates those same factory capabilities and
  still exposes only the initial `buildInitialPair()`, `branchCapability()`, and
  `destroy()` manager surface until terminal OPEN publication lands.
- Focused Task 9 Step 2 suite (`test/private/branch-path-authority.js`,
  `test/private/route-manager.js`, `test/private/guard-lease.js`,
  `test/private/udx-cell-endpoint.js`) passed independently in Node with 27/27
  tests and 228/228 assertions. The new branch/manager tests also passed
  independently in Bare with 8/8 tests and 95/95 assertions.
- Focused Task 9 Step 3 suite (`test/private/route-manager.js`,
  `test/private/route-extension-session.js`,
  `test/private/final-exit-activation-session.js`,
  `test/private/final-exit-activation.js`) passed in Node with 19/19 tests and
  157/157 assertions. The final-exit facade proof now consumes the authenticated
  responder OPEN handoff and proves replay/revoke/destruction semantics.
- Focused Task 9 Step 4/5/6 suite (`test/private/route-manager.js`,
  `test/private/guard-lease.js`, `test/private/branch-path-authority.js`,
  `test/private/route-extension-session.js`,
  `test/private/final-exit-activation.js`, and
  `test/private/udx-cell-endpoint.js`) passed in Node and Bare with 42/42
  tests and 354/354 assertions. The route manager now publishes the initial
  lookup/announce OPEN pair transactionally, exposes only branch-local empty
  capabilities after publication, rotates one branch make-before-break while
  preserving the opposite branch capability, clamps replacement construction to
  the directory guard/selected relay signed expiries, rolls failed rotation
  attempts back without leaking consumed OPEN material, and suspends by revoking
  manager operations, branch material, guard issuers, and the live socket while
  retaining only a one-shot reconnect authority and sealed directory.
- `lib/private/dht-exit-seeds.js` freezes the DHT-only exit seed set as
  signed `DHT_EXIT_DHT_SEEDS_V1` bytes. `test/private/dht-exit-seeds.js`
  proves exact one- and three-reference encodings, strict 1..3 count
  bounds, canonical set-digest input, canonical destination ordering,
  branch/exit binding, clocked expiry rejection, hostile descriptor
  rejection, signature verification, and zeroization.
- `lib/private/dht-exit-destination-table.js` admits only live,
  ping-correlated configured bootstrap references, sorts seed refs by
  canonical decoded id/handle order before signing, and exposes seed delivery
  only through a revocable one-shot authority. Destroying the table revokes
  unconsumed seed-delivery authorities.
- `lib/private/dht-exit-wire.js` owns the client-only DHT-RPC packet subset
  adapted from dht-rpc commit `fe04496196ea2ce42d1de27b0f770b02d2a87cd5`
  under MIT provenance: `Request._encodeRequest`, `decodeReply`,
  `validateId`, and the IPv4 peer codec only. `test/private/dht-exit-wire.js`
  freezes command-0 PING and HyperDHT command-9 IMMUTABLE_GET request bytes,
  response byte `0x13`, u16 transaction byte order, destination tuples,
  empty/error/full reply flag mixes, invalid IDs, trailing bytes, and
  request-packet rejection in Node and Bare.
- `lib/private/dht-exit-reservation.js` and `lib/private/dht-exit-io.js`
  add the exit-side one-socket reservation boundary. The endpoint OPEN
  authority is a distinct handoff-carried capability, not accepted by the
  exit reservation channel.
- `requestDhtExitImmutableGet` accepts one validated routed immutable-get request,
  reserves its ordinary UDP operation before send, and emits one normalized
  `ROUTED_REPLY_V1`. Referral tuples are reply-correlated, bounded, probed before
  admission, deduplicated against live destination IDs, and sorted by unsigned
  XOR distance. The operation owns every pending TID and settlement authority;
  cancellation, socket close, deadline expiry, table destruction, and
  synchronous callback failure revoke all remaining authority without emitting
  a duplicate reply. Raw immutable values remain bounded to 1,023 bytes before
  any referral can be admitted.
- Focused DHT-exit Task 13 suite (`test/private/dht-exit-wire.js`,
  `test/private/dht-exit-destination-table.js`, `test/private/dht-exit-io.js`,
  and `test/private/dht-exit-immutable-get.js`) passed in Node and Bare with
  27/27 tests and 248/248 assertions.
- Focused DHT-exit Task 12 suite (`test/private/dht-exit-seeds.js`,
  `test/private/dht-exit-destination-table.js`,
  `test/private/dht-exit-test-topology-grant.js`,
  `test/private/dht-exit-wire.js`, `test/private/dht-exit-reservation.js`,
  and `test/private/dht-exit-io.js`) passed in Node and Bare with 22/22 tests
  and 240/240 assertions.

### Gate 3B1 Task 15 live controller and lifecycle checkpoint

Task 15 connects the previously reviewed package-private owners into one
production-code, in-process lifecycle without changing HyperDHT's root public
surface:

- `lib/private/private-routing-controller.js` owns the exact `OFF`,
  `BOOTSTRAPPING`, `GUARD_PINNED`, `BUILDING`, `READY`, `ROTATING`,
  `SUSPENDED`, `UNAVAILABLE`, and `DESTROYED` state machine. Its frozen
  capability exposes only `start`, `snapshot`, `immutableGet`, `suspend`,
  `resume`, `networkChanged`, and `destroy`.
- `lib/private/live-route-authority.js` and
  `lib/private/opaque-destination.js` retain each branch's moved OPEN
  route transport and payload codec, admit signed exit seeds, publish
  generation-bound address-free destinations, and carry only the reviewed
  immutable-get command. Failed live send/receive operations issue an exact
  branch-loss signal; cancellation and intentional teardown do not.
- The controller's `start` method consumes only `EndpointBootstrapAuthority`, then
  drives production `BootstrapIO`, `GuardLease`, lookup/announce branch
  construction, authenticated tail extension, final-exit
  ACTIVATE/READY/ACK/OPEN, signed DHT-exit seed delivery, route admission, and
  immutable lookup. No test-only controller issuer, raw socket, endpoint,
  identity secret, or structural route authority participates in the hosted
  success path.
- Rotation is make-before-break and branch-local. Natural expiry, rejected
  route IO, or authenticated `BRANCH_DESTROY_V1` propagation replaces only the
  affected branch, advances its generation, preserves the other branch and
  shared physical guard, and releases every retired logical M3 forwarding
  owner. Candidate exhaustion or replacement failure closes owned resources and
  enters `UNAVAILABLE`.
- Suspend synchronously installs one shared in-flight result, revokes both live
  branches and routed destinations, closes native route ownership, and retains
  only the sealed directory plus one-shot guard reconnect capability. Resume
  consumes that capability and builds fresh generations. Network change,
  wall-clock rollback, guard loss, partial initial construction, and teardown
  fail closed with deterministic ownership cleanup and key zeroization.
- `test/private/live-immutable-get.js` exercises a fully hosted native
  endpoint/guard/middle/exit/DHT-exit topology: READY, exact immutable value,
  natural lookup rotation, idle downstream lookup replacement, idle announce
  loss fail-closed behavior, shared-guard loss, suspend/resume, network change,
  and negative absent-service startup. The relay actors are hosted in-process;
  Task 16 process isolation remains required before the multi-process criterion
  is complete.
- Final Task 15 verification ran `test/private-routing.js` independently under
  Node v22.19.0 and Bare v1.30.3: both passed 798/798 tests and
  16,124/16,124 assertions. Focused native hosted lifecycle coverage passed
  13/13 tests and 119/119 assertions under each runtime.

### Gate 3B1 Task 17 live eleven-process scenario status

`test/private/live-process-suite.js` drives eleven separate role processes over
native UDX loopback. It is test infrastructure, not a public API, and carries no
anonymity claim.

At `cae9721`, the normal and reverse scenarios pass 175 assertions each with
both Node and Bare role children. They prove,
live and cross-process: ordered DHT role bind and the audited setup store;
endpoint bootstrap, guard pinning, and separate lookup/announce branches built
through authenticated adjacent links; an exact immutable get retrieved through
the three-position route either directly from the configured DHT path or after
the exit admits an isolated learned closer under a signed Task 12 grant;
delayed-lookup cancellation; a silent native lookup-middle route-cell blackhole
that triggers link-loss propagation and rotates the endpoint onto a fresh pair,
followed by a second exact immutable get; exit accounting for referral probes and
ordinary requests; endpoint suspend and resume, including a third exact immutable
get over the rebuilt route; required-mode immutable/mutable puts at their
maximum value sizes with exact readback and independent storage snapshots;
required-mode blinded presence publication, resolution, revocation, and
tombstone resolution; a terminal network change that leaves no endpoint
socket and installs no fallback edge; and ordered teardown with zero residual
operations, resources, and queued bytes in every role.

Reaching resume, rotation, and network-change required four fixture
and owner corrections, each of which is now part of the proof:

- The fixture issues a per-generation pool of one-shot topology grants
  (`LEARNED_GRANT_USES` referral, value, and seed grants per adjacency and
  generation) because `LinkDirectory` keeps one link handle per grant and
  `UdxCellEndpoint.openLink` refuses a consumed handle, so every rebuilt branch
  must re-probe its learned closers with fresh grants.
- Guard bootstrap acceptance and relay accept sessions are re-armable, so a
  rebuilt branch can re-enter the same guard.
- Exit grant requests are serialized: exits allow one outstanding isolated grant
  request per exit and answer `COUNTER_EXHAUSTED` for a concurrent second, which
  the DHT retries against later candidates.
- `DHTExitIO` seeds its request TID from a random 16-bit counter rather than zero,
  so a socket rebuilt on a reused host/port after suspend does not collide with
  the TIDs of the pre-suspend session and have its replies dropped as duplicates.

The eleven-role scenarios are not part of the portable aggregate. They bind the
`127.64.x.1` role tuples, which macOS and Windows refuse without per-address
configuration (KI-2), so they run from their own scripts under the Linux CI job
while `test/private-routing.js` stays green everywhere:

These are measured results for the published `cae9721` source/test tree on
2026-09-09, not protocol contracts. All ten gates passed in one uninterrupted
run. Earlier totals remain in the dated history; documentation-only changes do
not re-date that evidence. Native-Linux CI and the cross-platform build results
are linked in the [publication checkpoint](#continuation-checkpoint--2026-09-09-required-mode-puts-and-v2-allocation).

| Suite                              | Command                                            | Result                                             |
| ---------------------------------- | -------------------------------------------------- | -------------------------------------------------- |
| Private aggregate, Node            | `npx brittle-node test/private-routing.js`         | 1,094/1,094 tests, 19,730/19,730 assertions, Linux |
| Private aggregate, Bare            | `bare test/private-routing.js`                     | 1,049/1,049 tests, 19,595/19,595 assertions, Linux |
| Eleven-role scenario, Node roles   | `npm run test:private:process:node`                | 175/175 assertions, Linux                          |
| Eleven-role scenario, Bare roles   | `npm run test:private:process:bare`                | 175/175 assertions, Linux                          |
| Eleven-role scenario, reverse Node | `bash scripts/linux-gates.sh process:node:reverse` | 175/175 assertions, Linux                          |
| Eleven-role scenario, reverse Bare | `bash scripts/linux-gates.sh process:bare:reverse` | 175/175 assertions, Linux                          |
| Eleven-role scenario, punch Node   | `bash scripts/linux-gates.sh process:node:punch`   | 180/180 assertions, Linux                          |
| Eleven-role scenario, punch Bare   | `bash scripts/linux-gates.sh process:bare:punch`   | 180/180 assertions, Linux                          |
| Namespace projection enforcement   | `npm run test:private:namespace`                   | 27/27 assertions, privileged Linux                 |
| Namespace live route and oracles   | `npm run test:private:namespace:live`              | 185/185 assertions; raw DROP 0                     |

### Gate 3B1 Task 17 wire-level privacy evidence

`test/private/live-namespace-node.js` runs the same eleven-process scenario with
every role in its own Linux network namespace, captures IPv4 traffic on every
veth, and checks the captured UDP bytes plus the independent kernel-drop
counter. The `cae9721` full run passes `185/185` with raw DROP zero. KI-16 records
the approved narrow teardown classification, its three-drop native positive
probe, and the injected ICMP echo that the gate rejects. Every UDP-specific
assertion still covers the full capture.

Isolation is structural, not asserted. Each role holds routes only to the peers
named by `ALLOW_EDGES`, and the root namespace forwards under a dedicated
iptables chain that ends in DROP for those devices. The endpoint's routing table
contains exactly one destination, its guard, and no default route, so a datagram
addressed anywhere else has no path rather than an unenforced prohibition.

The scenario is the full lifecycle, including the failure paths: bootstrap,
guard pinning, two branches, routed reads and maximum-size required puts,
required-mode presence publication/resolution/revocation, a silent route-cell
blackhole with lookup rotation, suspend and resume, a terminal network change,
and ordered teardown. What the capture shows across all of it:

| Observed on the wire                                                      | Assertion                                                         |
| ------------------------------------------------------------------------- | ----------------------------------------------------------------- |
| No datagram crossed a pair the topology forbids                           | `no datagram crosses a pair the topology forbids`                 |
| No unexplained kernel drop; raw DROP was zero in this recorded run        | `every kernel drop is a proven native-close ICMP reply`           |
| The endpoint's only destination, for the entire run, is its guard         | `the endpoint only ever sends to its guard`                       |
| The endpoint's encoded address never appears inside a cell past its guard | `the endpoint address never travels inside a cell past its guard` |
| No identity key, route key, MAC key or sentinel appears in any payload    | `no leak marker appears on any edge that carries route cells`     |
| No cell payload repeats on a second hop, so each hop re-encrypts          | `no cell payload is relayed unchanged across two hops`            |
| Every route cell is 1,200 bytes on every hop, on every edge               | `every route cell is the same size on every hop`                  |

The leak search is checked against itself. The retrieved value is deliberately
visible where the design says it must be, between an exit and a DHT node, and
`the value search is not vacuous` fails if the same search stops finding it. The
auditor/decoy namespace pair plays the same role for the capture harness in
`test/private/namespace-projection.js`: a capture that observes nothing there is
a broken harness, not a private route.

This supports a scoped claim and nothing wider. Under the
[v1 active-relay adversary](private-routing-v1.md#active-relay-adversary), where
any single guard, middle, exit or storage node may be malicious, these
[protected properties](private-routing-v1.md#protected-properties) now have
packet-level evidence: the endpoint has no direct send authority after
readiness, no failure path produces direct fallback, and the endpoint address
does not travel beyond its guard. This scenario has no application peer
streams, so it does not prove address privacy between application peers.

What this is still not. Every v1
[out-of-scope](private-routing-v1.md#out-of-scope-for-v1) item is untouched: a
global passive observer, timing correlation by colluding guards and exits, Sybil
resistance, and query privacy from exits. Uniform outer cell size does not hide
timing, packet counts, or operation-specific request/reply signatures, and
nothing in this gate pads to a constant rate, mixes, or adds cover traffic. An adversary watching
two edges can still correlate them. That is tracked as
[KI-1](#ki-1-routes-are-correlatable-by-timing-and-volume): a v1 design boundary
accepted on purpose, not a test gap, and the reason this remains an
experimental, package-private slice with no anonymity claim beyond the table
above.

Role clocks are supplied by `test/private/process/runtime-clock.js`. Wall and
monotonic time are derived from one cached sample of a single counter because the
route protocol carries a wall expiry into a monotonic deadline and rejects any hop
whose derived deadline exceeds the one it was handed; independent `Date.now()` and
`hrtime` samples straddling a millisecond boundary produced exactly that rejection.

### Gate 3A resource bounds

Fragmentation is limited to eight fragments, eight concurrent messages, eight buffered fragments, and a five-second message deadline. Eight full fragments carry at most 8,424 bytes of application data. Including the twenty-byte header in each of eight route payloads produces at most 8,584 encoded bytes; 8,584 is not an application-data limit. Public duplex segmentation across multiple internal messages is intentionally absent.

The route-payload nonce-domain registry is also deliberately process-local and capped at 4,096 claims. It never evicts an activated claim and fails closed at capacity. It is deterministic Gate 3A scaffolding, not the durable circuit/generation freshness mechanism required for live or mobile routing.

## Newly authored Gate 3A modules

The following files were authored in this fork and were not migrated from the prototype commit:

- `lib/private/dht-command-policy.js` defines the fail-closed immutable-get-only command mapping. `test/private/dht-command-policy.js` proves exact request encoding and rejection of every unsupported command before authority IO.
- `lib/private/query-context.js` creates per-instance, unforgeable lookup/announce capabilities for that one command. Its focused coverage is in `test/private/dht-command-policy.js`.
- `lib/private/opaque-destination.js` owns address-free, branch-bound destination capabilities for one adapter instance. Its focused coverage is in `test/private/routed-dht-io.js`.
- `lib/private/routed-dht-io.js` implements the internal nine-method DHT-RPC request-transport contract against a trusted in-process authority. It supports only the reviewed immutable-get request body and normalizes a trusted logical response; it is not a live or remote authority interface. Its focused coverage is in `test/private/routed-dht-io.js`.

`test/private/fake-route-authority.js` and `test/private/routed-dht-traversal.js` are also newly authored, test-only conformance scaffolding. They exercise deterministic five-node lookup and announce traversal through base DHT-RPC without hosts, ports, sockets, UDX, or network traffic. They do not model a live three-position route and are not an anonymity test.

## Gate 3A-only and deferred scope

The Gate 3A fake authority and traversal modules remain deterministic
conformance scaffolding and are not authorized as substitutes for the
package-private Gate 3B1 live owners. Gate 3B1 and the later C/D/put slices
include M3 context derivation, authenticated adjacent links, tail/final-exit
state, guard pinning, separate lookup/announce routes, quotas, branch rotation,
teardown, immutable/mutable get and put, required SURB replies, blinded presence,
provenance-qualified DHT-exit destinations, generation invalidation, and native
DHT-exit socket ownership.

The remaining deferred scope is explicit:

- traffic-analysis defences: padding to a constant rate, batching, and cover
  traffic, tracked as
  [KI-1](#ki-1-routes-are-correlatable-by-timing-and-volume);
- peer streams, a separately reviewed wire design;
- KI-4's remote confirmation on real links, and independent remote lifecycle
  evidence under owner-approved dispatch;
- external cryptographic review and public required-mode approval;
- root public required-mode integration, Hyperswarm, mobile, and PearTube
  integration.

The Task 15 controller remains package-private. It carries no anonymity claim
beyond the properties tabulated in
[Task 17 wire-level privacy evidence](#gate-3b1-task-17-wire-level-privacy-evidence),
which hold only under the v1 active-relay adversary.

## Gate 3B entry criteria

Gate 3B is an aggregate delivery gate, not a requirement that one implementation
plan change every private-routing subsystem at once. It may be completed through
numbered, separately designed and reviewed vertical sub-gates such as Gate 3B1,
3B2, and later slices. Each sub-gate must state exactly which criteria it
advances, keep incomplete criteria fail-closed and non-public, and preserve the
experimental/no-anonymity boundary. No sub-gate may expose public required mode
or claim Delivery Gate 3 complete until all ten aggregate criteria below pass
together in fork-native CI.

The complete Gate 3B series must implement and verify all of the following:

1. Signed relay advertisements and numeric-only bounded bootstrap.
2. Stable guard pinning and separate lookup/announce middle/exit branches.
3. Adjacent authenticated links, three-position live routes, quotas, rotation, and teardown.
4. Exact reviewed request and reply body codecs, encoded-byte amplification accounting, and adversarial vectors for private presence, mutable/immutable get/put, and exit referrals.
5. Exact v1 role/branch/circuit/generation transcript constructors and the deferred M3 derivation vectors.
6. Provenance-qualified DHT exit destination tables and live allowlisted UDP operations.
7. Trusted route-generation expiry and rotation invalidation for every issued destination capability.
8. A public required-mode controller only after direct authority is removed at readiness.
9. Multi-process Node/Bare integration.
10. Privileged Linux namespace capture plus a semantic leak oracle proving endpoint-to-guard-only traffic after readiness.

Delivery Gate 3 remains open until every one of these ten items passes fork-native CI. Gate 3A completion alone does not authorize a public private-routing mode or an anonymity claim.

[Gate 3B1](superpowers/specs/2026-07-18-private-routing-gate-3b1-live-immutable-get-design.md)
was the first live vertical slice: signed relay advertisements, bounded numeric
bootstrap, guard pinning, separate lookup/announce branches, authenticated
adjacent links, endpoint-to-exit authentication, immutable-get codecs,
provenance-qualified destinations, generation invalidation, Node/Bare process
integration, and packet/semantic leak oracles. Its original announce branch
carried no mutation. Subsequent slices added immutable/mutable get and put,
experimental required SURB replies, and Gate D blinded presence including
publication and revocation. Public required mode, peer streams, Hyperswarm,
and mobile-device integration remain gated; see
[Current implementation](#current-implementation).

## Package-private v2 adjacency integration checkpoint

The v2 neighbor pool now consumes explicit caller-authorized link handles and
owns separate finite service and close ledgers. Both endpoints can complete
native A1/A2 adjacency setup without an unaccounted peer-side session.
Authenticated adjacent payloads and immediate DATAGRAM teardown use their
respective ordinary and teardown partitions. The current integration checks
cover fixed parent deadlines, timer rearming, accept waiter cancellation,
one-shot binding cleanup, and authenticated truncated closure rejection.

CREATE and CREATED both enforce their owned operation deadline at native
dispatch; a failed send cannot publish establishment. Responder adjacency
lifetimes use the admitted expiry and parent bounds, not the short OFFER
attempt deadline. Shared-neighbor verification keeps a second branch usable
after the first branch's ACK cache expires. Authenticated DESTROY retries stop
at eight, and duplicate TEARDOWN requests share the original ten-ACK allowance.

Initiator and responder ledger inputs are finite ordinary and physical-closure
parent budgets. Admission reserves four branch-owned children before OFFER or
ACCEPT publication; exact OFFER replay reuses its original reply ledger.
The negotiated directional totals include physical closure, as in the v2 specification's
§8.3 algebra: the ordinary child excludes ten cells,12,000 bytes, and one
command, while its disjoint physical-closure child owns exactly those amounts.
Failed admission rolls back partial reservations. Ownership moves with the
authenticated native binding, and destruction releases only unspent capacity;
already charged work is never refunded. Ordinary CONTROL reception charges the
ordinary receive child, not the physical-closure child.

Reverse limits fit the authenticated responder advertisement. Forward limits
fit the initiator's reservation and parent expiry at index zero, or its own
current-tail advertisement at indices one and two. Index-zero candidate
consumption now matches the live reservation's identity, endpoint, epoch,
advertisement, grant digest, run ID, operations and clock before consumption.
Its original candidate deadline narrows the Native exchange, retries and
issuer handoff; original wire expiry also bounds the signed OFFER.
Independent review of that repair remains incomplete. The responder checks forward
geometry, its receive reservation and parent expiry, not its advertisement's
reverse-send maxima. Signed concurrency is reserved before callbacks and
released with native branch ownership, not response-cache expiry.

Setup receive ownership survives native issuer-to-runtime transfer. Actual
arrivals spend cells and bytes; authenticated retransmissions do not allocate
another command. Invalid ACCEPT/proof signatures do not consume the eight
authenticated-attempt allowance or authorize branch destruction. A signed
conflict or ninth authenticated arrival closes only its original logical
branch using DESTROY, rather than falsely reporting physical carrier loss.
Changed signed OFFERs cannot allocate another owner for an existing logical
tuple. Cache pressure cannot evict a live branch; reclamation requires both
the original setup deadline and release of native branch ownership.

The first exact late setup arrival is accounted before setup authority is
retired. This does not shorten an established branch's negotiated lifetime.
Real Darwin `udx-native` A1/A2 probes cover signed OFFER/ACCEPT/proof conflicts,
ninth arrivals, invalid signatures, late duplicates and sibling payloads.
An isolated probe lowering only the cache capacity to two additionally checks
live-row preservation, refusal of a third admission and expired-row reuse.
Before the A0 correction, the affected Node24 suite passed372 tests and6835
assertions. After that correction, the focused guard/peer carrier/runtime run
passes45 tests and328 assertions. Cross-grant and delayed-ACCEPT regressions
fail under deliberate removed-binding and rebased-deadline mutations.
A real Darwin `udx-native` A0 also exchanges1,100-byte payloads both ways
after its consumed candidate's setup deadline and completes acknowledged teardown.
Ordinary correctness findings now have different-model Opus/Fable review and
Main's adjudication. Security review remains blocked by the provider's lack of
prepaid credit. These checks are not full route, cryptographic or privacy acceptance.
Final integrated verification on the unmodified source, including the A0
correction, passes375 tests and6849 assertions. The temporary A0 mutation
preload was removed after its negative checks; no review gate is waived.

Delayed advisory reconciliation adds a real Native A0 quota regression:
forward authority is independent of the source advertisement, reverse limits
fit the guard advertisement, parent expiry is enforced, partial reservation
failure publishes no OFFER, and exhaustion/release cannot spend a sibling's
partition. The latest affected Node24 run passes376 tests and6864 assertions.
The corrected shared-responder mutation disables root ownership release as
well as child reservation; the sibling-spend assertion itself still fails.

Real A1/A2 probes additionally use an actual signed concurrency limit of two.
A changed signed OFFER against an adopted runtime, or its ninth authenticated
OFFER, retires both original halves, releases all four child reservations,
and frees an admission slot for another genuine branch. The existing sibling
and replacement both exchange1,100-byte payloads in each direction.
Neither setup deadlines nor ten-cell closure partitions were enlarged.
The forwarding cache test retains its full original5,000ms horizon, including
the1,000ms spent awaiting downstream drain. Bootstrap callers already reject
fulfilled-but-false Native sends before establishing either endpoint.
These are proof improvements, not independent-review or release approval.

The twelve-request closure regression retains all twelve fresh-authenticated
arrivals: the first ten retain the original ACK cache, excess closure traffic
fails its own branch without additional ACK allowance, and a genuine sibling
retains its own teardown capacity. The raw sender releases received ACK packet
ownership rather than accidentally filling the native receive queue.

Endpoint-wide shutdown initiates native socket close before awaiting outstanding
send completions; packet ownership is retained until those completions settle.
This is not per-branch cancellation. `udx-native` 1.20.7 exposes no per-send
cancellation API, and closing a shared socket for one branch is not permitted.
Its `trySend` path also retains packet storage and is not a replacement.

This checkpoint does not complete v2 tail extension, purpose finalization,
stream admission, private registration/rendezvous, legacy egress/controller
integration, or Linux privacy acceptance. External human cryptographic review
and public required-mode approval remain separate gates.

### 2026-09-11 owner lifetime and admission correction

Responder construction now requires a synchronous adoption callback. Acceptance
requires the exact newly established link's live runtime, then rechecks responder
and binding destruction before row publication. Callback failure reaches the
existing Native setup-failure owner; it cannot leave an untaken silent admission.
The signed concurrency cap is shared by every responder instance for one relay
owner. Releasing one responder does not reset still-owned Native admissions.

The Native cap regression uses two responder instances and three independently
authenticated physical bindings. Its third open times out while two slots are
occupied; that local timeout is not an authenticated rejection reason. No third
runtime is created and the source reservation is released. Following the original
five-second ACK-cache retirement, the same third binding admits a fresh branch,
with bidirectional traffic on both it and the surviving sibling.

The direct responder regression retains ninth/changed OFFER accounting,
cross-binding tombstones, late-arrival accounting, and allocation-command
non-refund. It now adopts real runtimes and explicitly observes branch-local
revocation. Binding-only destruction is covered separately. Real host-native
callback regressions cover unrelated-runtime returns, responder destruction,
and throws after adoption; each checks callback execution, failed-owner release,
and surviving sibling traffic.

Guard leases detach taken physical reservations and remove issuers through the
existing Native release hook. Three real Darwin A0 open/data/teardown cycles
return both retained counts to zero. This does not establish the unresolved
lifetime completion-allocation or native per-send cancellation contracts.

`narrowPeerReservations` atomically shrinks existing pending ledger/storage
reservations without rebasing spent work or returning descendant-owned quota.
Taken storage cannot shrink. The complete caller-owned descriptor snapshot
normalizes revoked-Proxy failures before live quota validation or mutation.
This primitive is not completed purpose finalization.

After formatting, the affected Node24 suite passes383/383 tests and6967/6967
assertions, exit0 in14.17seconds (`artifact://697`). Counterfactuals fail for
per-instance caps, unrelated-runtime acceptance, omitted destruction checks,
retained guard reservations/issuers, ordinary array-length access, and unnormalized
revoked-Proxy errors. A first destruction mutant removing only one of two checks
correctly survived; removing both exposes a live failed owner. The first guard
reservation mutant had an ambiguous anchor and did not execute the scenario;
its corrected transfer-specific mutant fails at the retained reservation count.

Verified probe sources are archived under `local://hyperdht-advisory-proofs/`:
admission preload SHA256 `f89e49c31a738d4814cae8ba27cd5590de95e684cfef5c9da9d1a4c1883fa288`;
guard churn SHA256 `932e377c79af4c522276aa4c8340cfb9f47429970022ebf720f593d03f594f93`.
Restore their original `.tmp-peer-admission-mutant.cjs` and
`.tmp-peer-guard-churn.cjs` filenames into the checkout to rerun relative imports.
No commit, public activation, full-v2, Linux privacy, or cryptographic acceptance
is implied. Tail discovery metadata, canonical advertisement transfer, and atomic
drained handoff remain the next integration work.

### 2026-09-11 tail metadata and discovery deadline integration

`readPeerActiveCandidateFacts` publishes copied, non-consuming authenticated
candidate facts only while the original owned wire/local deadlines remain live.
Authenticated establishment now retains advertisement260 and moves it with the
tail secret and T290 into both source/guard tail owners; final-exit material
still has exactly twelve fields. The focused adjacency/bootstrap/guard suite
passes53/53 tests and376/376 assertions. A genuine Darwin Native A0 smoke proves
the advertisement/transcript move, survival after runtime closure, and rejection
of consumed, reentrantly destroyed, and wire-expired candidate fact reads.
The smoke source is archived at
`local://hyperdht-advisory-proofs/.tmp-peer-tail-metadata.cjs`, SHA256
`d1e0cb3bb8fafc6d6abcb917b1e2a5161dc6a1e182785ea46bfc17a7c78d9274`,
and removed from the checkout.

`createPeerCandidateLocator(owner, advertisement, deadlineBounds)` accepts an
optional exact own-data snapshot `{ clockIdentity, wireExpiresAt, localDeadline }`.
Bounds only narrow the advertisement wire expiry, its original clock-matched
local projection, and the projection of the narrowed wire expiry. Accessors,
clock mismatches, expired bounds, and reentrant owner revocation reject.
The existing Native direct transport copies both bounded facts unchanged.
The focused locator suite passes6/6 tests and102/102 assertions after formatting;
Fable independently reviewed this reported blocker with no remaining bounded gap.

Transport copying alone did not finish candidate publication: the ACTIVE
challenge previously omitted the transport wire cap. Its authenticated expiry
now freezes the minimum of transport, cookie and advertisement expiries, and
the existing local projection uses that same frozen value. A regression checks
both published deadlines and the expiry in the authenticated ACTIVE response;
the focused direct bootstrap suite passes15/15 tests and72/72 assertions.
This further reported flag has been sent to Fable. Full affected-suite proof
after these changes remains pending; the earlier383/6967 result is a baseline,
not verification of this new integration.

Independent Gemini/high workers own Native neighbor discovery and v2 tail
control; Main owns the closed activation dispatch and atomic drained carrier
transfer. Existing carrier phase promotion from an incoming outer class and
timer lifetime gaps were independently flagged by Fable and remain integration
work, not accepted behavior. No public activation, full-v2, Linux privacy,
security funding waiver, or cryptographic acceptance is implied.

### 2026-09-11 tail correction and Native discovery transaction checkpoint

Fable subsequently accepted the bounded signed-ACTIVE expiry correction.
The initial tail worker completion was rejected: independent Opus review found
an out-of-scope proof variable, unbounded readiness wait, incomplete initiator
proof, discovery/lifecycle leaks, asymmetric-expiry rejection, signer mismatch,
notification ownership gaps, and missing retained-storage reservations.
The recovered earlier flow test used fake authority and was not counted as
Native evidence. A new four-node Native fixture and genuine activation claims
are present but have not yet been run.

The tail correction moved from rate-limited Fable to explicitly pinned
Opus5/max, owning only `peer-tail-control.js`. Main added the runtime-side
synchronous final-carrier authorization scope and closed v1/v2 tail-brand
dispatch for generic final activation. These edits remain unverified.

Main rewrote Native discovery as a single 24-cell/28,800-byte transaction,
captured the authenticated advertisement handle at provisioning, preserved the
original projected wire deadline, normalized request snapshots before
reservation, and added requester-destruction notification to settle pending
discovery. New regressions exercise real Native cancellation and reuse,
pool destruction, projected expiry, and clock-callback rollback; no passing
result is claimed before the writer barrier.

A further specification check found that local class6 readiness must coexist
with class5 OFFER/ACCEPT retries during sentinel confirmation. That correction,
including carrier-owned deadline/timer cleanup, was handed to a separate
Opus5/max writer. Another fresh Opus review examines the corrected discovery
transaction read-only. Main retains acceptance and final runtime verification.
The earlier383/6967 affected-suite result remains baseline only. All existing
external and Native dependency blockers remain; no commit or public activation.

Native discovery verification now passes52/52 tests and369/369 assertions
(`artifact://716`, first command). It includes actual Native in-flight close,
same-source requester reuse over the preserved shared socket, timer-count
retirement, pool destruction, original wire projection, descriptor rejection,
and post-reservation clock failure/reentrant pool destruction rollback.
The rollback fixture initially allocated only24 service cells even though
provisioning spends that same ledger; it now allows40, enough for one discovery
but never two, so a leaked first24-cell reservation prevents replacement.
The independent discovery reviewer accepted the corrected transaction and
withdrew its initial speculative findings. Production pool reservations are
mandatory inputs; the helper's20-cell fixture default is not a production default.

The second command in artifact716 failed immediately in tail destruction:
`clearTailKeys` existed but was not exported by `peer-crypto.js`. Main exported
that existing helper. Subsequent Native-tail execution exposed fixture-only
role/epoch mismatches: safety and guard advertisements were verified as terminal,
and the four-node advertisement/grant epoch differed from the pinned A0 epoch7.
Those bindings now match; session setup derives its default epoch from its
actual link handle. The descriptor privacy test no longer asserts an unrelated
initial phase. Tail integration remains unaccepted and under direct Native
diagnosis; these corrections are not a passing tail result.

The finite direct Native smoke now completes A0, authenticated DIRECTORY D1,
A1 TAIL_READY, authenticated SUPPLIED D2, and A2 FINAL_EXIT_READY in0.34s.
It uses real Native endpoints and opaque authorities throughout. This is tail
construction proof only; final activation and encrypted carrier testing follow.
The four-node fixture was also missing safety/terminal direct responders, and
its guard/safety parent budgets reserved only one adjacency while each owns two.
Registered the actual responders and allocated exactly two branch budgets at
those intermediate nodes.

Source fixes replace an undefined candidate timer variable with the stored
record deadline and separate short-lived candidate admission from admitted
branch lifetime. Different-model Opus review accepted those changes, while
flagging timer reentrancy and a direction-specific bound refinement. Main also
corrected successor local lifetime to project signed READY under the retained
parent deadline rather than inheriting the spent discovery admission deadline.

The previous tail publication waited for all eight EXTENDED attempts, consuming
most of readiness's two-second window, and left an old receive waiter attached.
The actual second-discovery probe then lost its first request and the safety
runtime expired before the retry. Publication now follows the first dispatched
EXTENDED, pauses the old consumer during installation, and retains bounded
byte-frozen retries through a genuine moved-predecessor forwarding capability.
Native forwarding requires no old consumer waiters and erases consumed payloads
after synchronous sealing. The two-extension smoke passes with that cutover;
replay, timer, final-carrier and full-suite verification remain pending.

Independent fixture review accepted the authentication/epoch/budget corrections
but flagged borrowed-owner destruction, unawaited source socket closure, late
teardown registration, and unreleased tail owners. Those findings remain open.

### 2026-09-11 genuine final-carrier and lost-reply checkpoint

The tail suite now passes 13/13 tests and 108/108 assertions on Node24. Genuine
Darwin Native A0/D1/A1/D2/A2 carriage reaches both registered final activation
owners, moves each final carrier once, retains identical authenticated T290, and
transports ciphertext authenticated with the opposite end's finalize keys in
both directions. The exact final material remains twelve fields. This proves
tail construction and final carriage, not purpose negotiation or peer streams.

An authenticated fake-adapter loss regression drops the first EXTENDED datagram,
observes the old tail already in FORWARDING, recovers its byte-frozen response
from the original retry allowance, and completes the second extension through
that same forwarder. The clock continues driving readiness retries; no deadline
or attempt allowance is enlarged. The earlier focused tail/guard-lease/neighbor
run passed 61/61 tests and 435/435 assertions. The 383/6967 full-suite result
remains a baseline, not verification of this integration.

Fixture cleanup now registers ownership before asynchronous setup, rolls back
partial failure, preserves borrowed signer overrides, destroys tail owners, and
awaits both source and responder socket closure. A real Native smoke verifies
late descriptor failure, port reuse, borrowed signer survival, and zero retained
bytes in all four tail pools. Two timers initially flagged after close belong
to the mandatory bounded Native DESTROY train; eight 500ms clock advances retire
them. Immediate cancellation would suppress a protocol obligation and was not
implemented.

Fresh different-model Opus review accepts the moved receive pump, authenticated
cached reply, bounded helper and payload erasure. It also found a missing
monotonic deadline check before forwarding publication and an upstream-loss
cause that incorrectly suppressed DESTROY on the surviving successor. Main
applied both corrections; targeted fault proofs remain pending. Timer/final-take
review and class-aware purpose integration continue. No full-v2, security,
Linux privacy, external-human or public-release acceptance is implied.

### 2026-09-11 bounded tail ownership and early-finalization checkpoint

The post-format expanded Node24 suite passes 504/504 tests and 7974/7974
assertions, exit0 in14.87seconds (artifact775). It includes all peer tests,
bootstrap/guard ownership tests, and the affected v1 M3, final-exit and tail
regressions. This supersedes the383/6967 baseline for this integrated source;
it is not full-v2 or Linux privacy acceptance.

Genuine Darwin Native carriage now proves that early class5 frames survive
terminal carrier transfer in arrival order. The original blanket shared-queue
check returned ERR_BUSY and permanently stranded an already-arrived frame.
Both transfer checks now use the same bounded queue predicate. A live receive
waiter and pre-transfer class6 still refuse the move. Forged authorization
neither consumes nor erases queued tail traffic. Only after the genuine final
authorization succeeds does callback-free in-place compaction erase obsolete
class1 payloads and retain class5 payload objects without copying. The receive
path shares the same DATAGRAM/1101-byte classifier. No queue capacity, attempt
allowance, material field, clock bound or activation authority was enlarged.

The generic v2 carrier bridge now exposes explicit local activation,
class-preserving receive, explicit class5 retry sending and the original frozen
clock tuple. Both receive APIs consume the same one-shot reservation. Native
checks cover incoming class6 not promoting the reverse sender, class5 retries
after local class6 activation, and expiry retiring pending receive/timer work.
Class6 test keys are separate deterministic test-only domains; these checks
do not implement or prove OFFER/ACCEPT or sentinel negotiation.

Authenticated late READY now rejects at the original operation deadline even
when timer callbacks have not fired. A genuine Native reentrant source clock
previously resurrected completion and retained678 caller bytes; the repair
returns ERR_DESTROYED and retains0. Tentative readiness train/envelope ownership
also releases on clock-triggered destruction. Synchronous250ms/2000ms timer
callbacks cannot reinstall retired handles.

The pre-forward-publication deadline probe keeps the guard in TAIL_READY after
late Native-send settlement; removing only that guard publishes FORWARDING.
Actual Native upstream physical loss now sends the surviving successor's
authenticated closure, spends its closure partition and emits no false
physical-loss notification for that still-live leg. Different-model Opus
reviews accepted these repairs and the final-carrier classification design;
Main retains the verdict.

Verified throwaway sources were archived verbatim under
`local://hyperdht-advisory-proofs/` and removed from the checkout:

- `.tmp-peer-tail-probe.cjs`: SHA256 `04765d6e77cdc049e8aa4682bc7cbe9a54f91894f91ecbc5c0f4295d54383564`.
- `.tmp-peer-fixture-cleanup.cjs`: SHA256 `305debbbafc2c218ef42502907abeb50f289b2d5367745d60d2d1726aa161e87`.
- `.tmp-peer-ready-clock.cjs`: SHA256 `d4d6d553a7561aaff8981e540ea752a76086831821228af8f52fb839b15577ec`.
- `.tmp-peer-publication-clock.cjs`: SHA256 `f14358e21c1e5d2127475139d855f5cc9bbe232ba9b6a2f84907a3ead1e252ff`.

JD requested a workaround for cyber risk flags. Catalog checks found only the
two permitted CyberKimi/CyberGLM routes on their previously unfunded shared
Adverserial backend and neither model on the alternate OrcaRouter catalog.
Ordinary correctness review and local Native regression evidence keep
implementation moving; neither substitutes for the blocked security review.
No task was disguised to evade risk controls, no model funding status was
reclassified as approval, and no authentication or release gate was disabled.
Purpose finalization, streams, semantic services, controller integration,
native cancellation/lifetime bounds and external approval remain open.

### 2026-09-11 frozen external security-review handoff

A held actual-Native receive exposed a second carrier boundary: class1 arriving
after the synchronous drain consumed a carrier reader with INVALID_ROUTE.
The candidate now installs a write-once post-authorization admission mode and
erases only valid late class1 after inbound accounting and closure interception.
The held packet now resumes with a carrier reader pending without consuming
that reader.

The independent producer review then exposed premature TAIL_READY2 cancellation
on terminal take. A new Native regression immediately takes the terminal
carrier, closes its old tail owner, and loses the first READY2 upstream.
Before the repair it reports source ERR_PRIVACY_UNAVAILABLE and prematurely
available duty storage. The candidate transfers the existing train, sealed
envelope, remaining attempts, original deadline and reservation to Native.
Ancestor session storage stays reserved if its old owner closes before the duty
ends. This regression now completes source verification and reclaims the
terminal tail storage after duty/material release.

Current focused verification passes39/39 tests and321/321 assertions, exit0
in1.82seconds (artifact783). The expanded affected suite passes505/505 tests
and7982/7982 assertions, exit0 in14.83seconds (artifact789). The latest duty
transfer has not received a final independent security verdict, and its final
edits have not been formatter-verified.

At JD's request, source is frozen for an external security agent:

- `review-bundles/hyperdht-private-peer-v2-security-review.zip`:1792138bytes;
  SHA256 `efd01631e600f78db1269317a38f39fceb5637a283e6c726ed4e16ee30896ab3`.
- `review-bundles/REVIEW_PROMPT.md`: standalone task, also included in the ZIP.
  -303 source/test/build/specification files;311 total archive members including
  the prompt, manifest, dependency metadata and captured verification evidence.
- ZIP CRC, every payload SHA256, manifest counts, safe relative member paths,
  and equality of standalone/bundled prompts verified.
- No `.git`, installed binaries, environment credentials, generated credential
  artifacts, vault pages or agent conversations included. Synthetic test
  fixtures remain. The bundle's migration document is a pre-handoff historical
  snapshot; the bundled prompt and verification metadata describe its code.

The handoff requests concrete findings, a minimal unified diff and exact
verification evidence. Dedicated setup-security review, Native cancellation
and completion-state bounds, full-v2 integration, Linux privacy and external
human/public approval remain open. No commit, push or public activation.

### 2026-09-11 authorized review-branch publication

JD explicitly requested committing and pushing the current work to a branch.
Publication targets `origin/implement-private-peer-v2`, not a merge to main or
public-required-mode activation. All pending implementation, tests, package
changes, specifications and review deliverables are included. Four local
`.omo/run-continuation/` session records are excluded from publication.

The pre-commit affected Node24 suite passes505/505 tests and7982/7982 assertions
(exit0,15.05seconds), covering `peer-*.js`, link bootstrap, UDX endpoint, guard
lease/link/reconnect, endpoint/bootstrap authority, M3, final-exit and tail
control. This is not a full npm/Bare/Linux/privacy acceptance claim. Source is
preserved as the reviewed candidate rather than silently formatted or repaired.

The review ZIP remains byte-identical at SHA256
`efd01631e600f78db1269317a38f39fceb5637a283e6c726ed4e16ee30896ab3`.
The separately published `activation-material-probe.cjs` and
`activation-material-finding.txt` document commit accepting changed parent
deadline, owner or clock metadata under controlled internal fault injection.
That expected-rejection probe fails; normal caller/remote exploitability is
not established. This publication does not fix or waive that finding.

The earlier blanket work pause was incorrect: a frozen ZIP does not block
independent checkout work. Independent tasks are reopened; only the actual
external neighbor/tail and setup review, native cancellation/completion bounds,
historical punch diagnosis and human/public approval dependencies remain
blocked. No external security or full-v2 verdict is asserted by this commit.

### 2026-09-11 discovery retirement and runtime clock continuation

Independent checkout work continued after WIP publication `b3b3a9e`; the
external review ZIP and standalone prompt were not edited.

- `awaitControlObject` now normalizes a thrown owned monotonic clock to
  `ERR_PRIVACY_UNAVAILABLE`. A genuine Native discovery fault probe previously
  exposed the injected raw error; after the fix it rejects with the public
  privacy error and retires the source tail.
- Authenticated discovery completion is sampled before response publication:
  the Native probe advances wall time from1000 to1100 after reading genuine
  candidate facts and observes `verifiedAt=1100`. Moving the sample before
  completion produces1000 and fails the same assertion.
- A permanent Native regression expires a retained candidate, rediscovers on
  the same source tail, rejects the old handle, and admits a branch whose45000
  wire expiry survives its1200 candidate admission expiry. Removing candidate
  retirement fails rediscovery; substituting candidate expiry for advertisement
  expiry fails the isolated regression at extension admission.
- A separate held-result probe retires the responder before delivering its
  genuine authenticated candidate. The late candidate loses authority, the
  guard's retained-tail pool returns to zero, the source rejects `ERR_DESTROYED`,
  and a fresh discovery succeeds on the same still-live Native neighbor pool.
  Removing the late-candidate destroy call fails the authority assertion.
  Reuse is checked before advancing the clock to expire the source operation,
  not after also expiring the provisioned neighbor.
- `checkRuntimeTime` now rechecks `state.cleared` after invoking the owned clock.
  A permanent genuine Native test destroys that same runtime from its clock
  callback. Before the fix, diagnostics returned after destruction; afterward,
  the current operation throws `ERR_DESTROYED`. This is callback reentrancy
  proof, not an ordinary remote exploitability claim.

After formatting only the three changed JavaScript files, the affected Node24
suite passes507/507 tests and7988/7988 assertions, exit0 in14.66seconds
(`artifact://828`). This includes the two new regressions, existing two-extension
Native flow, synchronous250/2000ms scheduler rejection, delayed authenticated
READY rejection, and terminal residual READY2 ownership. It does not establish
full npm/Bare/Linux/privacy acceptance or external security approval.

Throwaway probe sources remain outside the checkout in session-local evidence:

- `peer-discovery-clock-probe.cjs`:
  `d8f43cf0e03f24ea195f62e4ac62f05d14fd89d75ee001ede5be7b65a64b2643`.
- `peer-discovery-mutant.cjs`:
  `965688d0c37c05f3897110e530d51c1d00f65db824b7e0b510ca24cc80a44616`.
- `peer-discovery-late-probe.cjs`:
  `6f160a8b9a95e668e1de5bdfb768260a4177866698c9d52dbcccee2be5db9004`.

These are in-memory fault injections with genuine authority, not alternate
production implementations. The activation metadata finding and external
approval gates remain open. This continuation is not yet committed or pushed.

### 2026-09-11 supplied V12 report intake

JD supplied an886479-byte V12 export against `b3b3a9e`, SHA256
`781e4aad0b670bfc121cddd1e2937e8328d4c6fa4a346e2f955bfd1e8e3f4b95`.
All62 unique finding IDs are indexed and separately tracked:19 Medium,
35 Low and8 Informational;28 are labelled Invalid and34 Unreviewed by V12.
The34 Unreviewed entries each contain a PoC;31 entries contain proposed patches.
Those labels and supplied outputs are report claims, not local acceptance.

The findings cite core HyperDHT, server, CLI and testnet code. Only274673 cites
`lib/private/`, specifically `surb.js`; its consumption check still uses strict
`now > state.expiresAtMs` in the current checkout. This source observation is
not a fresh execution of the supplied proof.

None of the findings names the requested peer-tail, peer adjacency runtime,
native-neighbor, direct-bootstrap or final-activation review targets. The report
therefore does not provide the scoped ownership/authentication evidence requested
by the frozen prompt. Absence of a finding is not evidence that a module was
audited or found secure. The external v2 review gate remains open.

Intake priority is fixed-width target disclosure274926, handshake resource
admission274909, UDP address validation274915, SURB expiry274673, and the
overlapping lifecycle/socket-cleanup groups. No uploaded setup script, PoC or
patch was executed or applied during intake. Complete machine-readable inventory
and scope disposition are retained as session-local
`v12-security-scan-index.json` and `v12-security-scan-intake.json`.

### V12 intake correction and continuation publication

The earlier count of34 supplied PoCs counted section headings, not executable
test bodies. The export contains31 embedded test cases. Findings274915,
274919 and274921 have PoC headings without test bodies;274915 explicitly says
its PoC could not be executed. Supplied validation output is not local proof.
Three reviewed reproductions were prepared outside the checkout but have not
been run. No V12 remediation patch has been applied.

JD requested committing and pushing the current continuation. Publication
includes the two clock-boundary fixes, two Native regressions and this record;
local `.omo` state and session-local report/probe files remain excluded.
The affected implementation was verified after formatting:507/507 tests,
7988/7988 assertions. The frozen review ZIP and prompt remain unchanged.

### 2026-09-11 Astra routing continuation — review gate unavailable

Two GPT-6-Astra dispatches were attempted for the architecture and integration packets. Both stopped at the provider credit gate before producing output. No Astra review text is preserved, so no ownership conclusion is attributed to those runs. Relay source and tests remain byte-identical; no RelayService edit was retained.

The retained local package-private crypto slice is `lib/private/peer-crypto.js`: strict X25519 shared-secret validation through `cryptoSuite.keyAgreement`, exact OFFER-body preTranscript and purposeTranscript framing, separate pre-MAC and route KDF domains, MAC16 computation and constant-time verification, purpose/offer/accept/confirmation/final transcript digests, and explicit key erasure. `test/private/peer-crypto.js` covers deterministic vectors, agreement symmetry, false/low-order rejection, forgery rejection, mutation binding, and erasure.

This is not stateful purpose finalization, peer streams, semantic services, controller integration, Native cancellation/lifetime completion, Linux privacy evidence, external human cryptographic review, security approval, or public activation. The missing approved production peer endpoint owner remains the next runtime blocker.

Verification correction: the purpose-MAC regression explicitly covers the 64-byte `PEER_ROUTE_REJECT_V2` header body; reliable ACK sentinels have no object MAC suffix. The focused Node result is 11/11 tests and 138/138 assertions; the focused Bare result is also 11/11 and 138/138. The private aggregate now imports the suite and passes 1,147/1,147 tests and 20,223/20,223 assertions.

### 2026-09-11 package-private purpose owner and peer transport slice

The local implementation now has a package-private `lib/private/peer-purpose-owner.js`
with source and terminal state machines for OFFER, ACCEPT or REJECT, authenticated
replay handling, two reliable sentinel trains, bounded retry, projected deadlines,
resource rollback/transfer, pre-shared-secret erasure, and active-route expiry.
The owner keeps the route inaccessible until the terminal class-6 sentinel send has
been accepted. Scheduler faults and uncertain native send results destroy or retry
the owner instead of being treated as normal exhaustion.

Active owners with explicit stream callbacks now bind `PeerReliableLanes` only after
sentinel activation. The transport facade keeps DATA and CONTROL ARQ separate,
continues the receive pump after activation, rejects snapshot-zero ACKs outside the
sentinel path, and requires strict boolean admission decisions. Physical send
attempts charge one directional cell and 1,200 bytes when route resources exist;
receive paths do not charge remote traffic, and terminal ACCEPT allocation charges
the one accepted command.

Focused owner verification passes 10/10 tests and 71/71 assertions. Focused crypto
verification remains 11/11 and 138/138; reliable lanes remain 35/35 and 674/674.
The private aggregate then passed 1,157/1,157 tests and 20,294/20,294 assertions.
The package-private owner has no public export. Semantic services, endpoint/controller
integration, Native cancellation/lifetime bounds, Linux privacy evidence, external
human review, and public activation remain blocked. Astra architecture and
integration dispatches stopped at HTTP 402 before producing review text.

### 2026-09-12 purpose owner correction and cross-runtime evidence

The package-private owner correction slice now requires carrier fulfillment to
resolve to the exact boolean `true`; synchronous or asynchronous false results
retry or destroy without publishing ACTIVE. Physical route accounting occurs
only after synchronous sealing succeeds and immediately before the carrier
attempt. Construction failure erases partial key material, removes the owner
registry entry, and releases reserved resources. Optional nonce inputs accept
only own data properties, so accessor execution cannot reach secret handling.
Negotiated expiry and limits now use the componentwise minimum and project the
same expiry through both source and terminal active deadlines.

The regression set covers dropped first OFFER, ACCEPT, and sentinel attempts,
asymmetric expiry and resource limits, authenticated REJECT parent-ledger
spending, exact carrier acceptance, bidirectional DATA/CONTROL stream
callbacks, and callback-snapshot immutability after activation. No new
physical carrier file was added; the route carrier remains the existing
M3-adjacency/guard-lease/UDX endpoint path.

Focused `peer-purpose-owner` verification passes 14/14 tests and 105/105
assertions on both Node and Bare. Focused crypto remains 11/11 and 138/138;
reliable lanes remain 35/35 and 674/674. The Node private aggregate passes
1,250/1,250 tests and 22,758/22,758 assertions. The corresponding Bare
focused peer suites pass: protocol 4/4 and 1,083/1,083, semantic wire 5/5
and 155/155, reliable lanes 35/35 and 674/674, M3 context 11/11 and 129/129,
ledger 12/12 and 215/215, adjacency runtime 22/22 and 174/174, purpose owner
14/14 and 105/105, and crypto 11/11 and 138/138. The full Bare aggregate
reaches existing native test 863, then its next live route setup fails with
`ROUTE_UNAVAILABLE` in `udx-cell-endpoint.js` and exits 134; this is not
evidence against the focused peer slice.

Relay source and tests remain byte-identical. The owner and stream code remain
package-private with no public activation path. Semantic services,
endpoint/controller ownership, Native cancellation/completion bounds, Linux
privacy evidence, external human cryptographic review, and public activation
remain blocked.

### 2026-09-12 staged-constructor transaction correction

A follow-up review found that the earlier constructor transaction began after
identity and staged secret copies. The owner now places identity copying,
final-key copying, callback snapshots, deadline projection, resource
reservation, and source preparation under one cleanup transaction. `identity`
and `finalKeys` also erase partial results when a later field fails. The
regression covers malformed circuit/query/final-key fields, a clock scheduler
fault, zeroed staged copies, and zero resource reservations.

Focused `peer-purpose-owner` verification now passes 15/15 tests and 125/125
assertions on both Node and Bare. The updated Node private aggregate passes
1,251/1,251 tests and 22,778/22,778 assertions (artifact 189). A fresh Bare
private aggregate passes 1,206/1,206 tests and 22,643/22,643 assertions
(artifact 191). This replaces the earlier pre-correction aggregate counts.
Relay files remain byte-identical; package-private ownership and the public
activation gates are unchanged.

### 2026-09-12 handshake staging transaction correction

The owner staging transaction now keeps source OFFER-body transfer, terminal
OFFER and REJECT wire copies, and ACCEPT derivation buffers inside guarded
cleanup paths. `prepareSource` erases its local body when transfer fails;
`handleAccept` erases staged body, wire, purpose, nonce, digest, and derived
keys on derivation failure; `handleOffer` and `cacheReject` do not retain
initial copies before their cleanup boundary. The regression forces a source
pre-shared-secret failure and observes every staged ACCEPT buffer zeroed, with
source reservations released.

Focused `peer-purpose-owner` verification passes 16/16 tests and 135/135
assertions on both Node and Bare. The current Node private aggregate passes
1,252/1,252 tests and 22,788/22,788 assertions; the current Bare private
aggregate passes 1,207/1,207 tests and 22,653/22,653 assertions. Relay files
remain byte-identical. The owner and stream slice remains package-private;
semantic services, endpoint/controller ownership, Native cancellation and
completion bounds, Linux privacy evidence, external human cryptographic
review, and public activation remain blocked.

### 2026-09-12 exact-carrier and staging-harness correction

The exact-`true` carrier regression now checks the terminal's
`TERMINAL_SENTINEL_PENDING` state and rejected `route()` before advancing the
retry clock; a later 250 ms advance permits activation. ACCEPT handling no
longer aliases `state.responseWire`; terminal ACCEPT sends use
`state.acceptWire` directly.
The raw-secret `TEST_ONLY_PEER_PURPOSE_OBSERVER` seam was removed; staging cleanup is tested
only through narrow test-harness sodium/allocation fault instrumentation for
the local ACCEPT body, ACCEPT wire copies, and purpose transcript. The
pre-shared erasure regression likewise uses harness-only allocation tracking.

Native `peer-m3-adjacency-runtime` is no longer registered by the portable
`test/private-routing.js` aggregate. It remains a dedicated platform suite:
Bare focused adjacency passes 22/22 tests and 174/174 assertions. Bare focused
peer verification passes crypto 11/11 and 138/138, protocol 4/4 and
1,083/1,083, semantic wire 5/5 and 155/155, reliable lanes 35/35 and 674/674,
M3 context 11/11 and 129/129, ledger 12/12 and 215/215, and purpose owner
16/16 and 142/142. The owner passes 16/16 and 142/142 on Node as well.

The current Node portable private aggregate passes 1,230/1,230 tests and
22,621/22,621 assertions. The preceding Bare run reached 843 tests, then
aborted at existing native live test 844 while binding a UDX route:
`ROUTE_UNAVAILABLE` from `udx-cell-endpoint.js` through
`test/private/native-adjacent-fixture.js`. That transient environment/native
live setup stop is superseded by the passing rerun below and was not a failure
in the focused peer suites. Relay files remain byte-identical. Semantic
services, endpoint/controller ownership, Native
cancellation/completion bounds, Linux privacy evidence, external human
cryptographic review, and public activation remain blocked.

### 2026-09-12 Bare portable aggregate rerun

A fresh Bare execution after the ACCEPT wire ownership correction passes
1,185/1,185 tests and 22,486/22,486 assertions. This supersedes the
immediately preceding environment stop at test 843 before native live test
844; this run completes without `ROUTE_UNAVAILABLE`. The Node portable
aggregate remains 1,230/1,230 tests and 22,621/22,621 assertions. Focused
owner and dedicated adjacency counts remain 16/16 and 142/142 on Bare and
22/22 and 174/174 respectively. Relay files remain byte-identical; semantic
services, endpoint/controller ownership, Native cancellation/completion
bounds, Linux privacy evidence, external human cryptographic review, and
public activation remain blocked.

### 2026-09-12 aggregate registration and decoder cleanup

The portable aggregate again registers `peer-m3-adjacency-runtime`. The owner
now clears `decoded.body` and `decoded.authSuffix` after finalize and route
dispatch, and the pre-shared erasure test tracks both returned agreement
buffers plus the terminal's retained state copy; it checks both direct
agreement outputs and the terminal owner-held copy after sentinel
authentication. The staging regression also checks decoded 260-byte bodies
for zeroization.

With adjacency registered, the Node private aggregate passes 1,252/1,252
tests and 22,800/22,800 assertions. Bare passes 1,207/1,207 tests and
22,665/22,665 assertions. Focused owner verification passes 16/16 tests and
147/147 assertions on both runtimes. Relay files remain byte-identical.
Semantic services, endpoint/controller ownership, Native
cancellation/completion bounds, Linux privacy evidence, external human
cryptographic review, and public activation remain blocked.

## 2026-09-13 peer alpha evidence and downstream cutover

The peer alpha code correctness boundary is source revision
`28f7e51b40cf2000d6a43beec62bfc785cfb3cca`. `writeAll()` retains a cell until
Streamx reports the transport drained, so a caller cannot erase a queued cell
before the transport owns it. Entry registration reserves the role before its
commit wait and excludes resolver admission during that interval. The private
server firewall now evaluates the authenticated end-to-end Noise identity and
never emits a refused connection to the application. The focused Node, Bare,
and Linux Node 24 public-API regressions pass 8/8 tests and 93/93 assertions.
Revision `78f32beec8dec2ec52fbefc7ef06f52e3cc32d60` isolates the firewall contract
on a fresh route. The earlier combined scenario could fail before reaching the
firewall, so it conflated route availability with policy behavior. The isolated
regression waits for the authenticated firewall callback and verifies exactly
one call plus zero emitted connections.

Build Status runs `34777014693` and `34777481870` exposed a second test-harness
race: the invalid-ciphertext regression waited for an application error without
installing a pending readable consumer, so Linux could deadlock before consuming
the record. The regression now installs `readOne()` and its matcherless
`t.exception()` before injection. It passes 18/18 tests and 104/104 assertions
on Node and Bare, plus 25/25 independent process runs and the complete
1,393-test suite in a fresh Linux arm64 Node 24 container.

The dormant native peer-tail activation now snapshots all twelve handoff
properties and revalidates their exact data-property identities, authoritative
clock/deadline/owner facts, and final-exit generation at both prepare and
commit. The prior fault-injection probe accepted substitutions of
`localDeadline`, `tailControl`, and `clockIdentity`; it now accepts the
unchanged control and rejects all three substitutions with `INVALID_ROUTE`.
The permanent Node and Bare regression passes 20/20 tests and 156/156
assertions.
The final Node private aggregate passes 1,302/1,302 tests and
23,206/23,206 assertions. The final Bare private aggregate passes
1,257/1,257 tests and 23,071/23,071 assertions. At capture revision
`32dded3498bec19ed03ac74287b03923f388b576`, fresh privileged Linux containers
on both the laptop (arm64, Colima) and Unraid (x86_64, Docker) pass the peer
packet-capture gate, each with 1/1 test and 23/23 assertions. Their live UDP
captures contain neither the application sentinel nor the stable destination
public key, `directDestinationSends` remains zero, and every observed relay
opens and reseals a different 1,200-byte cell.

Real-link run
[34770010983](https://github.com/ayooooo123/hyperdht/actions/runs/34770010983)
did not reach LINK_OFFER. The eleven remote hosts exposed only 48/140 directed
UDP pairs; role 1 never attached and the coordinator stopped after 609 seconds.
This is infrastructure evidence, not confirmation or refutation of the
responder-side offer fix.

The decentralized route-selection decision follows Veilid's published model:
the source selects its safety half, the destination selects its private half,
and neither selects the whole route. Selection uses signed node identities,
cryptographic random sampling, distinct identities and address-prefix
diversity; route failure demotes candidates. No central operator registry or
self-declared “operator” field is added. This is honestly named topology
diversity, not proof that two keys have different human operators.

The performance/privacy default also follows the low-latency Veilid tradeoff.
Private peer traffic keeps per-hop authenticated transformation, fixed
1,200-byte cells, separate source/destination route halves and bounded route
lifetimes. It does not add constant-rate cover or delay mixing, so it makes no
global-passive-observer timing-anonymity claim. Ordinary routing-table
maintenance and topic discovery stay direct; privacy-sensitive peer streams use
the private context. Generic routed `lookup`, `findPeer`, `announce`,
`unannounce`, and raw `query` remain outside the reviewed DHT wire. Blinded
immutable/mutable get/put plus private peer streams cover the approved
rendezvous and application-data path without putting all overlay maintenance on
four-hop routes.

Hyperswarm fork revision
`4bae99e4067f77fa3b378914883b357f87292de4` selects
`dht.privateRouting` for every peer server and dial while retaining the root DHT
for discovery and lifecycle. Its real six-node integration passes on Node and
Bare, 1/1 test and 3/3 assertions, and proves the selected peer stream has zero
direct destination sends. Its HyperDHT, DHT RPC, and sodium-native forks are
exact-commit codeload archives, so a fresh install succeeds with no `git`
executable on `PATH` and the repository's socket-firewall `--allow-git=none`
policy remains intact. PearTube revision
`53896a3be13f1a35b26a00acf58c3aa139c1fc99` pins that fork for the backend and
mobile bundle. `network.privateRouting: true` expands to the exact acknowledged
endpoint profile on desktop or mobile; it remains opt-in because a deployment
needs four reachable relay nodes and the external review gate. The backend
regression passes 29/29, the changed-code policy lint passes, and the Bare mobile
backend bundle completes with require coverage.

Draft integration reviews are
[Hyperswarm PR 2](https://github.com/ayooooo123/hyperswarm/pull/2) and
[PearTube PR 548](https://github.com/ayooooo123/peartube/pull/548). The
Hyperswarm focused private path is green; its full upstream suite is not a
release signal on this host because `test/chaos.js` fails convergence and leaves
the following test active. An isolated unmodified parent worktree using registry
HyperDHT 6.33.0 reproduces the same `test/swarm.js:62` assertion-after-end.

HyperDHT Actions run
[34773603689](https://github.com/ayooooo123/hyperdht/actions/runs/34773603689)
passes the Linux live gate plus deterministic macOS and Linux jobs at the code
revision above. PearTube's exact downstream revision passes Fast CI, relay
tests/container build, Android debug/release, and iOS build. Hyperswarm run
[34774056889](https://github.com/ayooooo123/hyperswarm/actions/runs/34774056889)
passes lint and git-disabled dependency installation on Linux and macOS; its
Windows job fails in the upstream `bare-base@v1` setup because socket-firewall
cannot locate `npm` on `PATH`, then fail-fast cancels Linux/macOS during the
pre-existing 60-second chaos test. This is a CI runner/action defect, not a
private-path pass claim; the focused Node and Bare private integrations above
are the behavioral evidence.

The complete dormant peer-tail/UDX stack is still not a production runtime.
Its test fixture supplies fake clocks, fake topology, test-only authorities and
synthetic neighbor provisioning that the public controller cannot obtain.
Promoting that fixture would fabricate discovery and admission rather than
integrate them. Public activation therefore remains on the narrower peer alpha
until a real decentralized bootstrap/neighbor service replaces those fixture
inputs and the exact resulting wire receives named external human
cryptographic review.
